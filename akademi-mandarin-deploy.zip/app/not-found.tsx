import Link from "next/link";

export default function NotFound() {
  return (
    <div className="app-shell-bg flex min-h-screen flex-col items-center justify-center px-6 py-20 text-center">
      <span className="font-cjk text-6xl text-brand-600/70">迷</span>
      <h1 className="mt-6 text-3xl font-extrabold text-ink-900">
        Halaman tidak ditemukan
      </h1>
      <p className="mt-3 max-w-md text-sm leading-relaxed text-ink-500">
        Tautan yang Anda buka mungkin sudah dipindahkan atau tidak pernah ada. Silakan
        kembali ke beranda atau lihat program kami.
      </p>
      <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
        <Link
          href="/"
          className="rounded-full bg-gradient-to-r from-brand-600 to-accent-500 px-6 py-3 text-sm font-semibold text-white transition hover:brightness-110"
        >
          Kembali ke Beranda
        </Link>
        <Link
          href="/program"
          className="rounded-full border border-brand-200 bg-white/70 px-6 py-3 text-sm font-semibold text-brand-700 transition hover:border-brand-400"
        >
          Lihat Program
        </Link>
      </div>
    </div>
  );
}
