"use client";

import { useEffect } from "react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Server-side details stay on the server; log the digest for support.
    console.error("[Akademi Mandarin] kesalahan:", error.digest ?? error.message);
  }, [error]);

  return (
    <div className="app-shell-bg flex min-h-screen flex-col items-center justify-center px-6 py-20 text-center">
      <span className="font-cjk text-6xl text-brand-600/70">误</span>
      <h1 className="mt-6 text-3xl font-extrabold text-ink-900">
        Terjadi kesalahan
      </h1>
      <p className="mt-3 max-w-md text-sm leading-relaxed text-ink-500">
        Sistem gagal memuat halaman ini. Silakan coba lagi. Bila masalah berlanjut,
        hubungi tim Akademi Mandarin.
      </p>
      {error.digest ? (
        <p className="mt-2 text-xs text-ink-400">Kode: {error.digest}</p>
      ) : null}
      <button
        type="button"
        onClick={reset}
        className="mt-8 rounded-full bg-gradient-to-r from-brand-600 to-accent-500 px-6 py-3 text-sm font-semibold text-white transition hover:brightness-110"
      >
        Coba Lagi
      </button>
    </div>
  );
}
