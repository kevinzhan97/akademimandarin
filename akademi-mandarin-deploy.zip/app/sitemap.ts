import type { MetadataRoute } from "next";
import { siteConfig } from "@/lib/site";

const routes = [
  { path: "/", priority: 1, changeFrequency: "weekly" as const },
  { path: "/tentang-kami", priority: 0.8, changeFrequency: "monthly" as const },
  { path: "/program", priority: 0.9, changeFrequency: "weekly" as const },
  { path: "/mengapa-mandarin", priority: 0.7, changeFrequency: "monthly" as const },
  { path: "/metode-belajar", priority: 0.7, changeFrequency: "monthly" as const },
  { path: "/hsk-path", priority: 0.8, changeFrequency: "monthly" as const },
  { path: "/faq", priority: 0.6, changeFrequency: "monthly" as const },
  { path: "/mulai-sekarang", priority: 0.9, changeFrequency: "monthly" as const },
];

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();

  return routes.map((route) => ({
    url: `${siteConfig.url}${route.path}`,
    lastModified,
    changeFrequency: route.changeFrequency,
    priority: route.priority,
  }));
}
