import type { Metadata } from "next";
import { DashboardShell } from "@/components/dashboard/DashboardShell";
import { loadDashboardShell } from "@/lib/dashboard";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Buzzer — Akademi Mandarin",
  robots: { index: false, follow: false },
};

export default async function BuzzerLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const { shell } = await loadDashboardShell("BUZZER", "ADMIN");

  return (
    <DashboardShell
      nav={shell.nav}
      user={shell.user}
      unreadNotifications={shell.unreadNotifications}
    >
      {children}
    </DashboardShell>
  );
}
