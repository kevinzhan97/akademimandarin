import { ListCard } from "@/components/dashboard/ListCard";
import { statusTone } from "@/components/ui/Badge";
import { PageHeader } from "@/components/ui/PageHeader";
import { StatCard } from "@/components/ui/StatCard";
import { requireRole } from "@/lib/auth";
import { getBuzzerDashboard } from "@/lib/queries/dashboards";
import { formatDate, humanizeEnum } from "@/lib/utils";

export default async function BuzzerDashboardPage() {
  await requireRole("BUZZER", "ADMIN");
  const data = await getBuzzerDashboard();

  return (
    <>
      <PageHeader
        eyebrow="Dashboard"
        title="Dashboard Buzzer"
        description="Pusat koordinasi kelas: pastikan setiap kelas punya guru, jadwal, dan murid yang tepat."
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Kelas Butuh Guru"
          value={data.counters.unassignedClasses}
          hint="Status planned/aktif tanpa pengajar"
          icon="alert"
          tone="gold"
        />
        <StatCard
          label="Kelas Aktif"
          value={data.counters.activeClasses}
          icon="bookOpen"
        />
        <StatCard
          label="Guru Aktif"
          value={data.counters.activeTeachers}
          icon="teacher"
          tone="jade"
        />
        <StatCard
          label="Murid Tanpa Kelas"
          value={data.counters.studentsWithoutClass}
          hint={`${data.counters.scheduledSlots} slot jadwal aktif`}
          icon="graduation"
        />
      </div>

      <div className="mt-6 grid gap-5 xl:grid-cols-2">
        <ListCard
          title="Kelas menunggu penugasan guru"
          description="Permintaan koordinasi yang perlu segera ditindaklanjuti"
          actionLabel="Kelola permintaan"
          emptyIcon="checkCircle"
          emptyTitle="Semua kelas sudah punya guru"
          emptyDescription="Tidak ada permintaan koordinasi yang tertunda."
          items={data.unassignedClasses.map((item) => ({
            id: item.id,
            title: item.name,
            meta: `${item.code} · ${item.program.name} · ${item.level?.name ?? "Level belum diatur"}`,
            detail: `Mulai ${formatDate(item.startDate)} · ${item._count.students} murid terdaftar`,
            badge: { label: "Butuh guru", tone: "warning" as const },
          }))}
        />

        <ListCard
          title="Jadwal kelas mingguan"
          description="Slot aktif yang sedang berjalan"
          actionLabel="Kelola jadwal"
          emptyIcon="calendar"
          emptyTitle="Belum ada slot jadwal"
          emptyDescription="Tambahkan jadwal pada kelas yang sudah dibuat."
          items={data.weekSchedules.map((schedule) => ({
            id: schedule.id,
            title: schedule.class.name,
            meta: `${humanizeEnum(schedule.dayOfWeek)} · ${schedule.startTime}–${schedule.endTime}`,
            trailing: schedule.teacher?.user.fullName ?? "Guru belum ditentukan",
          }))}
        />

        <ListCard
          title="Ringkasan status kelas"
          description="Distribusi status kelas di sistem"
          emptyIcon="chart"
          emptyTitle="Belum ada kelas"
          items={[
            {
              id: "active",
              title: "Kelas aktif",
              meta: "Sedang berjalan dengan murid terdaftar",
              badge: { label: String(data.counters.activeClasses), tone: statusTone("ACTIVE") },
            },
            {
              id: "unassigned",
              title: "Kelas tanpa guru",
              meta: "Perlu penugasan guru oleh buzzer",
              badge: {
                label: String(data.counters.unassignedClasses),
                tone: statusTone("PENDING"),
              },
            },
            {
              id: "enrollment",
              title: "Enrollment menunggu konfirmasi",
              meta: "Calon murid yang perlu ditempatkan ke kelas",
              badge: { label: String(data.counters.pendingEnrollments), tone: "info" as const },
            },
            {
              id: "students",
              title: "Murid aktif tanpa kelas",
              meta: "Sudah terdaftar namun belum punya kelas aktif",
              badge: { label: String(data.counters.studentsWithoutClass), tone: "warning" as const },
            },
          ]}
        />
      </div>
    </>
  );
}
