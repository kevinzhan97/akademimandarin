import { ProfilePanel } from "@/components/dashboard/ProfilePanel";
import { requireRole } from "@/lib/auth";

export default async function BuzzerProfilePage() {
  await requireRole("BUZZER", "ADMIN");

  return (
    <ProfilePanel subtitle="Kelola data akun koordinator kelas Anda." />
  );
}
