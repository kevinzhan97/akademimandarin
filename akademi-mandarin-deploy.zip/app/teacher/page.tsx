import { ListCard } from "@/components/dashboard/ListCard";
import { EmptyState } from "@/components/ui/Feedback";
import { PageHeader } from "@/components/ui/PageHeader";
import { StatCard } from "@/components/ui/StatCard";
import { statusTone } from "@/components/ui/Badge";
import { requireRole } from "@/lib/auth";
import { getTeacherDashboard } from "@/lib/queries/dashboards";
import { formatDate, humanizeEnum } from "@/lib/utils";

export default async function TeacherDashboardPage() {
  const user = await requireRole("TEACHER", "ADMIN");
  const data = await getTeacherDashboard(user.id);

  if (!data) {
    return (
      <>
        <PageHeader eyebrow="Dashboard" title="Dashboard Guru" />
        <EmptyState
          icon="teacher"
          title="Profil guru belum dibuat"
          description="Akun Anda belum memiliki profil guru. Hubungi administrator Akademi Mandarin untuk melengkapinya."
        />
      </>
    );
  }

  return (
    <>
      <PageHeader
        eyebrow="Dashboard"
        title="Dashboard Guru"
        description={`Selamat mengajar, ${user.fullName}. Berikut ringkasan kelas dan tugas murid Anda.`}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Kelas Saya" value={data.counters.classes} icon="bookOpen" />
        <StatCard
          label="Murid Aktif"
          value={data.counters.students}
          icon="users"
          tone="jade"
        />
        <StatCard
          label="Tugas Perlu Dinilai"
          value={data.counters.submissionsToGrade}
          icon="clipboard"
          tone="gold"
        />
        <StatCard
          label="Kuis Perlu Dinilai"
          value={data.counters.attemptsToGrade}
          icon="quiz"
        />
      </div>

      <div className="mt-6 grid gap-5 xl:grid-cols-2">
        <ListCard
          title="Kelas saya"
          description="Kelas yang ditugaskan kepada Anda"
          actionLabel="Lihat semua"
          emptyIcon="bookOpen"
          emptyTitle="Belum ada kelas"
          emptyDescription="Buzzer atau admin akan menugaskan kelas kepada Anda."
          items={data.classes.map((item) => ({
            id: item.id,
            title: item.name,
            meta: `${item.program.name} · ${item.level?.name ?? "Level belum diatur"} · ${item._count.students} murid`,
            badge: { label: humanizeEnum(item.status), tone: statusTone(item.status) },
          }))}
        />

        <ListCard
          title="Jadwal mengajar"
          description="Slot jadwal mingguan Anda"
          actionLabel="Jadwal lengkap"
          emptyIcon="calendar"
          emptyTitle="Belum ada jadwal mengajar"
          items={data.schedules.map((schedule) => ({
            id: schedule.id,
            title: schedule.class.name,
            meta: `${humanizeEnum(schedule.dayOfWeek)} · ${schedule.startTime}–${schedule.endTime}${schedule.room ? ` · ${schedule.room}` : ""}`,
            badge: { label: humanizeEnum(schedule.type) },
          }))}
        />

        <ListCard
          title="Tugas menunggu penilaian"
          description="Kiriman murid di kelas Anda"
          actionLabel="Nilai sekarang"
          emptyIcon="checkCircle"
          emptyTitle="Tidak ada tugas tertunda"
          emptyDescription="Semua kiriman murid sudah dinilai."
          items={data.submissionsToGrade.map((submission) => ({
            id: submission.id,
            title: submission.assignment.title,
            meta: `${submission.student.user.fullName} · dikirim ${formatDate(submission.submittedAt)}`,
            badge: { label: "Perlu dinilai", tone: "warning" as const },
          }))}
        />

        <ListCard
          title="Kuis menunggu penilaian"
          description="Percobaan kuis murid yang perlu dikoreksi"
          actionLabel="Buka kuis"
          emptyIcon="quiz"
          emptyTitle="Tidak ada kuis tertunda"
          emptyDescription="Semua percobaan kuis sudah dinilai."
          items={data.attemptsToGrade.map((attempt) => ({
            id: attempt.id,
            title: attempt.quiz.title,
            meta: `${attempt.student.user.fullName} · ${attempt.submittedAt ? formatDate(attempt.submittedAt) : "-"}`,
            badge: { label: "Perlu dinilai", tone: "warning" as const },
          }))}
        />
      </div>
    </>
  );
}
