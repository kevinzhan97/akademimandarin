import { ProfilePanel } from "@/components/dashboard/ProfilePanel";
import { requireRole } from "@/lib/auth";

export default async function TeacherProfilePage() {
  await requireRole("TEACHER", "ADMIN");

  return (
    <ProfilePanel subtitle="Kelola data kontak pengajar untuk koordinasi kelas dan murid." />
  );
}
