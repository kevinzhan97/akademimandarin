import type { Metadata } from "next";
import { CtaSection, PublicPageHeader } from "@/components/public/Sections";
import { Icon } from "@/components/ui/Icon";
import { getPublicStats } from "@/lib/queries/public";
import { siteConfig } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Tentang Kami",
  description:
    "Akademi Mandarin adalah akademi bahasa Mandarin yang menjembatani Indonesia dan Tiongkok melalui pengajaran terstruktur, guru bersertifikat, dan sistem belajar terukur.",
  alternates: { canonical: "/tentang-kami" },
};

export default async function AboutPage() {
  const stats = await getPublicStats();

  const statItems = [
    { label: "Murid aktif", value: stats.students },
    { label: "Guru aktif", value: stats.teachers },
    { label: "Program", value: stats.programs },
    { label: "Kelas aktif", value: stats.activeClasses },
  ];

  return (
    <>
      <PublicPageHeader
        eyebrow="Tentang Kami"
        hanzi="关"
        title="Menjembatani Indonesia dan Tiongkok melalui bahasa"
        description="Akademi Mandarin lahir dari satu keyakinan sederhana: bahasa adalah jembatan. Kami menggabungkan pengajaran kelas kecil, kurikulum HSK yang terstruktur, dan sistem belajar digital agar perjalanan belajar Anda jelas dari hari pertama."
      />

      <section className="section-pad pt-4">
        <div className="shell-container grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="space-y-6 text-base leading-relaxed text-ink-600">
            <p>
              Kami memulai dari kelas-kelas kecil bersama murid yang ingin bekerja,
              melanjutkan studi, atau membangun bisnis dengan mitra Tiongkok. Seiring
              waktu, kebutuhan mereka berkembang: bukan hanya bisa berbicara, tetapi
              juga membaca, menulis, dan memahami konteks budaya.
            </p>
            <p>
              Karena itu kurikulum kami disusun sejalan dengan HSK - mulai dari{" "}
              <strong className="text-ink-800">Pre-HSK 1</strong> untuk pemula total,
              hingga <strong className="text-ink-800">HSK 4</strong> untuk kebutuhan
              profesional. Segmen internal 3A/3B dan 4A/4B membantu murid mencerna
              materi tingkat lanjut secara bertahap tanpa kehilangan arah.
            </p>
            <p>
              Saat ini Akademi Mandarin melayani murid perorangan, kelompok, dan
              korporat melalui kelas online maupun tatap muka, dengan portal belajar
              yang mencatat seluruh perjalanan belajar murid: materi, kuis, tugas,
              kehadiran, hingga progres tiap keterampilan HSK.
            </p>
            <p>
              Kami percaya kualitas belajar ditentukan oleh tiga hal: guru yang tepat,
              kurikulum yang terarah, dan kebiasaan latihan yang konsisten. Ketiganya
              kami jaga dalam setiap kelas.
            </p>
          </div>

          <div className="glass rounded-[2rem] p-6">
            <h2 className="text-lg font-bold text-ink-900">Akademi Mandarin hari ini</h2>
            {stats.available ? (
              <>
                <dl className="mt-5 grid grid-cols-2 gap-5">
                  {statItems.map((item) => (
                    <div key={item.label}>
                      <dt className="text-xs font-semibold tracking-wide text-ink-400 uppercase">
                        {item.label}
                      </dt>
                      <dd className="mt-1 text-3xl font-extrabold text-brand-700">
                        {item.value}
                      </dd>
                    </div>
                  ))}
                </dl>
                <p className="mt-5 text-xs leading-relaxed text-ink-400">
                  Angka di atas diambil langsung dari basis data resmi Akademi Mandarin.
                </p>
              </>
            ) : (
              <p className="mt-4 text-sm leading-relaxed text-ink-500">
                Statistik akademi sedang tidak dapat dimuat. Silakan hubungi tim kami
                melalui WhatsApp atau email untuk data terbaru.
              </p>
            )}
            <div className="mt-6 space-y-3 border-t border-ink-900/8 pt-5 text-sm text-ink-600">
              <p className="flex items-center gap-2">
                <Icon name="mail" size={16} />
                {siteConfig.email}
              </p>
              <p className="flex items-center gap-2">
                <Icon name="globe" size={16} />
                {siteConfig.url.replace("https://", "")}
              </p>
            </div>
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
