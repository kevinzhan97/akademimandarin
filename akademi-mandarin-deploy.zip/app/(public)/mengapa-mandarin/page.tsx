import type { Metadata } from "next";
import { CtaSection, PublicPageHeader } from "@/components/public/Sections";
import { TrustStrip } from "@/components/public/ContentSections";
import { GlassCard } from "@/components/ui/Card";
import { Icon } from "@/components/ui/Icon";
import { whyMandarin } from "@/lib/content";
import { getPublicStats } from "@/lib/queries/public";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Mengapa Belajar Mandarin",
  description:
    "Alasan belajar bahasa Mandarin: peluang karier, bisnis dengan mitra Tiongkok, beasiswa dan studi, travel, pemahaman budaya, serta sertifikasi HSK yang diakui.",
  alternates: { canonical: "/mengapa-mandarin" },
};

const careerFacts = [
  {
    title: "Bekerja dengan mitra Tiongkok",
    description:
      "Komunikasi langsung tanpa perantara membuat kerja sama lebih cepat, akurat, dan dipercaya.",
  },
  {
    title: "Studi & beasiswa",
    description:
      "Banyak beasiswa pemerintah Tiongkok mensyaratkan skor HSK sebagai bukti kemampuan bahasa.",
  },
  {
    title: "Konten tanpa subtitle",
    description:
      "Drama, berita, dan artikel dapat dinikmati langsung - cara paling menyenangkan memperluas kosakata.",
  },
];

export default async function WhyMandarinPage() {
  const stats = await getPublicStats();

  return (
    <>
      <PublicPageHeader
        eyebrow="Mengapa Mandarin"
        hanzi="为"
        title="Bahasa yang membuka jalan antara dua ekonomi besar"
        description="Mandarin bukan sekadar hobi. Untuk banyak murid kami, bahasa ini adalah kunci karier, pendidikan, bisnis, dan pengalaman budaya yang jauh lebih dalam."
      />

      {stats.available ? <TrustStrip stats={stats} /> : null}
      <section className="section-pad">
        <div className="shell-container grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {whyMandarin.map((item) => (
            <GlassCard key={item.title} interactive className="h-full">
              <span className="mb-4 flex size-11 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-600 to-accent-500 text-white">
                <Icon name={item.icon} size={20} />
              </span>
              <h2 className="text-lg font-bold text-ink-900">{item.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">
                {item.description}
              </p>
            </GlassCard>
          ))}
        </div>
      </section>

      <section className="section-pad bg-white/50">
        <div className="shell-container grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
          <div>
            <h2 className="text-3xl font-extrabold text-balance sm:text-4xl">
              Apa yang berubah setelah bisa Mandarin?
            </h2>
            <p className="mt-4 text-base leading-relaxed text-ink-500">
              Perubahan paling sering dirasakan murid kami bukan pada nilai ujian,
              tetapi pada kepercayaan diri: berani membuka percakapan, menulis pesan
              bisnis, dan memahami nuansa budaya.
            </p>
          </div>
          <ul className="grid gap-4 sm:grid-cols-3">
            {careerFacts.map((fact) => (
              <li key={fact.title} className="card-surface p-5">
                <h3 className="text-sm font-bold text-ink-900">{fact.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">
                  {fact.description}
                </p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
