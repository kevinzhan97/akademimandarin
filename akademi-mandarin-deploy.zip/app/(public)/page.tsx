import type { Metadata } from "next";
import Image from "next/image";
import { BenefitCards } from "@/components/BenefitCards";
import { Hero } from "@/components/Hero";
import { HeroStats } from "@/components/HeroStats";
import { HSKPath } from "@/components/HSKPath";
import { QuoteBlock } from "@/components/QuoteBlock";
import { FaqAccordion } from "@/components/public/FaqAccordion";
import { LeadForm } from "@/components/public/LeadForm";
import { ProgramShowcase } from "@/components/public/ProgramShowcase";
import {
  FaqPreview,
  MethodPreview,
  TrustStrip,
  WhyMandarinPreview,
} from "@/components/public/ContentSections";
import { CtaSection, VideoSection } from "@/components/public/Sections";
import { SectionHeading } from "@/components/ui/Card";
import { faqs } from "@/lib/content";
import { getLeadProgramOptions, getPublicPrograms, getPublicStats } from "@/lib/queries/public";
import { siteConfig } from "@/lib/site";

// Public content is rendered per request so admin updates appear immediately.
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: `${siteConfig.name} — Mandarin Menghubungkan Lebih Banyak Peluang`,
  description: siteConfig.description,
  alternates: { canonical: "/" },
};

export default async function HomePage() {
  const [programs, stats, programOptions] = await Promise.all([
    getPublicPrograms(),
    getPublicStats(),
    getLeadProgramOptions(),
  ]);

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    name: siteConfig.name,
    url: siteConfig.url,
    description: siteConfig.description,
    email: siteConfig.email,
    areaServed: "ID",
    knowsLanguage: ["zh", "id"],
    makesOffer: programs.map((program) => ({
      "@type": "Offer",
      name: `${program.name} (${program.hskLabel})`,
      category: "Language course",
    })),
  };

  return (
    <>
      <script
        type="application/ld+json"
        // Structured data for search engines.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      {/*
        ONE continuous cinematic composition. The wallpaper is the canvas and
        every UI layer is stacked inside the SAME grid cell, so the UI starts at
        Y = 0 - there is no flow box (and therefore no gap) above the artwork.
        The wallpaper layer itself is viewport-pinned so the 3:2 panorama is
        never stretched or badly cropped.
      */}
      <div className="relative isolate grid min-h-svh">
        {/* Layer 0 - wallpaper canvas, sticky inside its own grid cell. The
            inner wrapper is `relative` so `next/image fill` has a valid
            positioned parent. */}
        <div className="pointer-events-none sticky top-0 -z-10 col-start-1 row-start-1 h-svh w-full self-start">
          <div className="relative h-full w-full overflow-hidden">
            <Image
              src="/wallpaper.png"
              alt="Panorama Akademi Mandarin: kuil Tiongkok, Tembok Besar, dan Monas dalam satu cakrawala yang menghubungkan Indonesia dan Tiongkok."
              fill
              preload
              sizes="100vw"
              className="object-cover object-[50%_62%]"
            />
            {/* Layer 1 - subtle readability veils; the artwork stays dominant. */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#fffdfb]/88 via-[#fffdfb]/62 to-[#fffdfb]/30 md:hidden" />
            <div className="absolute inset-0 hidden bg-gradient-to-r from-[#fffdfb]/82 via-[#fffdfb]/45 via-40% to-transparent md:block" />
            <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-white/55 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-b from-transparent to-[#fdfcfb]" />
          </div>
        </div>

        {/* Layers 20-40 - real React UI in the same cell, starting at Y = 0. */}
        <div className="shell-container relative z-20 col-start-1 row-start-1 flex flex-col gap-5 pt-24 pb-10 sm:gap-6 sm:pt-24 lg:gap-6 lg:pt-28">
          <Hero />
          <HeroStats />
          <BenefitCards className="relative z-30" />
          <div className="grid gap-4 lg:grid-cols-[1.55fr_1fr] lg:items-end">
            <HSKPath />
            <QuoteBlock />
          </div>
        </div>
      </div>

      {stats.available ? <TrustStrip stats={stats} /> : null}
      <ProgramShowcase programs={programs} />
      <MethodPreview />
      <WhyMandarinPreview />
      <VideoSection />

      <FaqPreview>
        <FaqAccordion items={faqs.slice(0, 5)} />
      </FaqPreview>

      <section className="section-pad" id="daftar">
        <div className="shell-container">
          <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr] lg:items-start">
            <SectionHeading
              align="left"
              eyebrow="Mulai Sekarang"
              title="Ambil trial gratis 60 menit"
              description="Isi formulir singkat ini. Tim akademik kami akan menghubungi Anda untuk mengatur tes penempatan dan jadwal kelas percobaan."
            />
            <div className="glass rounded-[2rem] p-6 sm:p-8">
              <LeadForm programs={programOptions} />
            </div>
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
