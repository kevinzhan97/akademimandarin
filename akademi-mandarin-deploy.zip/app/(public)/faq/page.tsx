import type { Metadata } from "next";
import { FaqAccordion } from "@/components/public/FaqAccordion";
import { PublicPageHeader } from "@/components/public/Sections";
import { Icon } from "@/components/ui/Icon";
import { faqs } from "@/lib/content";
import { siteConfig, whatsappLink } from "@/lib/site";

export const metadata: Metadata = {
  title: "FAQ",
  description:
    "Pertanyaan umum tentang kursus Mandarin Akademi Mandarin: level, durasi, jadwal, kelas online, pembayaran, trial gratis, dan sertifikasi HSK.",
  alternates: { canonical: "/faq" },
};

export default function FaqPage() {
  const structuredData = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: { "@type": "Answer", text: faq.answer },
    })),
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <PublicPageHeader
        eyebrow="FAQ"
        hanzi="问"
        title="Pertanyaan yang sering diajukan"
        description="Belum menemukan jawaban yang Anda cari? Tim akademik kami siap membantu melalui WhatsApp atau email pada hari kerja."
      />

      <section className="section-pad pt-4">
        <div className="shell-container grid gap-10 lg:grid-cols-[1.3fr_0.7fr] lg:items-start">
          <FaqAccordion items={faqs} />

          <aside className="glass rounded-[2rem] p-6">
            <h2 className="text-lg font-bold text-ink-900">Masih ada pertanyaan?</h2>
            <p className="mt-2 text-sm leading-relaxed text-ink-500">
              Hubungi tim Akademi Mandarin. Kami membantu memilih program, menghitung
              durasi belajar, dan menjadwalkan trial gratis Anda.
            </p>
            <div className="mt-5 space-y-3">
              <a
                href={whatsappLink("Halo Akademi Mandarin, saya ingin bertanya tentang program.")}
                target="_blank"
                rel="noreferrer noopener"
                className="flex items-center gap-3 rounded-2xl border border-ink-900/10 bg-white/80 px-4 py-3 text-sm font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
              >
                <Icon name="whatsapp" size={17} />
                WhatsApp
              </a>
              <a
                href={`mailto:${siteConfig.email}`}
                className="flex items-center gap-3 rounded-2xl border border-ink-900/10 bg-white/80 px-4 py-3 text-sm font-semibold text-ink-700 transition hover:border-brand-300 hover:text-brand-700"
              >
                <Icon name="mail" size={17} />
                {siteConfig.email}
              </a>
              <a
                href="/mulai-sekarang"
                className="flex items-center gap-3 rounded-2xl bg-gradient-to-r from-brand-600 to-accent-500 px-4 py-3 text-sm font-semibold text-white transition hover:brightness-110"
              >
                <Icon name="arrowRight" size={17} />
                Mulai Sekarang
              </a>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
