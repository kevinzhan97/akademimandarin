"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { publicLeadSchema, zodFieldErrors } from "@/lib/validators";
import type { FormState } from "@/types/forms";

/**
 * Public "Mulai Sekarang" form → creates a CRM lead.
 * This is the single entry point from the company profile into the CRM.
 */
export async function submitLeadAction(
  _previous: FormState,
  formData: FormData,
): Promise<FormState> {
  // Honeypot: silently drop obvious bot submissions.
  const honeypot = formData.get("company");
  if (typeof honeypot === "string" && honeypot.trim().length > 0) {
    return {
      status: "success",
      message: "Terima kasih, data Anda sudah kami terima.",
    };
  }

  const parsed = publicLeadSchema.safeParse({
    name: formData.get("name") ?? "",
    phone: formData.get("phone") ?? "",
    email: formData.get("email") ?? "",
    programId: formData.get("programId") ?? "",
    currentLevel: formData.get("currentLevel") ?? "",
    notes: formData.get("notes") ?? "",
  });

  if (!parsed.success) {
    return {
      status: "error",
      message: "Periksa kembali data yang Anda isi.",
      errors: zodFieldErrors(parsed.error),
    };
  }

  const data = parsed.data;
  const programId = data.programId ? Number(data.programId) : null;

  try {
    const program =
      programId && Number.isInteger(programId)
        ? await prisma.program.findUnique({
            where: { id: programId },
            select: { id: true, name: true },
          })
        : null;

    await prisma.lead.create({
      data: {
        name: data.name,
        phone: data.phone,
        email: data.email ? data.email : null,
        source: "WEBSITE",
        programId: program?.id ?? null,
        currentLevel: data.currentLevel ? data.currentLevel : null,
        status: "LEAD",
        notes: data.notes
          ? `${data.notes}\n\n(Dikirim dari formulir website Akademi Mandarin)`
          : "Dikirim dari formulir website Akademi Mandarin.",
        followUpDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
      },
    });
  } catch {
    return {
      status: "error",
      message:
        "Maaf, terjadi gangguan saat menyimpan data. Silakan hubungi kami melalui WhatsApp.",
    };
  }

  revalidatePath("/admin/leads");
  revalidatePath("/admin");

  return {
    status: "success",
    message:
      "Terima kasih! Data Anda sudah masuk ke sistem kami. Tim akademik akan menghubungi Anda dalam 1×24 jam.",
  };
}
