import type { Metadata } from "next";
import { LeadForm } from "@/components/public/LeadForm";
import { PublicPageHeader } from "@/components/public/Sections";
import { Badge } from "@/components/ui/Badge";
import { Icon } from "@/components/ui/Icon";
import { getLeadProgramOptions, getPublicPrograms } from "@/lib/queries/public";
import { whatsappLink } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Mulai Sekarang",
  description:
    "Daftar kelas Mandarin Akademi Mandarin. Isi formulir singkat, dapatkan tes penempatan gratis, dan mulai kelas percobaan 60 menit.",
  alternates: { canonical: "/mulai-sekarang" },
};

const steps = [
  {
    title: "Isi formulir",
    description: "Cukup nama, nomor WhatsApp, dan program yang Anda minati.",
  },
  {
    title: "Dihubungi tim akademik",
    description: "Kami menghubungi Anda dalam 1×24 jam pada hari kerja.",
  },
  {
    title: "Tes penempatan gratis",
    description: "Menentukan titik mulai: Pre-HSK 1 sampai HSK 4.",
  },
  {
    title: "Kelas percobaan 60 menit",
    description: "Coba kelas bersama guru, lalu tentukan jadwal tetap Anda.",
  },
];

export default async function StartNowPage({
  searchParams,
}: {
  searchParams: Promise<{ program?: string }>;
}) {
  const [params, programs, publicPrograms] = await Promise.all([
    searchParams,
    getLeadProgramOptions(),
    getPublicPrograms(),
  ]);

  const selected = params.program
    ? publicPrograms.find((program) => program.slug === params.program)
    : undefined;

  return (
    <>
      <PublicPageHeader
        eyebrow="Mulai Sekarang"
        hanzi="始"
        title="Ambil langkah pertama hari ini"
        description="Isi formulir singkat berikut. Tim akademik Akademi Mandarin akan menghubungi Anda untuk mengatur tes penempatan dan kelas percobaan gratis."
      />

      <section className="section-pad pt-4">
        <div className="shell-container grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-start">
          <div className="glass rounded-[2rem] p-6 sm:p-8">
            <h2 className="text-lg font-bold text-ink-900">Formulir pendaftaran</h2>
            <p className="mt-1 mb-6 text-sm text-ink-500">
              Data Anda tersimpan aman di sistem Akademi Mandarin dan hanya digunakan
              untuk keperluan konsultasi program.
            </p>
            <LeadForm
              programs={programs}
              defaultProgramId={selected ? selected.id : null}
            />
          </div>

          <div className="space-y-6">
            {selected ? (
              <div className="card-surface p-6">
                <Badge tone="brand">Program dipilih</Badge>
                <h2 className="mt-3 text-lg font-bold text-ink-900">
                  {selected.name}
                </h2>
                <p className="mt-1 text-sm font-semibold text-brand-600">
                  {selected.hskLabel}
                </p>
                <p className="mt-3 text-sm leading-relaxed text-ink-500">
                  {selected.description}
                </p>
              </div>
            ) : null}

            <div className="card-surface p-6">
              <h2 className="text-lg font-bold text-ink-900">Alur pendaftaran</h2>
              <ol className="mt-5 space-y-4">
                {steps.map((step, index) => (
                  <li key={step.title} className="flex gap-3">
                    <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-brand-50 text-xs font-bold text-brand-700">
                      {index + 1}
                    </span>
                    <span>
                      <span className="block text-sm font-semibold text-ink-800">
                        {step.title}
                      </span>
                      <span className="mt-0.5 block text-sm text-ink-500">
                        {step.description}
                      </span>
                    </span>
                  </li>
                ))}
              </ol>
            </div>

            <div className="glass rounded-[2rem] p-6">
              <p className="text-sm font-semibold text-ink-800">
                Ingin langsung berbicara?
              </p>
              <p className="mt-1 text-sm text-ink-500">
                Hubungi tim kami melalui WhatsApp pada hari kerja 09.00 – 20.00 WIB.
              </p>
              <a
                href={whatsappLink("Halo Akademi Mandarin, saya ingin mendaftar kelas.")}
                target="_blank"
                rel="noreferrer noopener"
                className="mt-4 inline-flex items-center gap-2 rounded-full bg-jade-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-jade-600"
              >
                <Icon name="whatsapp" size={16} />
                Chat WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
