import type { Metadata } from "next";
import Link from "next/link";
import { PublicPageHeader } from "@/components/public/Sections";
import { Icon } from "@/components/ui/Icon";
import { searchPublicContent } from "@/lib/queries/search";
import { siteConfig } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Pencarian",
  description: `Cari program, jalur HSK, metode belajar, dan pertanyaan umum di ${siteConfig.name}.`,
  alternates: { canonical: "/cari" },
  robots: { index: false, follow: true },
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string | string[] }>;
}) {
  const params = await searchParams;
  const raw = Array.isArray(params.q) ? params.q[0] : params.q;
  const results = await searchPublicContent(raw ?? "");
  const total = results.groups.reduce((sum, group) => sum + group.hits.length, 0);

  return (
    <>
      <PublicPageHeader
        eyebrow="Pencarian"
        hanzi="搜索"
        title="Cari di Akademi Mandarin"
        description="Telusuri program, jalur HSK, metode belajar, dan pertanyaan yang sering diajukan."
      />

      <section className="pb-16 sm:pb-24">
        <div className="shell-container">
          <form
            action="/cari"
            method="get"
            role="search"
            className="glass flex items-center gap-3 rounded-3xl p-3 sm:p-4"
          >
            <label htmlFor="search-page-input" className="sr-only">
              Kata kunci pencarian
            </label>
            <span className="flex min-w-0 flex-1 items-center gap-2 rounded-2xl border border-ink-900/10 bg-white/80 px-4">
              <Icon name="search" size={18} className="shrink-0 text-ink-400" />
              <input
                id="search-page-input"
                name="q"
                type="search"
                defaultValue={results.term}
                placeholder="Contoh: HSK 3, kelas percakapan, biaya"
                className="min-w-0 flex-1 bg-transparent py-3 text-sm text-ink-900 outline-none placeholder:text-ink-400"
              />
            </span>
            <button
              type="submit"
              className="shrink-0 rounded-full bg-gradient-to-r from-brand-600 to-accent-500 px-5 py-3 text-sm font-bold text-white transition hover:brightness-110"
            >
              Cari
            </button>
          </form>

          {results.term.length < 2 ? (
            <p className="mt-8 text-sm text-ink-500">
              Masukkan minimal dua karakter untuk mulai mencari.
            </p>
          ) : total === 0 ? (
            <div className="glass mt-8 rounded-3xl p-6">
              <p className="text-sm font-bold text-ink-900">
                Tidak ada hasil untuk &ldquo;{results.term}&rdquo;.
              </p>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">
                Coba kata kunci lain, atau langsung lihat{" "}
                <Link
                  href="/program"
                  className="font-semibold text-brand-600 underline decoration-brand-300 underline-offset-4"
                >
                  program belajar
                </Link>{" "}
                dan{" "}
                <Link
                  href="/faq"
                  className="font-semibold text-brand-600 underline decoration-brand-300 underline-offset-4"
                >
                  FAQ
                </Link>{" "}
                kami.
              </p>
            </div>
          ) : (
            <div className="mt-8 grid gap-8">
              {results.groups.map((group) => (
                <div key={group.label}>
                  <h2 className="text-xs font-extrabold tracking-[0.2em] text-ink-400 uppercase">
                    {group.label} · {group.hits.length}
                  </h2>
                  <ul className="mt-4 grid gap-3">
                    {group.hits.map((hit) => (
                      <li key={`${group.label}-${hit.href}-${hit.title}`}>
                        <Link
                          href={hit.href}
                          className="glass-soft glass-hover block rounded-2xl px-5 py-4"
                        >
                          <span className="block text-sm font-bold text-ink-900">
                            {hit.title}
                          </span>
                          {hit.description ? (
                            <span className="mt-1 block text-sm leading-relaxed text-ink-500">
                              {hit.description}
                            </span>
                          ) : null}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
