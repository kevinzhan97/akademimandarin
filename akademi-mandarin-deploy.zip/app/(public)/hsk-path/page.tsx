import type { Metadata } from "next";
import { FaqAccordion } from "@/components/public/FaqAccordion";
import { HskPathSection } from "@/components/public/HskPathSection";
import { CtaSection, PublicPageHeader } from "@/components/public/Sections";
import { SectionHeading } from "@/components/ui/Card";
import { faqs } from "@/lib/content";

export const metadata: Metadata = {
  title: "HSK Path",
  description:
    "Jalur belajar HSK di Akademi Mandarin: Pre-HSK 1, HSK 1, HSK 2, HSK 3 Path (segmen internal 3A/3B), dan HSK 4 Path (segmen internal 4A/4B).",
  alternates: { canonical: "/hsk-path" },
};

const hskFaqs = faqs.filter(
  (faq) => faq.question.includes("HSK") || faq.question.includes("lama"),
);

export default function HskPathPage() {
  return (
    <>
      <PublicPageHeader
        eyebrow="HSK Path"
        hanzi="考"
        title="Jalur resmi HSK, dengan struktur internal yang lebih mudah diikuti"
        description="Perjalanan belajar Anda dimulai dari Pre-HSK 1 untuk pemula total, lalu naik bertahap menuju HSK 1, HSK 2, HSK 3, dan HSK 4 sesuai target pribadi maupun kebutuhan profesional."
      />

      <HskPathSection />

      <section className="section-pad bg-white/50">
        <div className="shell-container grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <SectionHeading
            align="left"
            eyebrow="Perlu Diketahui"
            title="Level ujian resmi vs segmen internal"
            description="Kami ingin Anda memahami perbedaannya agar tidak salah menyebutkan kualifikasi saat melamar kerja atau mendaftar beasiswa."
          />
          <div className="space-y-4">
            <div className="card-surface p-6">
              <h3 className="text-base font-bold text-ink-900">
                Level ujian resmi HSK
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">
                Sertifikasi HSK yang dikeluarkan lembaga resmi menggunakan penomoran
                HSK 1, HSK 2, HSK 3, HSK 4, dan seterusnya. Pada sertifikat Anda hanya
                akan tercantum nomor level tersebut.
              </p>
            </div>
            <div className="card-surface p-6">
              <h3 className="text-base font-bold text-ink-900">
                Segmen internal 3A/3B dan 4A/4B
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">
                Segmen ini adalah pembagian materi di Akademi Mandarin agar beban
                belajar tingkat lanjut lebih terkendali. Tidak ada ujian resmi
                &ldquo;HSK 3A&rdquo; atau &ldquo;HSK 4B&rdquo; — keduanya bagian dari
                persiapan menuju level resmi berikutnya.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="section-pad">
        <div className="shell-container">
          <SectionHeading
            eyebrow="Pertanyaan HSK"
            title="Hal yang paling sering ditanyakan murid"
          />
          <div className="mx-auto mt-10 max-w-3xl">
            <FaqAccordion items={hskFaqs} />
          </div>
        </div>
      </section>

      <CtaSection />
    </>
  );
}
