import type { Metadata } from "next";
import { PublicPageHeader, CtaSection, VideoSection } from "@/components/public/Sections";
import { GlassCard, SectionHeading } from "@/components/ui/Card";
import { Icon } from "@/components/ui/Icon";
import { methodSteps } from "@/lib/content";

export const metadata: Metadata = {
  title: "Metode Belajar",
  description:
    "Metode belajar Akademi Mandarin: tes penempatan, rencana personal, kelas interaktif empat keterampilan, latihan terstruktur di LMS, serta evaluasi dan simulasi HSK.",
  alternates: { canonical: "/metode-belajar" },
};

const skills = [
  {
    hanzi: "听",
    title: "Listening",
    description:
      "Audio dialog, dikte, dan latihan nada dengan materi bertingkat dari HSK 1 hingga HSK 4.",
  },
  {
    hanzi: "说",
    title: "Speaking",
    description:
      "Praktik percakapan terarah dengan koreksi langsung guru, termasuk pelafalan nada.",
  },
  {
    hanzi: "读",
    title: "Reading",
    description:
      "Membaca hanzi, kalimat, dan artikel pendek dengan target kosakata per level.",
  },
  {
    hanzi: "写",
    title: "Writing",
    description:
      "Latihan urutan goresan, menulis kalimat, hingga menyusun paragraf dan esai singkat.",
  },
];

const support = ["Pinyin", "Grammar", "Vocabulary", "Hanzi"];

export default function MethodPage() {
  return (
    <>
      <PublicPageHeader
        eyebrow="Metode Belajar"
        hanzi="法"
        title="Sistem belajar yang membuat progres terlihat"
        description="Kami menggabungkan kelas interaktif dengan latihan mandiri terstruktur, sehingga setiap jam belajar menghasilkan kemajuan yang dapat diukur."
      />

      <section className="section-pad pt-4">
        <div className="shell-container">
          <ol className="grid gap-5 lg:grid-cols-5">
            {methodSteps.map((step) => (
              <li key={step.step}>
                <GlassCard className="h-full">
                  <div className="flex items-center justify-between">
                    <span className="flex size-11 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-600 to-accent-500 text-white">
                      <Icon name={step.icon} size={20} />
                    </span>
                    <span className="text-2xl font-black text-brand-100">
                      {step.step}
                    </span>
                  </div>
                  <h2 className="mt-4 text-base font-bold text-ink-900">
                    {step.title}
                  </h2>
                  <p className="mt-2 text-sm leading-relaxed text-ink-500">
                    {step.description}
                  </p>
                </GlassCard>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="section-pad bg-white/50">
        <div className="shell-container">
          <SectionHeading
            eyebrow="Empat Keterampilan"
            title="Seimbang, bukan hanya percakapan"
            description="Setiap sesi menyentuh empat keterampilan utama sehingga murid siap menghadapi soal HSK maupun kebutuhan komunikasi nyata."
          />
          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {skills.map((skill) => (
              <div key={skill.title} className="card-surface p-6 text-center">
                <p className="font-cjk text-4xl text-brand-600">{skill.hanzi}</p>
                <h3 className="mt-3 text-base font-bold text-ink-900">
                  {skill.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">
                  {skill.description}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <span className="text-sm font-semibold text-ink-500">
              Komponen pendukung:
            </span>
            {support.map((item) => (
              <span
                key={item}
                className="rounded-full border border-brand-200 bg-white/70 px-3.5 py-1.5 text-sm font-semibold text-brand-700"
              >
                {item}
              </span>
            ))}
          </div>
        </div>
      </section>

      <VideoSection />

      <CtaSection />
    </>
  );
}
