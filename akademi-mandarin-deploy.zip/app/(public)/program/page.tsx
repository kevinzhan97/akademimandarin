import type { Metadata } from "next";
import { HskPathSection } from "@/components/public/HskPathSection";
import { ProgramShowcase } from "@/components/public/ProgramShowcase";
import { CtaSection, PublicPageHeader } from "@/components/public/Sections";
import { getPublicPrograms } from "@/lib/queries/public";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Program Belajar Mandarin",
  description:
    "Program Akademi Mandarin: Basic (Pre-HSK 1), Beginner (HSK 1), Intermediate (HSK 2), Professional (HSK 3 Path), dan Advance (HSK 4 Path).",
  alternates: { canonical: "/program" },
};

export default async function ProgramPage() {
  const programs = await getPublicPrograms();

  return (
    <>
      <PublicPageHeader
        eyebrow="Program"
        hanzi="程"
        title="Lima tahap belajar, dari nol sampai siap ujian HSK"
        description="Pilih titik mulai sesuai kemampuan Anda. Setiap program memiliki target kosakata, latihan hanzi, dan evaluasi empat keterampilan yang jelas."
      />

      <ProgramShowcase programs={programs} heading={false} />

      <HskPathSection />

      <CtaSection />
    </>
  );
}
