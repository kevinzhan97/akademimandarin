import { Footer } from "@/components/public/Footer";
import { Navbar } from "@/components/Navbar";
import { ROLE_HOME } from "@/lib/rbac";
import { getSessionUser } from "@/lib/session";

export default async function PublicLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const user = await getSessionUser();

  return (
    <div className="app-shell-bg flex min-h-screen flex-col">
      <Navbar
        user={
          user
            ? { fullName: user.fullName, dashboardHref: ROLE_HOME[user.role] }
            : null
        }
      />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
