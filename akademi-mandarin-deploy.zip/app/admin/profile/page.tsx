import { ProfilePanel } from "@/components/dashboard/ProfilePanel";
import { requireRole } from "@/lib/auth";

export default async function AdminProfilePage() {
  await requireRole("ADMIN");

  return (
    <ProfilePanel subtitle="Kelola data akun administrator dan keamanan portal Akademi Mandarin." />
  );
}
