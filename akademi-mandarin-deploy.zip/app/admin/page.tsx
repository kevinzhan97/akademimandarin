import { Badge, statusTone } from "@/components/ui/Badge";
import { Card, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/Feedback";
import { PageHeader } from "@/components/ui/PageHeader";
import { ProgressBar, StatCard } from "@/components/ui/StatCard";
import { requireRole } from "@/lib/auth";
import { getAdminDashboard } from "@/lib/queries/dashboards";
import { formatCurrency, formatDate, humanizeEnum } from "@/lib/utils";

export default async function AdminDashboardPage() {
  await requireRole("ADMIN");
  const data = await getAdminDashboard();

  return (
    <>
      <PageHeader
        eyebrow="Overview"
        title="Dashboard Administrator"
        description="Ringkasan penuh Akademi Mandarin: murid, tim, kelas berjalan, dan kondisi keuangan."
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Murid"
          value={data.counters.totalStudents}
          hint={`${data.counters.activeStudents} murid aktif`}
          icon="graduation"
        />
        <StatCard
          label="Guru / Buzzer"
          value={`${data.counters.teachers} / ${data.counters.buzzers}`}
          hint="Akun tim aktif"
          icon="teacher"
          tone="jade"
        />
        <StatCard
          label="Kelas Aktif"
          value={data.counters.activeClasses}
          hint={`${data.counters.upcomingClasses} kelas mulai ≤7 hari`}
          icon="bookOpen"
        />
        <StatCard
          label="Lead Baru"
          value={data.counters.newLeads}
          hint={`Total ${data.counters.totalLeads} lead di CRM`}
          icon="target"
          tone="gold"
        />
        <StatCard
          label="Pendapatan Bulan Ini"
          value={formatCurrency(data.finance.revenueThisMonth)}
          hint="Pembayaran berstatus PAID"
          tone="jade"
          icon="wallet"
        />
        <StatCard
          label="Pembayaran Tertunda"
          value={formatCurrency(data.finance.outstanding)}
          hint="Status pending & overdue"
          tone="gold"
          icon="receipt"
        />
        <StatCard
          label="Progres Belajar"
          value={`${data.learning.averageMastery}%`}
          hint="Rata-rata mastery HSK murid"
          icon="chart"
        />
        <StatCard
          label="Enrollment Menunggu"
          value={data.pendingEnrollments.length}
          hint="Perlu ditindaklanjuti"
          icon="clipboard"
        />
      </div>

      <div className="mt-6 grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader
            title="Lead terbaru"
            description="Calon murid dari formulir website dan kanal lainnya"
          />
          {data.recentLeads.length === 0 ? (
            <EmptyState
              icon="target"
              title="Belum ada lead"
              description="Lead dari formulir website akan muncul di sini otomatis."
            />
          ) : (
            <ul className="divide-y divide-ink-900/6">
              {data.recentLeads.map((lead) => (
                <li
                  key={lead.id}
                  className="flex items-start justify-between gap-3 py-3"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-ink-900">
                      {lead.name}
                    </p>
                    <p className="mt-0.5 text-xs text-ink-500">
                      {lead.phone} · {lead.program?.name ?? "Program belum dipilih"}
                    </p>
                    <p className="mt-0.5 text-[0.7rem] text-ink-400">
                      {formatDate(lead.createdAt)} ·{" "}
                      {lead.assignedTo?.fullName ?? "Belum ada penanggung jawab"}
                    </p>
                  </div>
                  <Badge tone={statusTone(lead.status)}>
                    {humanizeEnum(lead.status)}
                  </Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card>
          <CardHeader
            title="Jadwal kelas aktif"
            description="Slot jadwal mingguan yang sedang berjalan"
          />
          {data.upcomingSchedules.length === 0 ? (
            <EmptyState
              icon="calendar"
              title="Belum ada jadwal aktif"
              description="Buat kelas lalu tambahkan slot jadwal mingguan."
            />
          ) : (
            <ul className="divide-y divide-ink-900/6">
              {data.upcomingSchedules.map((schedule) => (
                <li
                  key={schedule.id}
                  className="flex items-center justify-between gap-3 py-3"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-ink-900">
                      {schedule.class.name}
                    </p>
                    <p className="mt-0.5 text-xs text-ink-500">
                      {humanizeEnum(schedule.dayOfWeek)} · {schedule.startTime}–
                      {schedule.endTime}
                    </p>
                  </div>
                  <span className="text-right text-xs text-ink-500">
                    {schedule.teacher?.user.fullName ?? "Guru belum ditentukan"}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card className="mt-5">
        <CardHeader
          title="Progres belajar keseluruhan"
          description="Rata-rata penguasaan materi HSK murid"
        />
        <ProgressBar
          value={data.learning.averageMastery}
          label="Mastery HSK"
          hint={`${data.learning.averageMastery}%`}
        />
      </Card>

    </>
  );
}
