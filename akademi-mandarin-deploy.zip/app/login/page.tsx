import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import { LoginForm } from "@/app/login/LoginForm";
import { Icon } from "@/components/ui/Icon";
import { ROLE_HOME } from "@/lib/rbac";
import { getSessionUser } from "@/lib/session";

export const metadata: Metadata = {
  title: "Login Portal",
  description:
    "Portal login Akademi Mandarin untuk murid, guru, buzzer, dan administrator.",
  robots: { index: false, follow: false },
  alternates: { canonical: "/login" },
};

const roleHighlights = [
  { role: "Murid", detail: "Materi, kuis, tugas, jadwal, progres HSK" },
  { role: "Guru", detail: "Kelas, penilaian, kehadiran, materi ajar" },
  { role: "Buzzer", detail: "Koordinasi jadwal, kelas, guru, dan murid" },
  { role: "Admin", detail: "CRM, akademi, konten, dan pengaturan sistem" },
];

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect(ROLE_HOME[user.role]);

  const showDemoHint = process.env.NODE_ENV !== "production";

  return (
    <div className="app-shell-bg flex min-h-screen items-center justify-center px-4 py-12">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-[2.5rem] border border-white/70 bg-white/60 shadow-[var(--shadow-glass)] backdrop-blur-xl lg:grid-cols-2">
        <div className="relative hidden flex-col justify-between bg-gradient-to-br from-ink-900 via-brand-800 to-brand-600 p-10 text-white lg:flex">
          <div className="brand-ribbon pointer-events-none absolute -top-10 -left-10 h-40 w-[30rem] rotate-12 opacity-40" />
          <div className="relative">
            <Link href="/" className="flex items-center">
              <Image
                src="/logo.png"
                alt="Akademi Mandarin"
                width={44}
                height={44}
                className="size-11 rounded-2xl object-contain"
              />
            </Link>

            <p className="font-cjk mt-10 text-4xl leading-none text-white/90">学习</p>
            <h1 className="mt-4 text-3xl font-extrabold text-white">
              Satu portal untuk seluruh perjalanan belajar
            </h1>
            <p className="mt-4 text-sm leading-relaxed text-white/80">
              Masuk untuk mengakses kelas, materi, tugas, kehadiran, dan progres HSK
              Anda. Setiap peran memiliki ruang kerja masing-masing.
            </p>
          </div>

          <ul className="relative mt-10 space-y-3">
            {roleHighlights.map((item) => (
              <li key={item.role} className="flex items-start gap-3 text-sm">
                <Icon name="checkCircle" size={17} className="mt-0.5 text-jade-400" />
                <span>
                  <span className="font-bold text-white">{item.role}</span>
                  <span className="text-white/75"> — {item.detail}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="p-8 sm:p-10">
          <div className="mb-8 lg:hidden">
            <Link href="/" className="flex items-center">
              <Image
                src="/logo.png"
                alt="Akademi Mandarin"
                width={40}
                height={40}
                className="size-10 rounded-2xl object-contain"
              />
            </Link>
          </div>

          <h2 className="text-2xl font-extrabold text-ink-900">Masuk ke portal</h2>
          <p className="mt-1.5 mb-6 text-sm text-ink-500">
            Gunakan akun yang diberikan administrator Akademi Mandarin.
          </p>

          <LoginForm />

          {showDemoHint ? (
            <div className="mt-6 rounded-2xl border border-dashed border-amber-300 bg-amber-50 p-4 text-xs leading-relaxed text-amber-800">
              <p className="font-bold">Mode pengembangan</p>
              <p className="mt-1">
                Akun demo (hanya tersedia setelah <code>npm run db:seed</code>):{" "}
                <code>demo_admin</code>, <code>demo_teacher</code>,{" "}
                <code>demo_buzzer</code>, <code>demo_student</code>.
              </p>
            </div>
          ) : null}

          <p className="mt-6 text-center text-xs text-ink-400">
            <Link
              href="/"
              className="font-semibold text-brand-600 underline decoration-brand-300 underline-offset-4"
            >
              Kembali ke website Akademi Mandarin
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
