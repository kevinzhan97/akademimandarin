"use client";

import { useActionState } from "react";
import { Alert } from "@/components/ui/Feedback";
import { Field, Input } from "@/components/ui/Form";
import { SubmitButton } from "@/components/ui/SubmitButton";
import { loginAction } from "@/lib/actions/auth";
import { idleFormState } from "@/types/forms";

export function LoginForm() {
  const [state, formAction] = useActionState(loginAction, idleFormState);

  return (
    <form action={formAction} className="space-y-4" noValidate>
      {state.status === "error" && state.message ? (
        <Alert tone="error">{state.message}</Alert>
      ) : null}

      <Field
        label="Username atau email"
        htmlFor="identifier"
        required
        error={state.errors?.identifier}
      >
        <Input
          id="identifier"
          name="identifier"
          autoComplete="username"
          placeholder="username Anda"
          required
        />
      </Field>

      <Field label="Password" htmlFor="password" required error={state.errors?.password}>
        <Input
          id="password"
          name="password"
          type="password"
          autoComplete="current-password"
          placeholder="••••••••"
          required
        />
      </Field>

      <SubmitButton pendingLabel="Memproses..." className="w-full">
        Masuk
      </SubmitButton>

      <p className="text-center text-xs leading-relaxed text-ink-400">
        Akun portal dibuat oleh administrator Akademi Mandarin. Bila Anda lupa
        password, hubungi tim kami untuk pengaturan ulang.
      </p>
    </form>
  );
}
