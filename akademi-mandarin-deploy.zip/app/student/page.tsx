import { ListCard } from "@/components/dashboard/ListCard";
import { statusTone } from "@/components/ui/Badge";
import { Card, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/Feedback";
import { PageHeader } from "@/components/ui/PageHeader";
import { ProgressBar, StatCard } from "@/components/ui/StatCard";
import { requireRole } from "@/lib/auth";
import { getStudentDashboard } from "@/lib/queries/dashboards";
import { formatDate, humanizeEnum } from "@/lib/utils";

export default async function StudentDashboardPage() {
  const user = await requireRole("STUDENT", "ADMIN");
  const data = await getStudentDashboard(user.id);

  if (!data) {
    return (
      <>
        <PageHeader eyebrow="Dashboard" title="Ruang Belajar" />
        <EmptyState
          icon="graduation"
          title="Profil murid belum dibuat"
          description="Akun Anda belum terhubung dengan data murid. Hubungi administrator Akademi Mandarin."
        />
      </>
    );
  }

  const { student, counters } = data;
  const nextSchedules = data.classLinks.flatMap((link) =>
    link.class.schedules.map((schedule) => ({
      id: `${link.class.id}-${schedule.id}`,
      title: link.class.name,
      meta: `${humanizeEnum(schedule.dayOfWeek)} · ${schedule.startTime}–${schedule.endTime}`,
      trailing: link.class.teacher?.user.fullName ?? "Guru belum ditentukan",
    })),
  );
  const currentHsk = data.hskProgress.at(-1);
  const skillRows = currentHsk
    ? [
        { label: "Mendengar (听)", value: currentHsk.listening },
        { label: "Berbicara (说)", value: currentHsk.speaking },
        { label: "Membaca (读)", value: currentHsk.reading },
        { label: "Menulis (写)", value: currentHsk.writing },
        { label: "Kosakata", value: currentHsk.vocabulary },
      ]
    : [];

  return (
    <>
      <PageHeader
        eyebrow="Dashboard"
        title={`Selamat belajar, ${user.fullName.split(" ")[0]}`}
        description="Ini ringkasan perjalanan belajar Mandarin Anda hari ini."
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Program Saat Ini"
          value={student.program?.name ?? "-"}
          hint={student.program?.hskLabel ?? "Program belum ditentukan"}
          icon="bookOpen"
        />
        <StatCard
          label="Kelas Aktif"
          value={counters.classes}
          hint={`${counters.publishedLessons} materi tersedia`}
          icon="users"
          tone="jade"
        />
        <StatCard
          label="Tugas Belum Dikumpul"
          value={counters.pendingAssignments}
          icon="clipboard"
          tone="gold"
        />
        <StatCard
          label="Kehadiran"
          value={`${counters.attendanceRate}%`}
          hint="Dari 20 pertemuan terakhir"
          icon="checkCircle"
        />
      </div>

      <div className="mt-6 grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader
            title="Progres HSK"
            description={
              currentHsk
                ? `Level terakhir: ${currentHsk.levelCode}`
                : "Belum ada catatan progres HSK"
            }
          />
          {skillRows.length === 0 ? (
            <EmptyState
              icon="award"
              title="Progres belum dinilai"
              description="Guru Anda akan mengisi penilaian tiap keterampilan setelah evaluasi."
            />
          ) : (
            <div className="space-y-4">
              {skillRows.map((skill) => (
                <ProgressBar
                  key={skill.label}
                  label={skill.label}
                  value={skill.value}
                />
              ))}
              {currentHsk ? (
                <div className="rounded-2xl bg-brand-50 px-4 py-3 text-sm text-brand-700">
                  Mastery keseluruhan: <strong>{currentHsk.masteryPercent}%</strong> ·
                  status {humanizeEnum(currentHsk.status)}
                </div>
              ) : null}
            </div>
          )}
        </Card>
        <ListCard
          title="Jadwal kelas saya"
          description="Pertemuan rutin mingguan"
          actionLabel="Jadwal lengkap"
          emptyIcon="calendar"
          emptyTitle="Belum ada jadwal kelas"
          emptyDescription="Jadwal akan muncul setelah Anda ditempatkan ke kelas."
          items={nextSchedules}
        />

        <ListCard
          title="Hasil kuis terakhir"
          description="Riwayat percobaan kuis Anda"
          actionLabel="Semua kuis"
          emptyIcon="quiz"
          emptyTitle="Belum ada kuis dikerjakan"
          items={data.attempts.map((attempt) => ({
            id: attempt.id,
            title: attempt.quiz.title,
            meta: `${humanizeEnum(attempt.quiz.type)} · ${formatDate(attempt.startedAt)}`,
            badge: {
              label:
                attempt.score !== null
                  ? String(Number(attempt.score))
                  : humanizeEnum(attempt.status),
              tone: statusTone(attempt.status),
            },
          }))}
        />

        <ListCard
          title="Tugas terakhir"
          description="Status pengumpulan tugas Anda"
          actionLabel="Semua tugas"
          emptyIcon="clipboard"
          emptyTitle="Belum ada tugas dikumpulkan"
          items={data.submissions.map((submission) => ({
            id: submission.id,
            title: submission.assignment.title,
            meta: `Dikumpulkan ${formatDate(submission.submittedAt)}`,
            badge: {
              label: humanizeEnum(submission.status),
              tone: statusTone(submission.status),
            },
          }))}
        />
      </div>

      <Card className="mt-5">
        <CardHeader
          title="Lanjutkan belajar"
          description="Pilih menu di bilah samping untuk membuka materi, kamus, dan alat belajar lainnya."
        />
      </Card>

    </>
  );
}
