import { ProfilePanel } from "@/components/dashboard/ProfilePanel";
import { requireRole } from "@/lib/auth";

export default async function StudentProfilePage() {
  await requireRole("STUDENT", "ADMIN");

  return (
    <ProfilePanel subtitle="Kelola data kontak akun belajar Anda agar guru mudah menghubungi." />
  );
}
