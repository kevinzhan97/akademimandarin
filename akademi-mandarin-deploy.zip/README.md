# Akademi Mandarin

Satu aplikasi terintegrasi untuk **Company Profile + LMS + CRM** Akademi Mandarin.
Dibangun dengan Next.js (App Router), React, TypeScript, Node.js, MySQL, dan Prisma ORM.

- Domain produksi: `https://akademimandarin.my.id`
- Target hosting: **Hostinger Business Web Hosting (Node.js)**
- Alur deploy: Local → GitHub → Hostinger Node.js → Build → Live

> Tidak ada WordPress, tidak ada PHP, tidak ada tema/plugin WordPress di repositori ini.

---

## 1. Fitur yang sudah berjalan

| Area | Status | Rute |
| --- | --- | --- |
| Company profile (premium, responsif) | ✅ | `/`, `/tentang-kami`, `/program`, `/mengapa-mandarin`, `/metode-belajar`, `/hsk-path`, `/faq`, `/mulai-sekarang` |
| Lead capture website → CRM | ✅ (menyimpan ke tabel `Leads`) | `/mulai-sekarang` |
| Autentikasi + sesi database | ✅ | `/login` |
| Otorisasi berbasis peran (server-side) | ✅ | `/admin`, `/teacher`, `/buzzer`, `/student` |
| Dashboard Admin (statistik nyata dari MySQL) | ✅ | `/admin` |
| Dashboard Guru (kelas, jadwal, antrean penilaian) | ✅ | `/teacher` |
| Dashboard Buzzer (koordinasi kelas & jadwal) | ✅ | `/buzzer` |
| Dashboard Murid (program, progres HSK, tugas) | ✅ | `/student` |
| Profil + ganti password (semua peran) | ✅ | `/*/profile` |
| SEO teknis (metadata, OG, sitemap, robots, JSON-LD) | ✅ | `/sitemap.xml`, `/robots.txt` |
| Keamanan (bcrypt, sesi HMAC, rate limit login, header keamanan) | ✅ | — |

Modul CRUD lanjutan (CRM penuh, LMS penuh, konten, sistem) dibangun bertahap sesuai
fase pengembangan; menu dashboard hanya menampilkan halaman yang sudah benar-benar ada.

---

## 2. Peran pengguna

Hanya ada empat peran, **tanpa registrasi publik** (`/login` hanya untuk akun yang
dibuat admin):

| Peran | Halaman awal | Fokus |
| --- | --- | --- |
| `ADMIN` | `/admin` | Akses penuh: CRM, akademi, konten, sistem |
| `TEACHER` | `/teacher` | Pengajaran, penilaian, kehadiran, progres murid |
| `BUZZER` | `/buzzer` | Koordinasi jadwal, kelas, guru, dan murid |
| `STUDENT` | `/student` | Pembelajaran: kursus, kuis, tugas, progres HSK |

Otorisasi diperiksa **di server** pada setiap layout, halaman, server action, dan route
handler melalui `lib/auth.ts` (`requireUser`, `requireRole`, `requireApiRole`).

---

## 3. Persyaratan

- Node.js **20.9+** (dites pada Node 24)
- MySQL 8 / MariaDB (lokal atau di Hostinger)
- npm 10+

---

## 4. Setup lokal

```bash
# 1. Install dependency (menjalankan prisma generate otomatis)
npm install

# 2. Siapkan environment
cp .env.example .env     # Windows: copy .env.example .env
# lalu isi DATABASE_URL dan AUTH_SECRET

# 3. Buat skema database
npm run db:migrate       # development (membuat file migrasi + apply)
# atau, tanpa file migrasi:
npm run db:push

# 4. Isi data demo (opsional, hanya untuk pengembangan)
npm run db:seed

# 5. Jalankan
npm run dev              # http://localhost:3000
```

### Akun demo (hasil `npm run db:seed`)

| Peran | Username | Password |
| --- | --- | --- |
| Admin | `demo_admin` | nilai `SEED_DEMO_PASSWORD` |
| Guru | `demo_teacher` | nilai `SEED_DEMO_PASSWORD` |
| Buzzer | `demo_buzzer` | nilai `SEED_DEMO_PASSWORD` |
| Murid | `demo_student` | nilai `SEED_DEMO_PASSWORD` |

`npm run db:seed` **menghapus** data dan menolak berjalan bila `NODE_ENV=production`
(kecuali `SEED_ALLOW_PRODUCTION=1`). Jangan dijalankan di produksi.

---

## 5. Environment variables

Semua nilai dijelaskan di `.env.example`. Tidak ada kredensial yang di-hardcode.

| Variabel | Wajib | Keterangan |
| --- | --- | --- |
| `DATABASE_URL` | ✅ | Koneksi MySQL untuk Prisma |
| `AUTH_SECRET` | ✅ | Minimal 32 karakter; dipakai untuk HMAC token sesi |
| `AUTH_SESSION_TTL_DAYS` | — | Umur sesi (default `7`) |
| `AUTH_MAX_LOGIN_ATTEMPTS` | — | Batas percobaan login gagal (default `5`) |
| `AUTH_LOCK_MINUTES` | — | Jendela penguncian (default `15`) |
| `NEXT_PUBLIC_SITE_URL` | ✅ | Domain produksi, tanpa `localhost` |
| `NEXT_PUBLIC_SITE_NAME` | — | Nama situs |
| `NEXT_PUBLIC_CONTACT_WHATSAPP` | — | Nomor WhatsApp publik (format `62...`) |
| `NEXT_PUBLIC_CONTACT_EMAIL`, `NEXT_PUBLIC_CONTACT_PHONE` | — | Kontak publik |
| `NEXT_PUBLIC_PROMO_VIDEO_ID` | — | ID video YouTube untuk section "Tonton Video" |
| `SEED_DEMO_PASSWORD` | — | Password akun demo (khusus pengembangan) |
| `PANDA_AI_API_KEY`, `PANDA_AI_BASE_URL`, `PANDA_AI_MODEL` | — | Titik integrasi Panda AI (opsional) |

Generate `AUTH_SECRET`:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

---

## 6. Scripts

| Perintah | Fungsi |
| --- | --- |
| `npm run dev` | Development server |
| `npm run build` | `prisma generate` + `next build` (produksi) |
| `npm start` | Menjalankan hasil build (`next start`) |
| `npm run lint` | ESLint |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run db:generate` | Generate Prisma Client |
| `npm run db:migrate` | Buat + terapkan migrasi (development) |
| `npm run db:deploy` | Terapkan migrasi yang sudah ada (produksi) |
| `npm run db:push` | Sinkronkan skema tanpa file migrasi |
| `npm run db:seed` | Data demo + akun demo |
| `npm run db:studio` | Prisma Studio |
| `npm run db:sql` | Cetak SQL penuh dari `prisma/schema.prisma` |

---

## 7. Deploy ke Hostinger Business (Node.js)

1. Push repositori ke GitHub. Pastikan `.env` **tidak** ter-commit (sudah ada di
   `.gitignore`).
2. Di hPanel: **Advanced → Node.js** → buat aplikasi Node.js baru.
   - Node version: 20 atau 22
   - Application root: folder repositori Anda
   - Start command: `npm start` (startup file dapat diarahkan ke Node.js app runner
     hPanel)
3. Tambahkan environment variables di hPanel (`DATABASE_URL`, `AUTH_SECRET`,
   `NEXT_PUBLIC_SITE_URL`, dst.) — jangan mengandalkan file `.env` di server.
4. Buat database MySQL di hPanel, lalu susun `DATABASE_URL`:

   ```
   mysql://USER:PASSWORD@localhost:3306/NAMA_DATABASE
   ```

5. Install, migrasi, dan build (terminal SSH atau menu Node.js → Run NPM):

   ```bash
   npm install
   npm run db:deploy   # menerapkan migrasi ke MySQL Hostinger
   npm run build
   ```

6. Restart aplikasi Node dari hPanel, lalu buka domain produksi.
7. Buat akun admin pertama dengan salah satu cara: jalankan seed di lingkungan
   non-produksi, atau tambahkan baris `Users` manual dengan hash bcrypt
   (lihat `lib/password.ts`) dan `roleId` milik peran `ADMIN`.

Catatan kompatibilitas:

- Tidak memakai Docker, Redis, atau microservice.
- `prisma generate` berjalan otomatis lewat `postinstall` dan `npm run build`.
- Halaman publik dan dashboard dirender per request, sehingga perubahan data langsung
  terlihat tanpa build ulang.


---

## 8. Struktur proyek

```
app/
  (public)/            # company profile (beranda, program, FAQ, dst.)
  login/               # autentikasi
  admin/ teacher/ buzzer/ student/   # dashboard per peran + layout otorisasi
  robots.ts sitemap.ts # SEO teknis
components/
  ui/                  # Button, Card, Badge, Form, DataTable, Modal, Icon, ...
  public/              # Navbar, Footer, Hero, ProgramShowcase, HskPath, LeadForm
  dashboard/           # DashboardShell, Sidebar, ListCard, ProfilePanel, ProfileForms
lib/
  prisma.ts env.ts auth.ts session.ts password.ts rbac.ts dashboard.ts rate-limit.ts
  validators.ts utils.ts site.ts content.ts
  actions/             # server actions (auth, account)
  queries/             # query Prisma untuk halaman publik & dashboard
prisma/
  schema.prisma        # 30 model (identitas, akademi, LMS, CRM, sistem)
  seed.ts              # data demo
types/                 # tipe bersama (auth, forms)
```

---

## 9. Keamanan

- Password di-hash dengan bcrypt (cost 12); tidak pernah disimpan sebagai plaintext.
- Sesi disimpan di database: token acak 256-bit, hanya HMAC-nya yang tersimpan.
- Cookie sesi `httpOnly`, `sameSite=lax`, `secure` di produksi.
- Setiap rute dashboard memverifikasi: sesi valid → akun `ACTIVE` → peran berwenang.
- Rate limit login berbasis database (per identifier) + pencatatan `LoginAttempts`.
- Validasi input dengan Zod di setiap server action.
- Prisma parameterized query (aman terhadap SQL injection).
- Header keamanan (`X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`,
  `Permissions-Policy`) diatur di `next.config.ts`.
- Kredensial hanya di environment variables; `.env` diabaikan Git.

---

## 10. Roadmap fase berikutnya

1. **Admin CRUD**: Users, Students, Teachers, Buzzers, Classes, Schedule, Attendance,
   HSK Progress (halaman + server action + validasi).
2. **CRM**: Leads, Customers, Follow-ups, Enrollments, Payments, Reports + konversi
   lead → customer → enrollment → akun murid.
3. **LMS**: Courses, Lessons, Materials, Quizzes, Questions, Attempts, Assignments,
   Submissions beserta penilaian.
4. **Konten**: Vocabulary, Hanzi, Audio, Materials, HSK (CRUD admin).
5. **Tools murid**: Kamus, Hanzi & urutan goresan, latihan, Panda AI.
6. **Buzzer penuh**: penugasan guru, perubahan jadwal, ketersediaan pengajar.
7. **Testing**: autentikasi/otorisasi/CRUD, uji responsif, uji build produksi.

Menu dashboard ditambahkan bersamaan dengan halaman nyata pada tiap fase, sehingga tidak
pernah ada tautan mati atau halaman "Coming Soon".
