/**
 * Development seed for Akademi Mandarin.
 * Creates roles, demo accounts (one per role), the full HSK program structure,
 * curriculum content, classes, CRM records, and system settings.
 *
 * IMPORTANT: this wipes existing rows so it can be re-run safely in development.
 * It refuses to run in production unless SEED_ALLOW_PRODUCTION=1.
 *
 * Run with: npm run db:seed
 */
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../lib/password";

const prisma = new PrismaClient();

const DEMO_PASSWORD = process.env.SEED_DEMO_PASSWORD || "AkademiMandarin123!";

async function wipe() {
  if (process.env.NODE_ENV === "production" && process.env.SEED_ALLOW_PRODUCTION !== "1") {
    throw new Error(
      "Seed dihentikan: NODE_ENV=production. Set SEED_ALLOW_PRODUCTION=1 bila memang ingin mengisi data demo.",
    );
  }

  // Deletion order respects foreign keys (Restrict relations last).
  await prisma.notification.deleteMany();
  await prisma.attendance.deleteMany();
  await prisma.submission.deleteMany();
  await prisma.quizAttempt.deleteMany();
  await prisma.question.deleteMany();
  await prisma.quiz.deleteMany();
  await prisma.assignment.deleteMany();
  await prisma.material.deleteMany();
  await prisma.audioAsset.deleteMany();
  await prisma.vocabulary.deleteMany();
  await prisma.hanzi.deleteMany();
  await prisma.schedule.deleteMany();
  await prisma.classStudent.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.enrollment.deleteMany();
  await prisma.hSKProgress.deleteMany();
  await prisma.followUp.deleteMany();
  await prisma.student.deleteMany();
  await prisma.customer.deleteMany();
  await prisma.class.deleteMany();
  await prisma.lead.deleteMany();
  await prisma.session.deleteMany();
  await prisma.loginAttempt.deleteMany();
  await prisma.user.deleteMany();
  await prisma.course.deleteMany();
  await prisma.lesson.deleteMany();
  await prisma.level.deleteMany();
  await prisma.program.deleteMany();
  await prisma.role.deleteMany();
  await prisma.setting.deleteMany();
}

async function seedRoles() {
  const roles = [
    { code: "ADMIN", name: "Administrator", description: "Akses penuh ke seluruh sistem." },
    { code: "TEACHER", name: "Guru", description: "Pengajaran, penilaian, dan progres murid." },
    { code: "BUZZER", name: "Buzzer", description: "Koordinasi jadwal, kelas, guru, dan murid." },
    { code: "STUDENT", name: "Murid", description: "Akses pembelajaran dan progres." },
  ];

  const map: Record<string, number> = {};
  for (const role of roles) {
    const created = await prisma.role.create({ data: role });
    map[role.code] = created.id;
  }
  return map;
}

async function seedUsers(roleIds: Record<string, number>) {
  const passwordHash = await hashPassword(DEMO_PASSWORD);

  const admin = await prisma.user.create({
    data: {
      username: "demo_admin",
      email: "demo_admin@akademimandarin.my.id",
      passwordHash,
      fullName: "Admin Demo",
      phone: "081200000001",
      roleId: roleIds.ADMIN!,
      status: "ACTIVE",
    },
  });

  const teacherUser = await prisma.user.create({
    data: {
      username: "demo_teacher",
      email: "demo_teacher@akademimandarin.my.id",
      passwordHash,
      fullName: "Laoshi Mei Ling",
      phone: "081200000002",
      roleId: roleIds.TEACHER!,
      status: "ACTIVE",
    },
  });

  const buzzerUser = await prisma.user.create({
    data: {
      username: "demo_buzzer",
      email: "demo_buzzer@akademimandarin.my.id",
      passwordHash,
      fullName: "Rani Koordinator",
      phone: "081200000003",
      roleId: roleIds.BUZZER!,
      status: "ACTIVE",
    },
  });

  const studentUser = await prisma.user.create({
    data: {
      username: "demo_student",
      email: "demo_student@akademimandarin.my.id",
      passwordHash,
      fullName: "Budi Santoso",
      phone: "081200000004",
      roleId: roleIds.STUDENT!,
      status: "ACTIVE",
    },
  });

  const teacher = await prisma.teacher.create({
    data: {
      userId: teacherUser.id,
      employeeNo: "AM-T-001",
      specialization: "HSK Preparation & Business Mandarin",
      bio: "Pengajar Mandarin dengan pengalaman 8 tahun, fokus persiapan HSK dan Mandarin bisnis.",
      phone: "081200000002",
      status: "ACTIVE",
    },
  });

  const buzzer = await prisma.buzzer.create({
    data: {
      userId: buzzerUser.id,
      employeeNo: "AM-B-001",
      region: "Jabodetabek",
      phone: "081200000003",
      notes: "Mengelola koordinasi jadwal kelas online dan tatap muka.",
      status: "ACTIVE",
    },
  });

  return { admin, teacher, buzzer, studentUser };
}

type ProgramSeed = { programId: number; code: string; slug: string; levelId: number; levelCode: string; price: number };

async function seedPrograms(): Promise<ProgramSeed[]> {
  const definitions = [
    {
      code: "BASIC",
      name: "Basic",
      slug: "basic",
      hskLabel: "Pre-HSK 1",
      tagline: "Fondasi pinyin, nada, dan 150 kosakata pertama",
      description: "Untuk pemula total: pinyin, empat nada, sapaan, angka, dan goresan hanzi dasar.",
      durationMonths: 3,
      priceMonthly: 650000,
      order: 1,
      levels: [{ code: "PRE-HSK-1", name: "Pre-HSK 1", vocabularyTarget: 150, hanziTarget: 40 }],
    },
    {
      code: "BEGINNER",
      name: "Beginner",
      slug: "beginner",
      hskLabel: "HSK 1",
      tagline: "Kalimat dasar untuk percakapan sehari-hari",
      description: "Menguasai 150 kata inti HSK 1, menyusun kalimat sederhana, dan membaca hanzi dasar.",
      durationMonths: 3,
      priceMonthly: 700000,
      order: 2,
      levels: [{ code: "HSK-1", name: "HSK 1", vocabularyTarget: 150, hanziTarget: 80 }],
    },
    {
      code: "INTERMEDIATE",
      name: "Intermediate",
      slug: "intermediate",
      hskLabel: "HSK 2",
      tagline: "Percakapan rutin dengan tata bahasa lanjutan",
      description: "300 kata HSK 2, tata bahasa lanjutan, dan menulis kalimat lengkap.",
      durationMonths: 4,
      priceMonthly: 750000,
      order: 3,
      levels: [{ code: "HSK-2", name: "HSK 2", vocabularyTarget: 300, hanziTarget: 150 }],
    },
    {
      code: "PROFESSIONAL",
      name: "Professional",
      slug: "professional",
      hskLabel: "HSK 3 Path",
      tagline: "Kurikulum intensif 3A → 3B",
      description: "Persiapan HSK 3 dengan segmen internal 3A/3B: 600 kata, diskusi topik, menulis paragraf.",
      durationMonths: 6,
      priceMonthly: 850000,
      order: 4,
      levels: [
        { code: "HSK-3A", name: "HSK 3A (segmen internal)", vocabularyTarget: 400, hanziTarget: 220 },
        { code: "HSK-3B", name: "HSK 3B (segmen internal)", vocabularyTarget: 600, hanziTarget: 300 },
      ],
    },
    {
      code: "ADVANCE",
      name: "Advance",
      slug: "advance",
      hskLabel: "HSK 4 Path",
      tagline: "Kurikulum intensif 4A → 4B",
      description: "Persiapan HSK 4 dengan segmen internal 4A/4B: 1.200 kata, presentasi, dan esai.",
      durationMonths: 8,
      priceMonthly: 950000,
      order: 5,
      levels: [
        { code: "HSK-4A", name: "HSK 4A (segmen internal)", vocabularyTarget: 900, hanziTarget: 450 },
        { code: "HSK-4B", name: "HSK 4B (segmen internal)", vocabularyTarget: 1200, hanziTarget: 600 },
      ],
    },
  ];

  const lessonTitles = [
    "Peta Belajar & Target Level",
    "Pinyin dan Empat Nada",
    "Latihan Kosakata Inti",
  ];

  const result: ProgramSeed[] = [];

  for (const definition of definitions) {
    const program = await prisma.program.create({
      data: {
        code: definition.code as never,
        name: definition.name,
        slug: definition.slug,
        hskLabel: definition.hskLabel,
        tagline: definition.tagline,
        description: definition.description,
        durationMonths: definition.durationMonths,
        priceMonthly: definition.priceMonthly,
        order: definition.order,
        isPublished: true,
      },
    });

    const levels = [];
    for (const [index, level] of definition.levels.entries()) {
      levels.push(
        await prisma.level.create({
          data: {
            programId: program.id,
            code: level.code,
            name: level.name,
            order: index + 1,
            vocabularyTarget: level.vocabularyTarget,
            hanziTarget: level.hanziTarget,
            description: `Target ${level.vocabularyTarget} kosakata dan ${level.hanziTarget} hanzi.`,
          },
        }),
      );
    }

    const firstLevel = levels[0]!;
    const course = await prisma.course.create({
      data: {
        programId: program.id,
        levelId: firstLevel.id,
        title: `Kursus ${definition.name} (${definition.hskLabel})`,
        slug: `kursus-${definition.slug}`,
        description: `Materi inti program ${definition.name} mengikuti silabus ${definition.hskLabel}.`,
        order: 1,
        isPublished: true,
      },
    });

    for (const [index, title] of lessonTitles.entries()) {
      await prisma.lesson.create({
        data: {
          courseId: course.id,
          order: index + 1,
          title,
          slug: `${definition.slug}-${index + 1}`,
          summary: `${title} untuk level ${definition.hskLabel}.`,
          contentMd: `## ${title}\n\nMateri ${definition.name} (${definition.hskLabel}).\n\n- 听 Mendengar\n- 说 Berbicara\n- 读 Membaca\n- 写 Menulis`,
          objectives: "Menguasai kosakata kunci, melafalkan nada dengan tepat, menyusun kalimat sederhana.",
          durationMinutes: 90,
          isPublished: true,
        },
      });
    }

    await prisma.material.create({
      data: {
        courseId: course.id,
        type: "PDF",
        title: `Buku Latihan ${definition.name}`,
        description: "Latihan mandiri untuk dikerjakan di rumah.",
        url: "https://akademimandarin.my.id/materi",
      },
    });

    for (const level of levels) {
      result.push({
        programId: program.id,
        code: definition.code,
        slug: definition.slug,
        levelId: level.id,
        levelCode: level.code,
        price: definition.priceMonthly,
      });
    }
  }

  return result;
}

type SeedUsers = Awaited<ReturnType<typeof seedUsers>>;
type AcademyContext = { studentId: number; classId: number };

const vocabularySeed = [
  { hanzi: "你好", pinyin: "nǐ hǎo", meaningId: "halo", meaningEn: "hello", wordClass: "frasa", hskLevel: 1 },
  { hanzi: "谢谢", pinyin: "xiè xie", meaningId: "terima kasih", meaningEn: "thank you", wordClass: "frasa", hskLevel: 1 },
  { hanzi: "老师", pinyin: "lǎo shī", meaningId: "guru", meaningEn: "teacher", wordClass: "nomina", hskLevel: 1 },
  { hanzi: "学生", pinyin: "xué shēng", meaningId: "murid", meaningEn: "student", wordClass: "nomina", hskLevel: 1 },
  { hanzi: "吃饭", pinyin: "chī fàn", meaningId: "makan", meaningEn: "to eat", wordClass: "verba", hskLevel: 1 },
  { hanzi: "时间", pinyin: "shí jiān", meaningId: "waktu", meaningEn: "time", wordClass: "nomina", hskLevel: 2 },
  { hanzi: "准备", pinyin: "zhǔn bèi", meaningId: "bersiap", meaningEn: "to prepare", wordClass: "verba", hskLevel: 2 },
  { hanzi: "重要", pinyin: "zhòng yào", meaningId: "penting", meaningEn: "important", wordClass: "adjektiva", hskLevel: 2 },
  { hanzi: "商务", pinyin: "shāng wù", meaningId: "bisnis", meaningEn: "business", wordClass: "nomina", hskLevel: 3 },
  { hanzi: "经验", pinyin: "jīng yàn", meaningId: "pengalaman", meaningEn: "experience", wordClass: "nomina", hskLevel: 3 },
  { hanzi: "提高", pinyin: "tí gāo", meaningId: "meningkatkan", meaningEn: "to improve", wordClass: "verba", hskLevel: 3 },
  { hanzi: "机会", pinyin: "jī huì", meaningId: "peluang", meaningEn: "opportunity", wordClass: "nomina", hskLevel: 3 },
];

const hanziSeed = [
  { character: "你", pinyin: "nǐ", meaningId: "kamu", radical: "亻", strokeCount: 7, hskLevel: 1 },
  { character: "好", pinyin: "hǎo", meaningId: "baik", radical: "女", strokeCount: 6, hskLevel: 1 },
  { character: "学", pinyin: "xué", meaningId: "belajar", radical: "子", strokeCount: 8, hskLevel: 1 },
  { character: "汉", pinyin: "hàn", meaningId: "Han (Tiongkok)", radical: "氵", strokeCount: 5, hskLevel: 1 },
  { character: "语", pinyin: "yǔ", meaningId: "bahasa", radical: "讠", strokeCount: 9, hskLevel: 1 },
  { character: "师", pinyin: "shī", meaningId: "guru/ahli", radical: "巾", strokeCount: 6, hskLevel: 2 },
  { character: "时", pinyin: "shí", meaningId: "waktu", radical: "日", strokeCount: 7, hskLevel: 2 },
  { character: "务", pinyin: "wù", meaningId: "urusan", radical: "力", strokeCount: 5, hskLevel: 3 },
  { character: "机", pinyin: "jī", meaningId: "mesin/peluang", radical: "木", strokeCount: 6, hskLevel: 3 },
  { character: "高", pinyin: "gāo", meaningId: "tinggi", radical: "高", strokeCount: 10, hskLevel: 3 },
];

async function seedAcademy(
  users: SeedUsers,
  programs: ProgramSeed[],
): Promise<AcademyContext> {
  const hsk1 = programs.find((item) => item.levelCode === "HSK-1")!;
  const hsk2 = programs.find((item) => item.levelCode === "HSK-2")!;
  const day = 24 * 60 * 60 * 1000;

  const student = await prisma.student.create({
    data: {
      userId: users.studentUser.id,
      studentNo: "AM-S-2026-001",
      programId: hsk2.programId,
      levelId: hsk2.levelId,
      currentHskLevel: 2,
      phone: "081200000004",
      goals: "Siap ujian HSK 3 untuk kebutuhan karier di perusahaan joint venture.",
      source: "WEBSITE",
      status: "ACTIVE",
      joinedAt: new Date(Date.now() - 120 * day),
    },
  });

  const activeClass = await prisma.class.create({
    data: {
      code: "AM-CLASS-01",
      name: "Kelas HSK 2 Malam",
      programId: hsk2.programId,
      levelId: hsk2.levelId,
      teacherId: users.teacher.id,
      mode: "ONLINE",
      status: "ACTIVE",
      capacity: 6,
      startDate: new Date(Date.now() - 21 * day),
      meetingUrl: "https://zoom.us/j/0000000000",
      notes: "Kelas reguler Senin & Rabu malam.",
      createdById: users.buzzer.userId,
    },
  });

  await prisma.class.create({
    data: {
      code: "AM-CLASS-02",
      name: "Kelas HSK 1 Pagi",
      programId: hsk1.programId,
      levelId: hsk1.levelId,
      mode: "OFFLINE",
      status: "PLANNED",
      capacity: 8,
      startDate: new Date(Date.now() + 10 * day),
      room: "Ruang 2 - Jakarta Selatan",
      notes: "Menunggu penugasan guru oleh buzzer.",
      createdById: users.buzzer.userId,
    },
  });

  const scheduleSeed = [
    { classId: activeClass.id, teacherId: users.teacher.id, dayOfWeek: "MONDAY" as const, startTime: "19:00", endTime: "20:30", room: null as string | null, meetingUrl: activeClass.meetingUrl },
    { classId: activeClass.id, teacherId: users.teacher.id, dayOfWeek: "WEDNESDAY" as const, startTime: "19:00", endTime: "20:30", room: null as string | null, meetingUrl: activeClass.meetingUrl },
  ];
  for (const schedule of scheduleSeed) {
    await prisma.schedule.create({ data: { ...schedule, type: "REGULAR", isActive: true } });
  }

  await prisma.classStudent.create({
    data: { classId: activeClass.id, studentId: student.id, status: "ACTIVE" },
  });

  const attendanceStatuses = ["PRESENT", "PRESENT", "LATE", "EXCUSED"] as const;
  for (const [index, status] of attendanceStatuses.entries()) {
    await prisma.attendance.create({
      data: {
        classId: activeClass.id,
        studentId: student.id,
        date: new Date(Date.now() - (index + 1) * 3 * day),
        status,
        recordedByUserId: users.teacher.userId,
      },
    });
  }

  const quiz = await prisma.quiz.create({
    data: {
      title: "Kuis Kosakata HSK 2 — Unit 1",
      description: "Kuis pilihan ganda untuk mengukur pemahaman kosakata unit pertama.",
      type: "QUIZ",
      passingScore: 70,
      timeLimitMinutes: 20,
      isPublished: true,
      createdById: users.teacher.userId,
    },
  });

  const questions = [
    { prompt: "「时间」 artinya adalah ...", options: ["waktu", "tempat", "orang", "harga"], answer: "waktu" },
    { prompt: "「准备」 artinya adalah ...", options: ["bersiap", "berhenti", "belajar", "membeli"], answer: "bersiap" },
    { prompt: "「重要」 artinya adalah ...", options: ["penting", "murah", "cepat", "ramai"], answer: "penting" },
    { prompt: "「我明天去北京」 berarti ...", options: ["Saya besok pergi ke Beijing", "Saya kemarin ke Beijing", "Saya sedang di Beijing", "Saya tidak ke Beijing"], answer: "Saya besok pergi ke Beijing" },
  ];

  for (const [index, question] of questions.entries()) {
    await prisma.question.create({
      data: {
        quizId: quiz.id,
        order: index + 1,
        type: "MULTIPLE_CHOICE",
        prompt: question.prompt,
        options: question.options,
        correctAnswer: question.answer,
        points: 1,
      },
    });
  }

  await prisma.quizAttempt.create({
    data: {
      quizId: quiz.id,
      studentId: student.id,
      status: "GRADED",
      score: 75,
      maxScore: 100,
      submittedAt: new Date(Date.now() - 6 * day),
      gradedByUserId: users.teacher.userId,
      feedback: "Bagus! Perhatikan penggunaan 时间 dan 时候 pada konteks kalimat.",
    },
  });

  const assignment = await prisma.assignment.create({
    data: {
      title: "Latihan Menulis 20 Hanzi Dasar",
      instructions: "Tulis 20 hanzi dari daftar kosakata unit 1 beserta pinyin dan artinya.",
      dueDate: new Date(Date.now() - 4 * day),
      maxScore: 100,
      isPublished: true,
      createdById: users.teacher.userId,
    },
  });

  await prisma.submission.create({
    data: {
      assignmentId: assignment.id,
      studentId: student.id,
      content: "Saya mengirimkan foto latihan hanzi pada tautan materi.",
      fileUrl: "https://akademimandarin.my.id/materi",
      status: "GRADED",
      score: 88,
      feedback: "Urutan goresan sudah bagus, perhatikan proporsi hanzi 语.",
      gradedByUserId: users.teacher.userId,
      gradedAt: new Date(Date.now() - 3 * day),
    },
  });

  await prisma.hSKProgress.createMany({
    data: [
      {
        studentId: student.id,
        programId: hsk1.programId,
        levelId: hsk1.levelId,
        levelCode: "HSK 1",
        listening: 92,
        speaking: 88,
        reading: 90,
        writing: 85,
        vocabulary: 150,
        masteryPercent: 100,
        mockExamScore: 186,
        status: "CERTIFIED",
        notes: "Lulus simulasi HSK 1 dengan nilai baik.",
        assessedByUserId: users.teacher.userId,
      },
      {
        studentId: student.id,
        programId: hsk2.programId,
        levelId: hsk2.levelId,
        levelCode: "HSK 2",
        listening: 78,
        speaking: 72,
        reading: 80,
        writing: 65,
        vocabulary: 240,
        masteryPercent: 74,
        status: "IN_PROGRESS",
        notes: "Fokus peningkatan menulis dan kosakata.",
        assessedByUserId: users.teacher.userId,
      },
    ],
  });

  for (const word of vocabularySeed) {
    await prisma.vocabulary.create({ data: word });
  }

  for (const item of hanziSeed) {
    await prisma.hanzi.create({ data: item });
  }

  return { studentId: student.id, classId: activeClass.id };
}

async function seedCrm(
  users: SeedUsers,
  programs: ProgramSeed[],
  context: AcademyContext,
) {
  const day = 24 * 60 * 60 * 1000;
  const beginner = programs.find((item) => item.levelCode === "HSK-1")!;
  const intermediate = programs.find((item) => item.levelCode === "HSK-2")!;
  const professional = programs.find((item) => item.levelCode === "HSK-3A")!;

  const leadSeeds = [
    { name: "Siti Nurhaliza", phone: "081311110001", email: "siti.nurhaliza@example.com", source: "INSTAGRAM", status: "LEAD", programId: beginner.programId, currentLevel: "Belum pernah belajar Mandarin", notes: "Ingin kelas malam setelah jam kerja." },
    { name: "Andi Pratama", phone: "081311110002", email: "andi.pratama@example.com", source: "WEBSITE", status: "CONTACTED", programId: intermediate.programId, currentLevel: "Sudah bisa percakapan sederhana", notes: "Butuh untuk keperluan kerja di perusahaan Tiongkok." },
    { name: "Maria Kusuma", phone: "081311110003", email: "maria.kusuma@example.com", source: "REFERRAL", status: "INTERESTED", programId: professional.programId, currentLevel: "Sudah lulus HSK 2", notes: "Menargetkan HSK 3 untuk beasiswa." },
    { name: "Rizky Ramadhan", phone: "081311110004", email: "rizky.ramadhan@example.com", source: "TIKTOK", status: "TRIAL", programId: beginner.programId, currentLevel: "Pemula", notes: "Sudah ikut trial, menunggu jadwal tetap." },
    { name: "Budi Santoso", phone: "081200000004", email: "demo_student@akademimandarin.my.id", source: "WEBSITE", status: "ACTIVE_STUDENT", programId: intermediate.programId, currentLevel: "HSK 2", notes: "Lead dari formulir website yang sudah menjadi murid aktif." },
  ];

  const leads = [];
  for (const [index, lead] of leadSeeds.entries()) {
    leads.push(
      await prisma.lead.create({
        data: {
          ...lead,
          status: lead.status as never,
          source: lead.source as never,
          assignedToUserId: index % 2 === 0 ? users.buzzer.userId : users.admin.id,
          followUpDate: new Date(Date.now() + (index + 1) * day),
        },
      }),
    );
  }

  const convertedLead = leads[4]!;
  const customer = await prisma.customer.create({
    data: {
      leadId: convertedLead.id,
      convertedUserId: users.studentUser.id,
      name: "Budi Santoso",
      phone: "081200000004",
      email: "demo_student@akademimandarin.my.id",
      type: "INDIVIDUAL",
      address: "Jakarta Selatan",
      status: "ACTIVE",
      notes: "Murid aktif program Intermediate (HSK 2).",
    },
  });

  await prisma.student.update({
    where: { id: context.studentId },
    data: { customerId: customer.id },
  });

  const followUpSeeds = [
    { leadId: leads[0]!.id, channel: "WHATSAPP" as const, note: "Mengirim brosur program Basic dan jadwal kelas malam.", result: "Berminat, meminta informasi biaya.", next: 2 },
    { leadId: leads[1]!.id, channel: "PHONE" as const, note: "Membahas kebutuhan Mandarin bisnis dan hasil tes penempatan.", result: "Menunggu jadwal trial.", next: 3 },
    { leadId: leads[2]!.id, channel: "MEETING" as const, note: "Konsultasi online mengenai target beasiswa dan jalur HSK 3.", result: "Sangat berminat, mempertimbangkan paket 6 bulan.", next: 5 },
    { customerId: customer.id, channel: "WHATSAPP" as const, note: "Konfirmasi pembayaran bulan kedua dan jadwal kelas.", result: "Sudah dibayar.", next: 30 },
  ];

  for (const followUp of followUpSeeds) {
    await prisma.followUp.create({
      data: {
        leadId: followUp.leadId ?? null,
        customerId: followUp.customerId ?? null,
        staffUserId: users.buzzer.userId,
        channel: followUp.channel,
        note: followUp.note,
        result: followUp.result,
        nextFollowUpAt: new Date(Date.now() + followUp.next * day),
      },
    });
  }

  const enrollment = await prisma.enrollment.create({
    data: {
      studentId: context.studentId,
      programId: intermediate.programId,
      levelId: intermediate.levelId,
      classId: context.classId,
      customerId: customer.id,
      status: "ACTIVE",
      startDate: new Date(Date.now() - 60 * day),
      endDate: new Date(Date.now() + 60 * day),
      agreedPrice: 750000,
      discount: 150000,
      totalAmount: 4350000,
      notes: "Paket 6 bulan dengan diskon pendaftaran awal.",
      createdByUserId: users.admin.id,
    },
  });

  const paymentSeeds = [
    { invoiceNo: "INV-2026-0001", amount: 1450000, status: "PAID" as const, paidAt: new Date(Date.now() - 60 * day), dueDate: new Date(Date.now() - 60 * day) },
    { invoiceNo: "INV-2026-0002", amount: 1450000, status: "PAID" as const, paidAt: new Date(Date.now() - 30 * day), dueDate: new Date(Date.now() - 30 * day) },
    { invoiceNo: "INV-2026-0003", amount: 1450000, status: "PENDING" as const, paidAt: null, dueDate: new Date(Date.now() + 7 * day) },
    { invoiceNo: "INV-2026-0004", amount: 750000, status: "OVERDUE" as const, paidAt: null, dueDate: new Date(Date.now() - 5 * day) },
  ];

  for (const payment of paymentSeeds) {
    await prisma.payment.create({
      data: {
        enrollmentId: enrollment.id,
        studentId: context.studentId,
        invoiceNo: payment.invoiceNo,
        amount: payment.amount,
        status: payment.status,
        method: "TRANSFER",
        dueDate: payment.dueDate,
        paidAt: payment.paidAt,
        reference: payment.paidAt ? `TRF-${payment.invoiceNo}` : null,
        recordedByUserId: users.admin.id,
      },
    });
  }
}

async function seedSystem(users: SeedUsers) {
  const day = 24 * 60 * 60 * 1000;

  const settings = [
    { key: "site.name", value: "Akademi Mandarin", group: "general" },
    { key: "site.tagline", value: "Mandarin Menghubungkan Lebih Banyak Peluang", group: "general" },
    { key: "site.email", value: "info@akademimandarin.my.id", group: "contact" },
    { key: "site.whatsapp", value: "6281234567890", group: "contact" },
    { key: "site.address", value: "Jakarta Selatan, Indonesia", group: "contact" },
    { key: "academy.class.capacity", value: "6", group: "academy" },
    { key: "crm.lead.defaultSource", value: "WEBSITE", group: "crm" },
    { key: "crm.followUp.slaHours", value: "24", group: "crm" },
    { key: "payment.bank", value: "BCA 1234567890 a.n. Akademi Mandarin", group: "finance" },
    { key: "auth.sessionTtlDays", value: "7", group: "security" },
  ];

  for (const setting of settings) {
    await prisma.setting.create({ data: setting });
  }

  const notifications = [
    { userId: users.admin.id, type: "INFO" as const, title: "Selamat datang di Akademi Mandarin", body: "Gunakan dashboard untuk memantau CRM, akademi, dan konten." },
    { userId: users.admin.id, type: "PAYMENT" as const, title: "Ada pembayaran tertunda", body: "Periksa daftar pembayaran berstatus pending dan overdue." },
    { userId: users.teacher.userId, type: "SCHEDULE" as const, title: "Jadwal mengajar pekan ini", body: "Kelas HSK 2 Malam berlangsung Senin dan Rabu pukul 19.00." },
    { userId: users.buzzer.userId, type: "WARNING" as const, title: "Kelas belum punya guru", body: "Kelas HSK 1 Pagi menunggu penugasan guru." },
    { userId: users.studentUser.id, type: "ASSIGNMENT" as const, title: "Tugas menunggu penilaian", body: "Latihan Menulis 20 Hanzi Dasar sudah dinilai guru Anda." },
    { userId: users.studentUser.id, type: "SUCCESS" as const, title: "Progres HSK 2", body: "Mastery Anda 74%. Fokus pada keterampilan menulis." },
  ];

  for (const [index, notification] of notifications.entries()) {
    await prisma.notification.create({
      data: {
        ...notification,
        link:
          notification.userId === users.studentUser.id
            ? "/student"
            : notification.userId === users.teacher.userId
              ? "/teacher"
              : notification.userId === users.buzzer.userId
                ? "/buzzer"
                : "/admin",
        createdAt: new Date(Date.now() - index * 6 * 60 * 60 * 1000),
      },
    });
  }

  // Keep the CRM follow-up queue realistic for demos.
  await prisma.setting.create({
    data: {
      key: "seed.lastRunAt",
      value: new Date(Date.now() - 0 * day).toISOString(),
      group: "system",
    },
  });
}

async function main() {
  console.log("→ Membersihkan data lama...");
  await wipe();

  console.log("→ Membuat peran pengguna...");
  const roleIds = await seedRoles();

  console.log("→ Membuat akun demo...");
  const users = await seedUsers(roleIds);

  console.log("→ Membuat program, level, kursus, dan pelajaran...");
  const programs = await seedPrograms();

  console.log("→ Membuat konten akademik...");
  const context = await seedAcademy(users, programs);

  console.log("→ Membuat data CRM...");
  await seedCrm(users, programs, context);

  console.log("→ Membuat pengaturan sistem & notifikasi...");
  await seedSystem(users);

  console.log("");
  console.log("Seed selesai.");
  console.log(`Password seluruh akun demo: ${DEMO_PASSWORD}`);
  console.log("  demo_admin / demo_teacher / demo_buzzer / demo_student");
}

main()
  .catch((error) => {
    console.error("Seed gagal:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
