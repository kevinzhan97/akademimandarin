/**
 * Session/permission types shared by server and client code.
 * Only these four roles exist in Akademi Mandarin - there is no public signup.
 */
export const ROLES = {
  ADMIN: "ADMIN",
  TEACHER: "TEACHER",
  BUZZER: "BUZZER",
  STUDENT: "STUDENT",
} as const;

export type RoleCode = (typeof ROLES)[keyof typeof ROLES];

export const ROLE_CODES: RoleCode[] = [
  ROLES.ADMIN,
  ROLES.TEACHER,
  ROLES.BUZZER,
  ROLES.STUDENT,
];

export interface SessionUser {
  id: number;
  username: string;
  fullName: string;
  email: string | null;
  avatarUrl: string | null;
  role: RoleCode;
  roleName: string;
  mustChangePassword: boolean;
}
