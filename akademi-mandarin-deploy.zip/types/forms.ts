/** Shared shape for every form that talks to a server action. */
export interface FormState {
  status: "idle" | "success" | "error";
  message?: string;
  errors?: Record<string, string>;
}

export const idleFormState: FormState = { status: "idle" };
