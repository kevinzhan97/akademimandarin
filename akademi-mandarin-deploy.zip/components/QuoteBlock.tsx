import { cn } from "@/lib/utils";

/** Closing quote of the homepage hero composition. */
export function QuoteBlock({ className }: { className?: string }) {
  return (
    <figure
      className={cn(
        "glass-soft w-full rounded-[1.75rem] px-6 py-5 text-center sm:ml-auto sm:max-w-sm sm:text-right",
        className,
      )}
    >
      <span
        aria-hidden="true"
        className="mx-auto block h-0.5 w-14 rounded-full bg-gradient-to-r from-brand-600 to-accent-500 sm:mr-0 sm:ml-auto"
      />
      <blockquote className="mt-3 text-base leading-snug font-semibold text-balance text-ink-900 sm:text-lg">
        &ldquo;Bahasa adalah jembatan,
        <br />
        manusia adalah tujuannya.&rdquo;
      </blockquote>
      <figcaption className="mt-3 text-[0.65rem] font-bold tracking-[0.24em] text-brand-600 uppercase">
        Akademi Mandarin
      </figcaption>
    </figure>
  );
}
