import Link from "next/link";
import type { ReactNode } from "react";
import {
  buttonClass,
  type ButtonSize,
  type ButtonVariant,
} from "@/components/ui/Button";

interface GlassButtonProps {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: Extract<
    ButtonVariant,
    "glass" | "primary" | "secondary" | "outline" | "ghost"
  >;
  size?: ButtonSize;
  className?: string;
  ariaLabel?: string;
  target?: string;
  rel?: string;
}

/**
 * Glass CTA button used on top of the homepage wallpaper. Renders a real link
 * when `href` is provided, otherwise a real button.
 */
export function GlassButton({
  children,
  href,
  onClick,
  variant = "glass",
  size = "lg",
  className,
  ariaLabel,
  target,
  rel,
}: GlassButtonProps) {
  if (href) {
    return (
      <Link
        href={href}
        className={buttonClass(variant, size, className)}
        aria-label={ariaLabel}
        target={target}
        rel={rel}
      >
        {children}
      </Link>
    );
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className={buttonClass(variant, size, className)}
      aria-label={ariaLabel}
    >
      {children}
    </button>
  );
}
