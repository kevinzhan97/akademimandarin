import { GlassButton } from "@/components/GlassButton";
import { Icon } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

/**
 * Hero layer of the homepage wallpaper composition: eyebrow, headline,
 * supporting copy, and the CTA buttons. Real HTML/React only.
 */
export function Hero({ className }: { className?: string }) {
  return (
    <div className={cn("fade-up relative z-20 max-w-2xl", className)}>
      <p className="text-[0.68rem] font-extrabold tracking-[0.32em] text-brand-600">
        LEARN · CONNECT · GROW
      </p>

      <h1 className="mt-4 text-[2.1rem] leading-[1.04] font-extrabold tracking-tight text-balance text-ink-900 sm:text-5xl lg:text-[2.9rem]">
        Mandarin
        <br />
        Menghubungkan
        <br />
        <span className="text-brand-600">Lebih Banyak Peluang</span>
      </h1>

      <p className="mt-4 max-w-xl text-[0.95rem] leading-relaxed text-ink-700 sm:text-base">
        Akademi Mandarin membantu Anda menguasai bahasa, membuka wawasan, dan
        menjembatani masa depan antara Indonesia dan Tiongkok.
      </p>

      <div className="relative z-40 mt-6 flex flex-wrap items-center gap-3">
        <GlassButton href="/program" variant="primary" size="lg">
          Lihat Program
          <Icon name="arrowRight" size={18} />
        </GlassButton>
        <GlassButton
          href="/#video"
          variant="glass"
          size="lg"
          ariaLabel="Tonton video profil Akademi Mandarin"
        >
          <Icon name="play" size={16} />
          Tonton Video
        </GlassButton>
      </div>
    </div>
  );
}
