"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ButtonLink } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { publicNav, siteConfig } from "@/lib/site";
import { cn } from "@/lib/utils";

export function Navbar({
  user,
}: {
  user: { fullName: string; dashboardHref: string } | null;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // The homepage renders this header on top of the wallpaper.
  const overlay = pathname === "/";

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header
      className={cn(
        "z-40 transition-all duration-300",
        overlay ? "fixed inset-x-0 top-0" : "sticky top-0",
        scrolled ? "py-2" : "py-3",
      )}
    >
      <div className="shell-container">
        <nav
          aria-label="Navigasi utama"
          className={cn(
            "flex items-center justify-between gap-3 rounded-3xl px-4 py-2.5 transition-all duration-300",
            scrolled || !overlay
              ? "glass"
              : "glass-soft border-white/50 bg-white/35",
          )}
        >
          <Link
            href="/"
            className="flex shrink-0 items-center"
            aria-label={siteConfig.name}
          >
            <Image
              src="/logo.png"
              alt="Akademi Mandarin"
              width={40}
              height={40}
              preload
              className="size-10 rounded-2xl object-contain"
            />
          </Link>

          <ul className="hidden flex-1 items-center justify-center gap-0.5 xl:flex">
            {publicNav.map((item) => {
              const active =
                item.href === "/"
                  ? pathname === "/"
                  : pathname.startsWith(item.href);
              return (
                <li key={item.href} className="shrink-0">
                  <Link
                    href={item.href}
                    aria-current={active ? "page" : undefined}
                    className={cn(
                      "block whitespace-nowrap rounded-full px-2.5 py-2 text-[0.8rem] font-medium transition",
                      active
                        ? "bg-white/80 text-brand-700"
                        : "text-ink-600 hover:bg-white/70 hover:text-brand-700",
                    )}
                  >
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>

          <div className="flex items-center gap-2">
            <Link
              href="/cari"
              aria-label="Cari di situs Akademi Mandarin"
              className="flex size-10 items-center justify-center rounded-2xl border border-ink-900/10 bg-white/70 text-ink-700 transition hover:text-brand-700"
            >
              <Icon name="search" size={18} />
            </Link>

            <div className="hidden items-center gap-2 lg:flex">
              {user ? (
                <ButtonLink href={user.dashboardHref} size="sm" variant="outline">
                  <Icon name="dashboard" size={15} />
                  Dashboard
                </ButtonLink>
              ) : (
                <ButtonLink href="/login" size="sm" variant="ghost">
                  Login
                </ButtonLink>
              )}
              <ButtonLink href="/mulai-sekarang" size="sm">
                Mulai Sekarang
                <Icon name="arrowRight" size={15} />
              </ButtonLink>
            </div>

            <button
              type="button"
              onClick={() => {
                setOpen((value) => !value);
              }}
              className="flex size-10 items-center justify-center rounded-2xl border border-ink-900/10 bg-white/70 text-ink-700 xl:hidden"
              aria-expanded={open}
              aria-controls="mobile-nav"
              aria-label={open ? "Tutup menu" : "Buka menu"}
            >
              <Icon name={open ? "close" : "menu"} size={20} />
            </button>
          </div>
        </nav>

        {open ? (
          <div id="mobile-nav" className="glass mt-2 rounded-3xl p-4 xl:hidden">
            <ul className="grid gap-1">
              {publicNav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="block rounded-2xl px-4 py-3 text-sm font-semibold text-ink-700 transition hover:bg-white/80 hover:text-brand-700"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>

            <div className="mt-3 grid gap-2 border-t border-ink-900/8 pt-3">
              {user ? (
                <ButtonLink href={user.dashboardHref} variant="outline" size="sm">
                  Dashboard
                </ButtonLink>
              ) : (
                <ButtonLink href="/login" variant="outline" size="sm">
                  Login
                </ButtonLink>
              )}
              <ButtonLink href="/mulai-sekarang" size="sm">
                Mulai Sekarang
              </ButtonLink>
            </div>
          </div>
        ) : null}
      </div>
    </header>
  );
}
