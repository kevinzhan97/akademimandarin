import Image from "next/image";
import Link from "next/link";
import { Icon } from "@/components/ui/Icon";
import { publicNav, siteConfig, whatsappLink } from "@/lib/site";

const programLinks = [
  { label: "Basic — Pre-HSK 1", href: "/program#basic" },
  { label: "Beginner — HSK 1", href: "/program#beginner" },
  { label: "Intermediate — HSK 2", href: "/program#intermediate" },
  { label: "Professional — HSK 3 Path", href: "/program#professional" },
  { label: "Advance — HSK 4 Path", href: "/program#advance" },
];

const socials = [
  { key: "instagram", label: "Instagram Akademi Mandarin", href: siteConfig.social.instagram },
  { key: "tiktok", label: "TikTok Akademi Mandarin", href: siteConfig.social.tiktok },
  { key: "youtube", label: "YouTube Akademi Mandarin", href: siteConfig.social.youtube },
] as const;

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative mt-24 overflow-hidden border-t border-white/60 bg-white/70">
      <div className="pointer-events-none absolute -top-32 left-1/2 h-64 w-[42rem] -translate-x-1/2 rounded-full bg-brand-200/40 blur-3xl" />
      <div className="shell-container relative py-14">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center">
              <Image
                src="/logo.png"
                alt="Akademi Mandarin"
                width={40}
                height={40}
                className="size-10 rounded-2xl object-contain"
              />
            </Link>
            <p className="mt-4 text-sm leading-relaxed text-ink-500">
              {siteConfig.description}
            </p>
            <div className="mt-5 flex gap-2">
              {socials.map((social) => (
                <a
                  key={social.key}
                  href={social.href}
                  aria-label={social.label}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="flex size-9 items-center justify-center rounded-xl border border-ink-900/10 bg-white/80 text-ink-600 transition hover:text-brand-600"
                >
                  <Icon name={social.key} size={17} />
                </a>
              ))}
              <a
                href={whatsappLink()}
                aria-label="WhatsApp Akademi Mandarin"
                target="_blank"
                rel="noreferrer noopener"
                className="flex size-9 items-center justify-center rounded-xl border border-ink-900/10 bg-white/80 text-ink-600 transition hover:text-brand-600"
              >
                <Icon name="whatsapp" size={17} />
              </a>
            </div>
          </div>
          <nav aria-label="Tautan perusahaan">
            <h3 className="text-sm font-bold text-ink-900">Perusahaan</h3>
            <ul className="mt-4 space-y-2.5">
              {publicNav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-ink-500 transition hover:text-brand-600"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Tautan program">
            <h3 className="text-sm font-bold text-ink-900">Program</h3>
            <ul className="mt-4 space-y-2.5">
              {programLinks.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-ink-500 transition hover:text-brand-600"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h3 className="text-sm font-bold text-ink-900">Kontak</h3>
            <ul className="mt-4 space-y-3 text-sm text-ink-500">
              <li className="flex items-start gap-2">
                <Icon name="mail" size={16} className="mt-0.5 shrink-0" />
                <a
                  href={`mailto:${siteConfig.email}`}
                  className="transition hover:text-brand-600"
                >
                  {siteConfig.email}
                </a>
              </li>
              {siteConfig.phone ? (
                <li className="flex items-start gap-2">
                  <Icon name="phone" size={16} className="mt-0.5 shrink-0" />
                  <a
                    href={`tel:${siteConfig.phone.replace(/\s|-/g, "")}`}
                    className="transition hover:text-brand-600"
                  >
                    {siteConfig.phone}
                  </a>
                </li>
              ) : null}
              <li className="flex items-start gap-2">
                <Icon name="whatsapp" size={16} className="mt-0.5 shrink-0" />
                <a
                  href={whatsappLink(
                    "Halo Akademi Mandarin, saya ingin konsultasi program.",
                  )}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="transition hover:text-brand-600"
                >
                  Konsultasi WhatsApp
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Icon name="globe" size={16} className="mt-0.5 shrink-0" />
                <span>Online (Zoom) &amp; kelas tatap muka</span>
              </li>
            </ul>
            <Link
              href="/login"
              className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-brand-600 transition hover:text-brand-700"
            >
              <Icon name="lock" size={15} />
              Portal Login Murid &amp; Tim
            </Link>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-ink-900/8 pt-6 text-xs text-ink-400 sm:flex-row">
          <p>
            © {year} {siteConfig.name}. Seluruh hak cipta dilindungi.
          </p>
          <p className="font-cjk tracking-widest">中印尼桥梁 · 学无止境</p>
        </div>
      </div>
    </footer>
  );
}
