import Link from "next/link";
import { GlassCard, SectionHeading } from "@/components/ui/Card";
import { programStageTone } from "@/components/public/ProgramShowcase";
import { hskStages } from "@/lib/content";

export function HskPathSection({ compact = false }: { compact?: boolean }) {
  return (
    <section className="section-pad" id="hsk-path">
      <div className="shell-container">
        <SectionHeading
          eyebrow="HSK Learning Path"
          title="Jalur belajar HSK yang transparan"
          description="Level ujian resmi tetap HSK 1 sampai HSK 4. Segmen 3A/3B dan 4A/4B adalah pembagian internal kami agar materi profesional lebih mudah dicerna."
        />

        <ol className="mt-12 grid gap-4 lg:grid-cols-5">
          {hskStages.map((item, index) => (
            <li key={item.stage} className="relative">
              <GlassCard className="h-full">
                <div className="flex items-center gap-3">
                  <span
                    className={`flex size-10 items-center justify-center rounded-2xl bg-gradient-to-br text-sm font-extrabold text-white ${
                      programStageTone[item.stage] ?? "from-brand-600 to-accent-500"
                    }`}
                  >
                    {index + 1}
                  </span>
                  <div>
                    <p className="text-xs font-bold tracking-wide text-ink-400 uppercase">
                      {item.label}
                    </p>
                    <p className="text-sm font-extrabold text-ink-900">{item.level}</p>
                  </div>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-ink-500">
                  {item.focus}
                </p>
                {item.internal && !compact ? (
                  <p className="mt-3 rounded-xl bg-brand-50 px-3 py-2 text-[0.7rem] leading-relaxed text-brand-700">
                    {item.internal}
                  </p>
                ) : null}
              </GlassCard>
            </li>
          ))}
        </ol>

        <p className="mt-8 text-center text-sm text-ink-500">
          Belum tahu harus mulai dari mana?{" "}
          <Link
            href="/mulai-sekarang"
            className="font-semibold text-brand-600 underline decoration-brand-300 underline-offset-4"
          >
            Ikuti tes penempatan gratis
          </Link>
          .
        </p>
      </div>
    </section>
  );
}
