import Link from "next/link";
import { ButtonLink } from "@/components/ui/Button";
import { SectionHeading } from "@/components/ui/Card";
import { Icon } from "@/components/ui/Icon";
import { siteConfig, whatsappLink } from "@/lib/site";

export function CtaSection() {
  return (
    <section className="section-pad">
      <div className="shell-container">
        <div className="relative overflow-hidden rounded-[2.25rem] bg-gradient-to-br from-ink-900 via-brand-800 to-brand-600 px-8 py-14 text-white sm:px-14">
          <div className="brand-ribbon pointer-events-none absolute -top-10 -right-16 h-40 w-[36rem] rotate-12 opacity-50" />
          <div className="relative grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:items-center">
            <div>
              <p className="text-xs font-bold tracking-[0.24em] text-white/70 uppercase">
                Mulai Perjalanan Anda
              </p>
              <h2 className="mt-3 text-3xl font-extrabold text-white sm:text-4xl">
                Siap bicara Mandarin dengan percaya diri?
              </h2>
              <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/80 sm:text-base">
                Ikuti tes penempatan gratis, dapatkan rekomendasi level Pre-HSK 1
                sampai HSK 4, dan mulai kelas pertama Anda pekan ini.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 lg:justify-end">
              <Link
                href="/mulai-sekarang"
                className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3.5 text-sm font-bold text-brand-700 transition hover:-translate-y-0.5 hover:bg-brand-50"
              >
                Mulai Sekarang
                <Icon name="arrowRight" size={16} />
              </Link>
              <a
                href={whatsappLink(
                  "Halo Akademi Mandarin, saya ingin tes penempatan gratis.",
                )}
                target="_blank"
                rel="noreferrer noopener"
                className="inline-flex items-center gap-2 rounded-full border border-white/40 px-6 py-3.5 text-sm font-bold text-white transition hover:-translate-y-0.5 hover:bg-white/10"
              >
                <Icon name="whatsapp" size={16} />
                Konsultasi WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function PublicPageHeader({
  eyebrow,
  title,
  description,
  hanzi,
}: {
  eyebrow: string;
  title: string;
  description: string;
  hanzi: string;
}) {
  return (
    <section className="relative overflow-hidden pt-10 pb-8 sm:pt-14">
      <span
        aria-hidden="true"
        className="font-cjk pointer-events-none absolute -top-8 right-2 text-[9rem] leading-none text-brand-600/[0.07] select-none sm:text-[13rem]"
      >
        {hanzi}
      </span>
      <div className="shell-container relative max-w-3xl">
        <span className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-white/70 px-3.5 py-1.5 text-xs font-bold tracking-[0.14em] text-brand-600 uppercase">
          {eyebrow}
        </span>
        <h1 className="mt-5 text-3xl leading-tight font-extrabold text-balance sm:text-4xl lg:text-5xl">
          {title}
        </h1>
        <p className="mt-5 text-base leading-relaxed text-ink-500">{description}</p>
      </div>
    </section>
  );
}

export function VideoSection() {
  const videoId = process.env.NEXT_PUBLIC_PROMO_VIDEO_ID;

  return (
    <section id="video" className="section-pad scroll-mt-24">
      <div className="shell-container">
        <SectionHeading
          eyebrow="Tonton Video"
          title="Kenali Akademi Mandarin dalam dua menit"
          description="Lihat suasana kelas, metode pengajaran, dan bagaimana murid kami berlatih empat keterampilan setiap pertemuan."
        />

        <div className="mt-12 overflow-hidden rounded-[2rem] border border-white/70 bg-white/70 shadow-[var(--shadow-glass)]">
          {videoId ? (
            <div className="aspect-video w-full">
              <iframe
                className="size-full"
                src={`https://www.youtube-nocookie.com/embed/${videoId}`}
                title="Video profil Akademi Mandarin"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                loading="lazy"
              />
            </div>
          ) : (
            <div className="grid gap-6 p-8 sm:p-12 lg:grid-cols-[1.2fr_1fr] lg:items-center">
              <div>
                <h3 className="text-xl font-bold text-ink-900">
                  Video profil lengkap tersedia di kanal resmi kami
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-ink-500">
                  Sementara itu, Anda bisa mengambil tur kelas gratis (trial 60 menit)
                  dan berbicara langsung dengan tim akademik untuk menyusun rencana
                  belajar Mandarin Anda.
                </p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <ButtonLink href="/mulai-sekarang" size="md">
                    Ambil Trial Gratis
                  </ButtonLink>
                  <ButtonLink
                    href={siteConfig.social.youtube}
                    variant="outline"
                    size="md"
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    <Icon name="youtube" size={16} />
                    Kunjungi Kanal YouTube
                  </ButtonLink>
                </div>
              </div>
              <div className="glass-soft rounded-3xl p-6">
                <p className="text-sm font-bold text-ink-900">Yang Anda dapatkan</p>
                <ul className="mt-4 space-y-3 text-sm text-ink-600">
                  <li className="flex gap-2">
                    <Icon name="check" size={16} className="mt-0.5 text-jade-500" />
                    Kelas interaktif maksimal 6 murid
                  </li>
                  <li className="flex gap-2">
                    <Icon name="check" size={16} className="mt-0.5 text-jade-500" />
                    Latihan 听 说 读 写 di setiap sesi
                  </li>
                  <li className="flex gap-2">
                    <Icon name="check" size={16} className="mt-0.5 text-jade-500" />
                    Laporan progres HSK untuk murid &amp; orang tua
                  </li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
