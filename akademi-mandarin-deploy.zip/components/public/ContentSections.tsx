import Link from "next/link";
import type { ReactNode } from "react";
import { ButtonLink } from "@/components/ui/Button";
import { GlassCard, SectionHeading } from "@/components/ui/Card";
import { Icon } from "@/components/ui/Icon";
import { methodSteps, whyMandarin } from "@/lib/content";

export function TrustStrip({
  stats,
}: {
  stats: { students: number; teachers: number; programs: number; activeClasses: number };
}) {
  const items = [
    { label: "Murid aktif", value: stats.students },
    { label: "Guru aktif", value: stats.teachers },
    { label: "Program berjalan", value: stats.programs },
    { label: "Kelas aktif", value: stats.activeClasses },
  ];

  return (
    <section className="pb-4">
      <div className="shell-container">
        <div className="glass grid grid-cols-2 gap-6 rounded-3xl px-6 py-7 sm:grid-cols-4">
          {items.map((item) => (
            <div key={item.label} className="text-center">
              <p className="text-2xl font-extrabold text-ink-900 sm:text-3xl">
                {item.value}
              </p>
              <p className="mt-1 text-xs font-medium text-ink-500 sm:text-sm">
                {item.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function MethodPreview({ steps = 3 }: { steps?: number }) {
  return (
    <section className="section-pad bg-white/50">
      <div className="shell-container">
        <SectionHeading
          eyebrow="Metode Belajar"
          title="Terarah, terukur, dan seimbang di empat keterampilan"
          description="Kami tidak hanya melatih percakapan. Setiap sesi memuat latihan mendengar, berbicara, membaca, dan menulis dengan target yang jelas."
        />

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {methodSteps.slice(0, steps).map((step) => (
            <GlassCard key={step.step} className="relative">
              <span className="absolute top-5 right-6 text-3xl font-black text-brand-100">
                {step.step}
              </span>
              <span className="mb-4 flex size-12 items-center justify-center rounded-2xl bg-white text-brand-600 shadow-[var(--shadow-soft)]">
                <Icon name={step.icon} size={22} />
              </span>
              <h3 className="text-lg font-bold text-ink-900">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">
                {step.description}
              </p>
            </GlassCard>
          ))}
        </div>

        <div className="mt-10 text-center">
          <ButtonLink href="/metode-belajar" variant="outline" size="md">
            Lihat 5 tahap metode belajar
            <Icon name="arrowRight" size={15} />
          </ButtonLink>
        </div>
      </div>
    </section>
  );
}

export function WhyMandarinPreview({ items = 3 }: { items?: number }) {
  return (
    <section className="section-pad">
      <div className="shell-container grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
        <div>
          <SectionHeading
            align="left"
            eyebrow="Mengapa Mandarin"
            title="Bahasa yang menghubungkan dua ekonomi besar"
            description="Indonesia dan Tiongkok adalah mitra yang saling membutuhkan. Kemampuan berbahasa Mandarin membuat Anda berdiri di antara keduanya — sebagai penghubung, bukan penonton."
          />
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonLink href="/mengapa-mandarin" size="md">
              Selengkapnya
              <Icon name="arrowRight" size={15} />
            </ButtonLink>
            <ButtonLink href="/mulai-sekarang" variant="outline" size="md">
              Konsultasi Gratis
            </ButtonLink>
          </div>
        </div>

        <ul className="grid gap-4 sm:grid-cols-2">
          {whyMandarin.slice(0, items + 1).map((item) => (
            <li
              key={item.title}
              className="card-surface p-5 transition hover:-translate-y-1"
            >
              <span className="flex size-10 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                <Icon name={item.icon} size={19} />
              </span>
              <h3 className="mt-4 text-base font-bold text-ink-900">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-500">
                {item.description}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function FaqPreview({ children }: { children: ReactNode }) {
  return (
    <section className="section-pad bg-white/50" id="faq">
      <div className="shell-container">
        <SectionHeading
          eyebrow="FAQ"
          title="Pertanyaan yang sering diajukan"
          description="Tidak menemukan jawaban Anda? Hubungi tim akademik kami melalui WhatsApp — kami balas pada hari kerja."
        />
        <div className="mx-auto mt-10 max-w-3xl">
          {children}
        </div>
        <div className="mt-8 text-center">
          <Link
            href="/faq"
            className="text-sm font-semibold text-brand-600 underline decoration-brand-300 underline-offset-4"
          >
            Lihat semua pertanyaan
          </Link>
        </div>
      </div>
    </section>
  );
}
