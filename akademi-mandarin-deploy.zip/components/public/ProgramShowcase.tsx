import { ButtonLink } from "@/components/ui/Button";
import { Badge } from "@/components/ui/Badge";
import { GlassCard, SectionHeading } from "@/components/ui/Card";
import { Icon } from "@/components/ui/Icon";
import { formatCurrency } from "@/lib/utils";

export interface ProgramLevelView {
  id: number;
  code: string;
  name: string;
  description: string | null;
}

export interface ProgramView {
  id: number;
  code: string;
  name: string;
  slug: string;
  hskLabel: string;
  tagline: string | null;
  description: string | null;
  durationMonths: number | null;
  priceMonthly: number;
  levels: ProgramLevelView[];
}

export const programStageTone: Record<string, string> = {
  BASIC: "from-sky-500 to-sky-400",
  BEGINNER: "from-jade-500 to-jade-400",
  INTERMEDIATE: "from-gold-500 to-gold-400",
  PROFESSIONAL: "from-brand-600 to-accent-500",
  ADVANCE: "from-brand-800 to-brand-600",
};

export function ProgramShowcase({
  programs,
  heading = true,
}: {
  programs: ProgramView[];
  heading?: boolean;
}) {
  return (
    <section className="section-pad" id="program">
      <div className="shell-container">
        {heading ? (
          <SectionHeading
            eyebrow="Program Kami"
            title="Lima tahap belajar, satu jalur yang jelas"
            description="Dari nol sampai siap ujian HSK 4. Setiap tahap punya target kosakata, hanzi, dan keterampilan yang terukur."
          />
        ) : null}

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {programs.map((program) => (
            <GlassCard
              key={program.id}
              id={program.slug}
              interactive
              className="flex scroll-mt-28 flex-col"
            >
              <div className="flex items-center justify-between gap-3">
                <span
                  className={`flex size-11 items-center justify-center rounded-2xl bg-gradient-to-br text-sm font-extrabold text-white ${
                    programStageTone[program.code] ?? "from-brand-600 to-accent-500"
                  }`}
                >
                  {program.code.slice(0, 2)}
                </span>
                <Badge tone="brand">{program.hskLabel}</Badge>
              </div>

              <h3 className="mt-5 text-xl font-bold text-ink-900">{program.name}</h3>
              {program.tagline ? (
                <p className="mt-1 text-sm font-medium text-brand-600">
                  {program.tagline}
                </p>
              ) : null}
              <p className="mt-3 flex-1 text-sm leading-relaxed text-ink-500">
                {program.description}
              </p>

              {program.levels.length > 0 ? (
                <ul className="mt-4 space-y-1.5">
                  {program.levels.map((level) => (
                    <li
                      key={level.id}
                      className="flex items-center gap-2 text-xs text-ink-600"
                    >
                      <Icon name="check" size={14} className="text-jade-500" />
                      {level.name}
                    </li>
                  ))}
                </ul>
              ) : null}

              <dl className="mt-5 grid grid-cols-2 gap-3 border-t border-ink-900/8 pt-4 text-sm">
                <div>
                  <dt className="text-xs text-ink-400">Durasi</dt>
                  <dd className="font-semibold text-ink-800">
                    {program.durationMonths ? `${program.durationMonths} bulan` : "-"}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-ink-400">Investasi</dt>
                  <dd className="font-semibold text-ink-800">
                    {program.priceMonthly > 0
                      ? `${formatCurrency(program.priceMonthly)}/bln`
                      : "Konsultasi"}
                  </dd>
                </div>
              </dl>

              <ButtonLink
                href={`/mulai-sekarang?program=${program.slug}`}
                variant="outline"
                size="sm"
                className="mt-5"
              >
                Ambil Program Ini
                <Icon name="arrowRight" size={15} />
              </ButtonLink>
            </GlassCard>
          ))}
        </div>

        <div className="mt-10 text-center">
          <ButtonLink href="/hsk-path" variant="ghost" size="md">
            Lihat detail HSK Path
            <Icon name="arrowRight" size={15} />
          </ButtonLink>
        </div>
      </div>
    </section>
  );
}
