"use client";

import { useActionState } from "react";
import { submitLeadAction } from "@/app/(public)/mulai-sekarang/actions";
import { Alert } from "@/components/ui/Feedback";
import { Field, Input, Select, Textarea } from "@/components/ui/Form";
import { SubmitButton } from "@/components/ui/SubmitButton";
import { idleFormState } from "@/types/forms";

export interface LeadProgramOption {
  id: number;
  name: string;
  hskLabel: string;
}

const levelOptions = [
  "Belum tahu (butuh tes penempatan)",
  "Belum pernah belajar Mandarin",
  "Pernah belajar dasar (pinyin & sapaan)",
  "Sudah bisa percakapan sederhana",
  "Sudah lulus HSK 1 - 2",
  "Sudah lulus HSK 3 atau lebih",
];

export function LeadForm({
  programs,
  defaultProgramId,
  compact = false,
}: {
  programs: LeadProgramOption[];
  defaultProgramId?: number | null;
  compact?: boolean;
}) {
  const [state, formAction] = useActionState(submitLeadAction, idleFormState);

  if (state.status === "success") {
    return (
      <Alert tone="success" title="Pendaftaran terkirim!">
        {state.message}
      </Alert>
    );
  }

  return (
    <form action={formAction} className="space-y-4" noValidate>
      {state.status === "error" && state.message ? (
        <Alert tone="error">{state.message}</Alert>
      ) : null}

      <div className={compact ? "space-y-4" : "grid gap-4 sm:grid-cols-2"}>
        <Field label="Nama lengkap" htmlFor="lead-name" required error={state.errors?.name}>
          <Input
            id="lead-name"
            name="name"
            placeholder="Nama Anda"
            autoComplete="name"
            required
          />
        </Field>

        <Field
          label="Nomor WhatsApp"
          htmlFor="lead-phone"
          required
          error={state.errors?.phone}
          hint="Contoh: 08123456789"
        >
          <Input
            id="lead-phone"
            name="phone"
            inputMode="tel"
            placeholder="0812xxxxxxx"
            autoComplete="tel"
            required
          />
        </Field>

        <Field label="Email" htmlFor="lead-email" error={state.errors?.email}>
          <Input
            id="lead-email"
            name="email"
            type="email"
            placeholder="nama@email.com"
            autoComplete="email"
          />
        </Field>

        <Field
          label="Program yang diminati"
          htmlFor="lead-program"
          error={state.errors?.programId}
        >
          <Select
            id="lead-program"
            name="programId"
            defaultValue={defaultProgramId ? String(defaultProgramId) : ""}
          >
            <option value="">Belum ditentukan</option>
            {programs.map((program) => (
              <option key={program.id} value={program.id}>
                {program.name} — {program.hskLabel}
              </option>
            ))}
          </Select>
        </Field>
      </div>

      <Field label="Level Mandarin saat ini" htmlFor="lead-level" error={state.errors?.currentLevel}>
        <Select id="lead-level" name="currentLevel" defaultValue={levelOptions[0]}>
          {levelOptions.map((level) => (
            <option key={level} value={level}>
              {level}
            </option>
          ))}
        </Select>
      </Field>

      <Field
        label="Tujuan atau pertanyaan"
        htmlFor="lead-notes"
        error={state.errors?.notes}
        hint="Contoh: ingin siap HSK 3 untuk keperluan kerja."
      >
        <Textarea
          id="lead-notes"
          name="notes"
          rows={3}
          placeholder="Ceritakan tujuan belajar Anda"
        />
      </Field>

      {/* Anti-spam honeypot: hidden from users, bots usually fill it. */}
      <div className="hidden" aria-hidden="true">
        <label htmlFor="lead-company">Perusahaan</label>
        <input id="lead-company" name="company" tabIndex={-1} autoComplete="off" />
      </div>

      <SubmitButton pendingLabel="Mengirim..." className="w-full sm:w-auto">
        Kirim &amp; Ambil Trial Gratis
      </SubmitButton>

      <p className="text-xs leading-relaxed text-ink-400">
        Dengan mengirim formulir ini Anda setuju dihubungi tim Akademi Mandarin melalui
        WhatsApp atau email mengenai program yang Anda minati.
      </p>
    </form>
  );
}
