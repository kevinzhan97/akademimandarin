"use client";

import { useState } from "react";
import { Icon } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

export interface FaqItem {
  question: string;
  answer: string;
}

export function FaqAccordion({ items }: { items: FaqItem[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="divide-y divide-ink-900/8 overflow-hidden rounded-3xl border border-white/70 bg-white/70 shadow-[var(--shadow-soft)]">
      {items.map((item, index) => {
        const open = openIndex === index;
        return (
          <div key={item.question}>
            <h3>
              <button
                type="button"
                onClick={() => setOpenIndex(open ? null : index)}
                aria-expanded={open}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition hover:bg-brand-50/50"
              >
                <span
                  className={cn(
                    "text-sm font-semibold sm:text-base",
                    open ? "text-brand-700" : "text-ink-800",
                  )}
                >
                  {item.question}
                </span>
                <Icon
                  name="chevronDown"
                  size={18}
                  className={cn(
                    "shrink-0 text-ink-400 transition-transform duration-300",
                    open && "rotate-180 text-brand-600",
                  )}
                />
              </button>
            </h3>
            {open ? (
              <div className="px-5 pb-5 text-sm leading-relaxed text-ink-500">
                {item.answer}
              </div>
            ) : null}
          </div>
        );
      })}
    </div>
  );
}
