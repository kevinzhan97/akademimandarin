import Link from "next/link";
import { Icon } from "@/components/ui/Icon";
import { hskStages } from "@/lib/content";
import { cn } from "@/lib/utils";

/**
 * HSK learning path timeline: horizontal with circular markers on desktop,
 * vertical on mobile. Real HTML/CSS only - no canvas, no images.
 */
export function HSKPath({ className }: { className?: string }) {
  return (
    <section
      aria-labelledby="hsk-learning-path"
      className={cn(
        "glass-soft rounded-[1.75rem] px-4 py-5 sm:px-6 sm:py-6",
        className,
      )}
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2
          id="hsk-learning-path"
          className="text-xs font-extrabold tracking-[0.28em] text-ink-800 uppercase"
        >
          HSK Learning Path
        </h2>
        <Link
          href="/hsk-path"
          className="inline-flex items-center gap-1 text-xs font-bold text-brand-600 transition hover:text-brand-700"
        >
          Lihat detail jalur belajar
          <Icon name="arrowRight" size={13} />
        </Link>
      </div>

      <div className="relative mt-6">
        <span
          aria-hidden="true"
          className="absolute top-2 bottom-2 left-2 w-px -translate-x-1/2 bg-gradient-to-b from-brand-300 via-brand-500 to-accent-400 md:top-2 md:right-2 md:bottom-auto md:left-2 md:h-px md:w-auto md:translate-x-0 md:bg-gradient-to-r"
        />

        <ol className="grid gap-5 md:grid-cols-5 md:gap-3">

        {hskStages.map((stage) => (
          <li key={stage.stage} className="relative flex items-start gap-4 md:block">
            <span className="relative z-10 flex size-4 shrink-0 items-center justify-center rounded-full border-2 border-brand-500 bg-white">
              <span className="size-1.5 rounded-full bg-brand-600" />
            </span>
            <div className="md:mt-4">
              <p className="text-[0.65rem] font-bold tracking-[0.18em] text-ink-400 uppercase">
                {stage.stage}
              </p>
              <p className="text-sm font-extrabold text-ink-900">
                {stage.path ?? stage.level}
              </p>
            </div>
          </li>
        ))}
        </ol>
      </div>

      <p className="mt-5 text-[0.65rem] leading-relaxed text-ink-500">
        Level ujian resmi tetap HSK 1 sampai HSK 4. Segmen 3A/3B dan 4A/4B
        adalah pembagian internal Akademi Mandarin, bukan level ujian terpisah.
      </p>
    </section>
  );
}
