import { cn } from "@/lib/utils";

const heroStats = [
  { value: "5", label: "Level Pembelajaran" },
  { value: "4", label: "Keterampilan Utama" },
  { value: "1", label: "Tujuan Lebih Besar" },
] as const;

/** Real HTML statistics block rendered over the wallpaper. */
export function HeroStats({ className }: { className?: string }) {
  return (
    <dl className={cn("grid max-w-md grid-cols-3 gap-2.5 sm:gap-3", className)}>
      {heroStats.map((stat) => (
        <div
          key={stat.label}
          className="glass-soft rounded-2xl px-2.5 py-3 text-center sm:px-3.5"
        >
          <dt className="sr-only">{stat.label}</dt>
          <dd>
            <span className="block text-xl font-extrabold text-brand-700 sm:text-2xl">
              {stat.value}
            </span>
            <span className="mt-0.5 block text-[0.62rem] font-semibold tracking-wide text-ink-600 sm:text-[0.68rem]">
              {stat.label}
            </span>
          </dd>
        </div>
      ))}
    </dl>
  );
}
