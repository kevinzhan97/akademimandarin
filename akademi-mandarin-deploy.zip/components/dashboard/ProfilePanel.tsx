import { ChangePasswordForm, ProfileForm } from "@/components/dashboard/ProfileForms";
import { Badge } from "@/components/ui/Badge";
import { Card, CardHeader } from "@/components/ui/Card";
import { InfoRow } from "@/components/ui/StatCard";
import { PageHeader } from "@/components/ui/PageHeader";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ROLE_LABEL } from "@/lib/rbac";
import { formatDateTime } from "@/lib/utils";

/**
 * Shared profile page for every role: identity card, editable contact data and
 * password change (server-side authorization enforced by requireUser).
 */
export async function ProfilePanel({ subtitle }: { subtitle: string }) {
  const session = await requireUser();
  const record = await prisma.user.findUnique({
    where: { id: session.id },
    select: {
      fullName: true,
      username: true,
      email: true,
      phone: true,
      lastLoginAt: true,
      createdAt: true,
      status: true,
      role: { select: { name: true } },
    },
  });

  if (!record) {
    return (
      <PageHeader eyebrow="Akun" title="Profil" description="Akun tidak ditemukan." />
    );
  }

  return (
    <>
      <PageHeader
        eyebrow="Akun"
        title="Profil Saya"
        description={subtitle}
        action={<Badge tone="brand">{ROLE_LABEL[session.role]}</Badge>}
      />

      <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
        <Card>
          <CardHeader title="Informasi akun" description="Data identitas portal Anda" />
          <InfoRow label="Nama lengkap" value={record.fullName} />
          <InfoRow label="Username" value={`@${record.username}`} />
          <InfoRow label="Peran" value={record.role.name} />
          <InfoRow
            label="Status akun"
            value={<Badge tone={record.status === "ACTIVE" ? "jade" : "danger"}>{record.status}</Badge>}
          />
          <InfoRow label="Login terakhir" value={formatDateTime(record.lastLoginAt)} />
          <InfoRow label="Akun dibuat" value={formatDateTime(record.createdAt)} />
          <p className="mt-4 text-xs leading-relaxed text-ink-400">
            Perubahan data akademik (program, kelas, jadwal) dilakukan oleh administrator
            atau buzzer pada menu terkait.
          </p>
        </Card>

        <div className="space-y-5">
          <Card>
            <CardHeader
              title="Data kontak"
              description="Digunakan untuk notifikasi akademik dan koordinasi kelas"
            />
            <ProfileForm
              defaultValues={{
                fullName: record.fullName,
                email: record.email ?? "",
                phone: record.phone ?? "",
              }}
            />
          </Card>

          <Card>
            <CardHeader
              title="Ganti password"
              description="Disarankan mengganti password awal setelah login pertama"
            />
            <ChangePasswordForm />
          </Card>
        </div>
      </div>
    </>
  );
}
