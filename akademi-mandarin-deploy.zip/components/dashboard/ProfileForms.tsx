"use client";

import { useActionState } from "react";
import { changePasswordAction, updateProfileAction } from "@/lib/actions/account";
import { Alert } from "@/components/ui/Feedback";
import { Field, Input } from "@/components/ui/Form";
import { SubmitButton } from "@/components/ui/SubmitButton";
import { idleFormState } from "@/types/forms";

export function ProfileForm({
  defaultValues,
}: {
  defaultValues: { fullName: string; email: string; phone: string };
}) {
  const [state, formAction] = useActionState(updateProfileAction, idleFormState);

  return (
    <form action={formAction} className="space-y-4">
      {state.status === "error" && state.message ? (
        <Alert tone="error">{state.message}</Alert>
      ) : null}
      {state.status === "success" && state.message ? (
        <Alert tone="success">{state.message}</Alert>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Nama lengkap" htmlFor="fullName" required error={state.errors?.fullName}>
          <Input
            id="fullName"
            name="fullName"
            defaultValue={defaultValues.fullName}
            required
          />
        </Field>
        <Field label="Email" htmlFor="email" error={state.errors?.email}>
          <Input
            id="email"
            name="email"
            type="email"
            defaultValue={defaultValues.email}
          />
        </Field>
        <Field label="Nomor telepon" htmlFor="phone">
          <Input id="phone" name="phone" defaultValue={defaultValues.phone} />
        </Field>
      </div>

      <SubmitButton pendingLabel="Menyimpan...">Simpan profil</SubmitButton>
    </form>
  );
}

export function ChangePasswordForm() {
  const [state, formAction] = useActionState(changePasswordAction, idleFormState);

  return (
    <form action={formAction} className="space-y-4">
      {state.status === "error" && state.message ? (
        <Alert tone="error">{state.message}</Alert>
      ) : null}
      {state.status === "success" && state.message ? (
        <Alert tone="success">{state.message}</Alert>
      ) : null}

      <Field
        label="Password saat ini"
        htmlFor="currentPassword"
        required
        error={state.errors?.currentPassword}
      >
        <Input
          id="currentPassword"
          name="currentPassword"
          type="password"
          autoComplete="current-password"
          required
        />
      </Field>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          label="Password baru"
          htmlFor="newPassword"
          required
          error={state.errors?.newPassword}
          hint="Minimal 8 karakter, kombinasi huruf dan angka."
        >
          <Input
            id="newPassword"
            name="newPassword"
            type="password"
            autoComplete="new-password"
            required
          />
        </Field>
        <Field
          label="Konfirmasi password baru"
          htmlFor="confirmPassword"
          required
          error={state.errors?.confirmPassword}
        >
          <Input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            autoComplete="new-password"
            required
          />
        </Field>
      </div>

      <SubmitButton pendingLabel="Memperbarui..." variant="secondary">
        Ganti password
      </SubmitButton>
    </form>
  );
}
