"use client";

import Link from "next/link";
import { useEffect, useState, type ReactNode } from "react";
import { SidebarContent } from "@/components/dashboard/Sidebar";
import { Icon } from "@/components/ui/Icon";
import { SubmitButton } from "@/components/ui/SubmitButton";
import { logoutAction } from "@/lib/actions/auth";
import type { NavGroup } from "@/lib/rbac";
import { initials } from "@/lib/utils";

export interface ShellUser {
  fullName: string;
  username: string;
  roleLabel: string;
  roleHome: string;
  mustChangePassword: boolean;
}

/**
 * Shared dashboard chrome: desktop sidebar, mobile slide-over navigation,
 * plain topbar and account menu. Content differs per role.
 */
export function DashboardShell({
  nav,
  user,
  unreadNotifications = 0,
  children,
}: {
  nav: NavGroup[];
  user: ShellUser;
  unreadNotifications?: number;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, []);

  return (
    <div className="app-shell-bg min-h-screen">
      <div className="mx-auto flex w-full max-w-[110rem] gap-6 px-3 py-3 sm:px-5 sm:py-5">
        <aside className="glass sticky top-5 hidden h-[calc(100vh-2.5rem)] w-72 shrink-0 rounded-3xl p-4 lg:block">
          <SidebarContent nav={nav} roleLabel={user.roleLabel} />
        </aside>

        <div className="min-w-0 flex-1">
          <header className="glass mb-5 flex items-center justify-between gap-3 rounded-3xl px-4 py-3">
            <div className="flex min-w-0 items-center gap-3">
              <button
                type="button"
                onClick={() => setOpen(true)}
                className="flex size-10 items-center justify-center rounded-2xl border border-ink-900/10 bg-white/70 text-ink-700 lg:hidden"
                aria-label="Buka menu"
                aria-expanded={open}
              >
                <Icon name="menu" size={20} />
              </button>
              <div className="min-w-0">
                <p className="truncate text-sm font-bold text-ink-900">
                  {user.fullName}
                </p>
                <p className="truncate text-xs text-ink-500">
                  {user.roleLabel} · @{user.username}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Link
                href={user.roleHome}
                className="hidden rounded-2xl border border-ink-900/10 bg-white/70 px-3 py-2 text-xs font-semibold text-ink-600 transition hover:text-brand-700 sm:block"
              >
                Dashboard
              </Link>
              <span className="relative flex size-10 items-center justify-center rounded-2xl border border-ink-900/10 bg-white/70 text-ink-600">
                <Icon name="bell" size={18} />
                {unreadNotifications > 0 ? (
                  <span className="absolute -top-1 -right-1 flex min-w-5 items-center justify-center rounded-full bg-brand-600 px-1 text-[0.65rem] font-bold text-white">
                    {unreadNotifications > 9 ? "9+" : unreadNotifications}
                  </span>
                ) : null}
              </span>
              <span className="flex size-10 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-600 to-accent-500 text-xs font-bold text-white">
                {initials(user.fullName)}
              </span>
              <form action={logoutAction} className="hidden sm:block">
                <SubmitButton
                  variant="ghost"
                  size="sm"
                  pendingLabel="Keluar..."
                  className="rounded-2xl"
                >
                  <Icon name="logout" size={16} />
                  <span className="hidden md:inline">Keluar</span>
                </SubmitButton>
              </form>
            </div>
          </header>

          {user.mustChangePassword ? (
            <div className="mb-5 flex flex-wrap items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
              <Icon name="alert" size={17} />
              <span className="flex-1">
                Anda masih memakai password awal. Demi keamanan, segera ganti password
                Anda melalui menu <strong>Profil</strong>.
              </span>
            </div>
          ) : null}

          <main className="pb-10">{children}</main>
        </div>
      </div>

      {open ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="Tutup menu"
            className="absolute inset-0 bg-ink-900/40 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
          <div className="glass absolute top-0 left-0 h-full w-72 rounded-r-3xl p-4">
            <SidebarContent
              nav={nav}
              roleLabel={user.roleLabel}
              onNavigate={() => setOpen(false)}
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}
