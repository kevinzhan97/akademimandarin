"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon } from "@/components/ui/Icon";
import { SubmitButton } from "@/components/ui/SubmitButton";
import { logoutAction } from "@/lib/actions/auth";
import type { NavGroup } from "@/lib/rbac";
import { cn } from "@/lib/utils";

export function SidebarContent({
  nav,
  roleLabel,
  onNavigate,
}: {
  nav: NavGroup[];
  roleLabel: string;
  onNavigate?: () => void;
}) {
  const pathname = usePathname();

  return (
    <div className="flex h-full flex-col">
      <Link
        href="/"
        onClick={onNavigate}
        className="flex items-center gap-2.5 px-2 py-1"
        aria-label="Akademi Mandarin"
      >
        <Image
          src="/logo.png"
          alt="Akademi Mandarin"
          width={40}
          height={40}
          className="size-10 rounded-2xl object-contain"
        />
        <span className="block text-[0.68rem] font-semibold tracking-wide text-brand-600 uppercase">
          {roleLabel}
        </span>
      </Link>

      <nav className="mt-6 flex-1 space-y-5 overflow-y-auto pr-1" aria-label="Menu dashboard">
        {nav.map((group) => (
          <div key={group.title}>
            <p className="px-2 pb-2 text-[0.68rem] font-bold tracking-[0.16em] text-ink-400 uppercase">
              {group.title}
            </p>
            <ul className="space-y-0.5">
              {group.items.map((item) => {
                const active =
                  item.href === pathname ||
                  (item.href !== "/" && pathname.startsWith(`${item.href}/`));
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      onClick={onNavigate}
                      aria-current={active ? "page" : undefined}
                      className={cn(
                        "flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-sm font-medium transition",
                        active
                          ? "bg-gradient-to-r from-brand-600 to-accent-500 text-white shadow-[var(--shadow-brand)]"
                          : "text-ink-600 hover:bg-white/80 hover:text-brand-700",
                      )}
                    >
                      <Icon name={item.icon} size={17} />
                      <span className="truncate">{item.label}</span>
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="mt-6 border-t border-ink-900/8 pt-4">
        <form action={logoutAction}>
          <SubmitButton
            variant="ghost"
            size="sm"
            pendingLabel="Keluar..."
            className="w-full justify-start"
          >
            <Icon name="logout" size={16} />
            Keluar
          </SubmitButton>
        </form>
      </div>
    </div>
  );
}
