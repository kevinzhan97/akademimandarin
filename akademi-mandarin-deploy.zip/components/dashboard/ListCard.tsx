import Link from "next/link";
import { Badge, type BadgeTone } from "@/components/ui/Badge";
import { Card, CardHeader } from "@/components/ui/Card";
import { EmptyState } from "@/components/ui/Feedback";
import type { IconName } from "@/components/ui/Icon";

export interface ListItemView {
  id: number | string;
  title: string;
  meta?: string;
  detail?: string;
  badge?: { label: string; tone?: BadgeTone };
  trailing?: string;
}

/**
 * Dashboard list card: consistent rendering for every "recent items" panel
 * across the admin, teacher, buzzer and student dashboards.
 */
export function ListCard({
  title,
  description,
  actionHref,
  actionLabel,
  items,
  emptyIcon = "folder",
  emptyTitle = "Belum ada data",
  emptyDescription,
}: {
  title: string;
  description?: string;
  actionHref?: string;
  actionLabel?: string;
  items: ListItemView[];
  emptyIcon?: IconName;
  emptyTitle?: string;
  emptyDescription?: string;
}) {
  return (
    <Card>
      <CardHeader
        title={title}
        description={description}
        action={
          actionHref && actionLabel ? (
            <Link
              href={actionHref}
              className="text-sm font-semibold text-brand-600 hover:text-brand-700"
            >
              {actionLabel}
            </Link>
          ) : undefined
        }
      />
      {items.length === 0 ? (
        <EmptyState
          icon={emptyIcon}
          title={emptyTitle}
          description={emptyDescription}
        />
      ) : (
        <ul className="divide-y divide-ink-900/6">
          {items.map((item) => (
            <li
              key={item.id}
              className="flex items-start justify-between gap-3 py-3"
            >
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-ink-900">
                  {item.title}
                </p>
                {item.meta ? (
                  <p className="mt-0.5 text-xs text-ink-500">{item.meta}</p>
                ) : null}
                {item.detail ? (
                  <p className="mt-0.5 text-[0.7rem] text-ink-400">{item.detail}</p>
                ) : null}
              </div>
              {item.badge ? (
                <Badge tone={item.badge.tone ?? "neutral"}>{item.badge.label}</Badge>
              ) : item.trailing ? (
                <span className="text-right text-xs text-ink-500">{item.trailing}</span>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
