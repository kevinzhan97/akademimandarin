import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export type BadgeTone =
  | "brand"
  | "gold"
  | "jade"
  | "neutral"
  | "info"
  | "warning"
  | "danger";

const tones: Record<BadgeTone, string> = {
  brand: "bg-brand-50 text-brand-700 border-brand-200",
  gold: "bg-gold-300/25 text-gold-500 border-gold-300/60",
  jade: "bg-jade-400/15 text-jade-600 border-jade-400/40",
  neutral: "bg-ink-900/5 text-ink-600 border-ink-900/10",
  info: "bg-sky-50 text-sky-700 border-sky-200",
  warning: "bg-amber-50 text-amber-700 border-amber-200",
  danger: "bg-red-50 text-red-700 border-red-200",
};

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: ReactNode;
  tone?: BadgeTone;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-semibold whitespace-nowrap",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

/** Maps workflow statuses to a consistent badge tone across the dashboards. */
export function statusTone(status: string | null | undefined): BadgeTone {
  switch ((status || "").toUpperCase()) {
    case "ACTIVE":
    case "PAID":
    case "PRESENT":
    case "GRADED":
    case "CERTIFIED":
    case "ACTIVE_STUDENT":
    case "COMPLETED":
      return "jade";
    case "PENDING":
    case "IN_PROGRESS":
    case "PLANNED":
    case "PROSPECT":
    case "TRIAL":
      return "warning";
    case "OVERDUE":
    case "LOST":
    case "ABSENT":
    case "SUSPENDED":
    case "CANCELLED":
    case "DROPPED":
      return "danger";
    case "READY":
    case "SUBMITTED":
    case "INTERESTED":
    case "ENROLLED":
    case "PAUSED":
      return "info";
    default:
      return "neutral";
  }
}
