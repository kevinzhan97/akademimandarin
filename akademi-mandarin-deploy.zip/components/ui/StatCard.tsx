import type { ReactNode } from "react";
import { Icon, type IconName } from "@/components/ui/Icon";
import { cn, percent } from "@/lib/utils";

export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = "brand",
  href,
  className,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  icon?: IconName;
  tone?: "brand" | "gold" | "jade" | "ink";
  href?: string;
  className?: string;
}) {
  const toneStyles = {
    brand: "bg-brand-50 text-brand-600",
    gold: "bg-gold-300/25 text-gold-500",
    jade: "bg-jade-400/15 text-jade-600",
    ink: "bg-ink-900/5 text-ink-700",
  } as const;

  const content = (
    <>
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-semibold tracking-wide text-ink-500 uppercase">
          {label}
        </p>
        {icon ? (
          <span
            className={cn(
              "flex size-9 items-center justify-center rounded-xl",
              toneStyles[tone],
            )}
          >
            <Icon name={icon} size={18} />
          </span>
        ) : null}
      </div>
      <p className="mt-3 text-2xl font-extrabold text-ink-900 sm:text-3xl">{value}</p>
      {hint ? <p className="mt-1 text-xs text-ink-500">{hint}</p> : null}
    </>
  );

  return (
    <div
      className={cn(
        "card-surface p-5",
        href && "transition hover:-translate-y-1 hover:shadow-lg",
        className,
      )}
    >
      {href ? <a href={href}>{content}</a> : content}
    </div>
  );
}

export function ProgressBar({
  value,
  max = 100,
  label,
  hint,
  tone = "brand",
  className,
}: {
  value: number;
  max?: number;
  label?: ReactNode;
  hint?: ReactNode;
  tone?: "brand" | "jade" | "gold";
  className?: string;
}) {
  const pct = percent(Number(value) || 0, Number(max) || 100);
  const barTone = {
    brand: "bg-gradient-to-r from-brand-600 to-accent-500",
    jade: "bg-gradient-to-r from-jade-500 to-jade-400",
    gold: "bg-gradient-to-r from-gold-500 to-gold-400",
  } as const;

  return (
    <div className={cn("w-full", className)}>
      {label || hint ? (
        <div className="mb-2 flex items-center justify-between gap-3 text-sm">
          <span className="font-semibold text-ink-700">{label}</span>
          <span className="text-ink-500">{hint ?? `${pct}%`}</span>
        </div>
      ) : null}
      <div
        className="h-2.5 w-full overflow-hidden rounded-full bg-ink-900/8"
        role="progressbar"
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div
          className={cn("h-full rounded-full transition-all duration-700", barTone[tone])}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export function InfoRow({
  label,
  value,
  className,
}: {
  label: ReactNode;
  value: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-start justify-between gap-4 border-b border-ink-900/6 py-2.5 last:border-0",
        className,
      )}
    >
      <span className="text-sm text-ink-500">{label}</span>
      <span className="text-right text-sm font-semibold text-ink-800">{value}</span>
    </div>
  );
}
