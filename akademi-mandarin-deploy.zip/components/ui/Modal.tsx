"use client";

import { useEffect, useState, type ReactNode } from "react";
import { buttonClass, type ButtonSize, type ButtonVariant } from "@/components/ui/Button";
import { Icon, type IconName } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

/**
 * Accessible modal dialog with a built-in trigger button.
 * Server-rendered forms can be passed as children (server actions still run).
 */
export function Modal({
  triggerLabel,
  triggerIcon = "plus",
  triggerVariant = "primary",
  triggerSize = "md",
  triggerClassName,
  title,
  description,
  children,
  size = "md",
}: {
  triggerLabel: string;
  triggerIcon?: IconName;
  triggerVariant?: ButtonVariant;
  triggerSize?: ButtonSize;
  triggerClassName?: string;
  title: string;
  description?: string;
  children: ReactNode;
  size?: "sm" | "md" | "lg";
}) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  const widthClass = {
    sm: "max-w-md",
    md: "max-w-2xl",
    lg: "max-w-4xl",
  }[size];

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={buttonClass(triggerVariant, triggerSize, triggerClassName)}
      >
        <Icon name={triggerIcon} size={16} />
        {triggerLabel}
      </button>

      {open ? (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-ink-900/45 p-4 backdrop-blur-sm sm:items-center"
          role="dialog"
          aria-modal="true"
          aria-label={title}
        >
          <button
            type="button"
            aria-label="Tutup dialog"
            className="absolute inset-0 cursor-default"
            onClick={() => setOpen(false)}
          />
          <div
            className={cn(
              "relative z-10 my-8 w-full rounded-3xl border border-white/70 bg-white p-6 shadow-2xl",
              widthClass,
            )}
          >
            <div className="mb-4 flex items-start justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-ink-900">{title}</h2>
                {description ? (
                  <p className="mt-1 text-sm text-ink-500">{description}</p>
                ) : null}
              </div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Tutup"
                className="rounded-full p-1.5 text-ink-400 transition hover:bg-ink-900/5 hover:text-ink-700"
              >
                <Icon name="close" size={18} />
              </button>
            </div>
            {children}
          </div>
        </div>
      ) : null}
    </>
  );
}
