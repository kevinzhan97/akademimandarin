import type { SVGProps } from "react";

/**
 * Inline SVG icon set (no icon dependency, tree-shakeable, zero runtime cost).
 * Paths use a 24x24 viewBox with currentColor stroke.
 */
const ICONS = {
  dashboard: "M3 3h7v7H3zM14 3h7v5h-7zM14 12h7v9h-7zM3 14h7v7H3z",
  home: "M4 10.5 12 3l8 7.5V20a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z",
  users: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.87",
  user: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8",
  teacher: "M2 7h20v11H2zM8 18v3M16 18v3M12 7V4",
  headset: "M4 14v-3a8 8 0 0 1 16 0v3M4 14h3v5H5a1 1 0 0 1-1-1zM20 14h-3v5h2a1 1 0 0 0 1-1z",
  book: "M4 4h6a3 3 0 0 1 3 3v13a2.5 2.5 0 0 0-2.5-2.5H4zM20 4h-4a3 3 0 0 0-3 3v13a2.5 2.5 0 0 1 2.5-2.5H20z",
  bookOpen: "M12 7v14M3 6h6a3 3 0 0 1 3 3M21 6h-6a3 3 0 0 0-3 3M3 6v14h6M21 6v14h-6",
  graduation: "M22 9 12 4 2 9l10 5zM6 11.5V17c0 1.7 2.7 3 6 3s6-1.3 6-3v-5.5",
  clipboard: "M9 3h6v3H9zM7 5H5v16h14V5h-2M9 12h6M9 16h4",
  checklist: "M4 6h2M4 12h2M4 18h2M9 6h11M9 12h11M9 18h11",
  calendar: "M4 6h16v15H4zM4 10h16M8 3v4M16 3v4",
  clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 7v5l3.5 2",
  check: "M4 12.5 9 18 20 6",
  checkCircle: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M8.5 12.5 11 15l4.5-5",
  trending: "M3 17 9 11l4 4 8-8M15 7h6v6",
  chart: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  target: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2",
  wallet: "M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H3zM3 7V5a2 2 0 0 1 2-2h12M16 13h2",
  receipt: "M6 3h12v18l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6",
  message: "M21 12a8 8 0 0 1-8 8H8l-5 3 1.5-5A8 8 0 0 1 13 4a8 8 0 0 1 8 8",
  megaphone: "M3 11v3l12 5V6zM15 8a3 3 0 0 1 0 6M6 14v6h3l1-5",
  bell: "M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6M10 20a2 2 0 0 0 4 0",
  settings: "M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.2A1.6 1.6 0 0 0 7.5 19l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3.6 13H3a2 2 0 1 1 0-4h.2A1.6 1.6 0 0 0 5 7.5l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 10.5 3.6V3a2 2 0 1 1 4 0v.2A1.6 1.6 0 0 0 17 5l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 1.1 2.7H21a2 2 0 1 1 0 4h-.2a1.6 1.6 0 0 0-1.4 1.5z",
  logout: "M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 8l-4 4 4 4M6 12h11",
  plus: "M12 5v14M5 12h14",
  edit: "M4 20h4l11-11-4-4L4 16zM14 5l4 4",
  trash: "M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14M10 11v6M14 11v6",
  eye: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
  search: "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16M21 21l-4.5-4.5",
  filter: "M3 5h18l-7 8v6l-4-2v-4z",
  download: "M12 3v12M7 11l5 5 5-5M4 20h16",
  upload: "M12 21V9M7 13l5-5 5 5M4 3h16",
  folder: "M3 6h6l2 2h10v11H3z",
  file: "M6 3h8l4 4v14H6zM14 3v4h4",
  link: "M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1",
  external: "M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5",
  globe: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M3 12h18M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18",
  language: "M4 6h10M9 4v2c0 5-2.5 8-5 9M6 11c1.5 4 4 6 7 7M13 20l4-10 4 10M14.5 17h5",
  mic: "M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3M5 11v1a7 7 0 0 0 14 0v-1M12 19v3M8 22h8",
  headphones: "M4 14v-2a8 8 0 0 1 16 0v2M4 14h3v5H5a1 1 0 0 1-1-1zM20 14h-3v5h2a1 1 0 0 0 1-1z",
  pen: "M16 3l5 5L8 21H3v-5zM14 5l5 5",
  brain: "M9 4a3 3 0 0 0-3 3 3 3 0 0 0-1 5.8V16a3 3 0 0 0 4 2.8V20h2V4zM15 4a3 3 0 0 1 3 3 3 3 0 0 1 1 5.8V16a3 3 0 0 1-4 2.8V20h-2V4z",
  play: "M6 4l14 8-14 8z",
  arrowRight: "M4 12h15M13 6l6 6-6 6",
  arrowLeft: "M20 12H5M11 6l-6 6 6 6",
  chevronDown: "M6 9l6 6 6-6",
  chevronRight: "M9 6l6 6-6 6",
  chevronLeft: "M15 6l-6 6 6 6",
  menu: "M4 7h16M4 12h16M4 17h16",
  close: "M6 6l12 12M18 6L6 18",
  phone: "M5 3h3l2 5-2.5 1.5a12 12 0 0 0 6 6L15 13l5 2v3a2 2 0 0 1-2 2A15 15 0 0 1 3 5a2 2 0 0 1 2-2",
  mail: "M3 6h18v12H3zM3 6l9 7 9-7",
  mapPin: "M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11M12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
  instagram: "M4 4h16v16H4zM12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7M17 7h.01",
  facebook: "M14 8h3V4h-3a5 5 0 0 0-5 5v2H7v4h2v5h4v-5h3l1-4h-4V9a1 1 0 0 1 1-1",
  youtube: "M2 8a3 3 0 0 1 3-3h14a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3zM11 9l4 3-4 3z",
  whatsapp: "M12 3a9 9 0 0 0-7.7 13.6L3 21l4.5-1.3A9 9 0 1 0 12 3M8.5 9.5c0 3 2.5 5.5 5.5 5.5l1-1.5-2-1-1 1c-1-.5-1.5-1-2-2l1-1-1-2z",
  tiktok: "M14 4v10.5a3.5 3.5 0 1 1-3.5-3.5c.2 0 .4 0 .5.1M14 4c.5 2.5 2 4 4.5 4.2",
  shield: "M12 3l8 3v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6zM9 12l2 2 4-4",
  award: "M12 15a5 5 0 1 0 0-10 5 5 0 0 0 0 10M8.5 14 7 22l5-3 5 3-1.5-8",
  sparkles: "M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8zM19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z",
  plane: "M10 21l2-6 8-8a2.8 2.8 0 0 0-4-4l-8 8-6 2 3 1 2 2 1 3z",
  briefcase: "M3 8h18v12H3zM8 8V5h8v3M3 13h18",
  palette: "M12 3a9 9 0 0 0 0 18c1.5 0 2-1 1.5-2-.6-1.2.3-2.5 1.7-2.5H18a3 3 0 0 0 3-3c0-5.8-4-10.5-9-10.5M7.5 11a1 1 0 1 0 0-2 1 1 0 0 0 0 2M11 8a1 1 0 1 0 0-2 1 1 0 0 0 0 2M15 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2",
  lock: "M6 11h12v10H6zM9 11V7a3 3 0 0 1 6 0v4M12 15v3",
  key: "M15 3a6 6 0 0 0-5.6 8.2L3 18v3h3l1-1v-2h2v-2h2l1.4-1.4A6 6 0 1 0 15 3M16 8h.01",
  refresh: "M20 11a8 8 0 1 0-2.3 6.3M20 20v-5h-5",
  puzzle: "M10 4h4v3a2 2 0 1 0 4 0h3v4h-3a2 2 0 1 0 0 4h3v4H10v-3a2 2 0 1 0-4 0H4v-4h3a2 2 0 1 0 0-4H4V7h3a2 2 0 1 1 3-3",
  quiz: "M5 4h14v16H5zM9 9h6M9 13h6M9 17h3",
  compass: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M15.5 8.5l-2 5-5 2 2-5z",
  info: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18M12 11v6M12 8h.01",
  alert: "M12 3l9 17H3zM12 10v5M12 18h.01",
} as const;

export type IconName = keyof typeof ICONS;

interface IconProps extends Omit<SVGProps<SVGSVGElement>, "name"> {
  name: IconName;
  size?: number;
}

export function Icon({ name, size = 20, className, ...rest }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      className={className}
      {...rest}
    >
      <path d={ICONS[name]} />
    </svg>
  );
}
