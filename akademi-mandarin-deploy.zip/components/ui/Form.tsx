import type { ComponentProps, ReactNode } from "react";
import { cn } from "@/lib/utils";

const controlClass =
  "w-full rounded-xl border border-ink-900/12 bg-white/85 px-3.5 py-2.5 text-sm text-ink-800 shadow-sm transition placeholder:text-ink-400 focus:border-brand-400 focus:ring-2 focus:ring-brand-100 focus:outline-none disabled:bg-ink-900/5";

export function Label({
  htmlFor,
  children,
  required,
  className,
}: {
  htmlFor?: string;
  children: ReactNode;
  required?: boolean;
  className?: string;
}) {
  return (
    <label
      htmlFor={htmlFor}
      className={cn("mb-1.5 block text-sm font-semibold text-ink-700", className)}
    >
      {children}
      {required ? <span className="ml-0.5 text-brand-600">*</span> : null}
    </label>
  );
}

export function Field({
  label,
  htmlFor,
  required,
  error,
  hint,
  children,
  className,
}: {
  label?: string;
  htmlFor?: string;
  required?: boolean;
  error?: string | null;
  hint?: string | null;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("w-full", className)}>
      {label ? (
        <Label htmlFor={htmlFor} required={required}>
          {label}
        </Label>
      ) : null}
      {children}
      {hint && !error ? (
        <p className="mt-1 text-xs text-ink-400">{hint}</p>
      ) : null}
      {error ? (
        <p role="alert" className="mt-1 text-xs font-medium text-red-600">
          {error}
        </p>
      ) : null}
    </div>
  );
}

export function Input({ className, ...rest }: ComponentProps<"input">) {
  return <input className={cn(controlClass, className)} {...rest} />;
}

export function Textarea({ className, ...rest }: ComponentProps<"textarea">) {
  return (
    <textarea
      rows={4}
      className={cn(controlClass, "resize-y", className)}
      {...rest}
    />
  );
}

export function Select({ className, children, ...rest }: ComponentProps<"select">) {
  return (
    <select className={cn(controlClass, "pr-8", className)} {...rest}>
      {children}
    </select>
  );
}

interface SelectOption {
  value: string | number;
  label: string;
}

export function SelectField({
  name,
  label,
  options,
  defaultValue,
  required,
  placeholder,
  error,
  hint,
  id,
}: {
  name: string;
  label?: string;
  options: SelectOption[];
  defaultValue?: string | number | null;
  required?: boolean;
  placeholder?: string;
  error?: string | null;
  hint?: string | null;
  id?: string;
}) {
  const fieldId = id ?? name;
  return (
    <Field label={label} htmlFor={fieldId} required={required} error={error} hint={hint}>
      <Select
        id={fieldId}
        name={name}
        required={required}
        defaultValue={defaultValue ?? ""}
      >
        {placeholder ? <option value="">{placeholder}</option> : null}
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </Select>
    </Field>
  );
}
