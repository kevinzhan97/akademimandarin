import Link from "next/link";
import type { ReactNode } from "react";
import { Icon, type IconName } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

export type AlertTone = "success" | "error" | "info" | "warning";

const alertTones: Record<AlertTone, { wrapper: string; icon: IconName }> = {
  success: { wrapper: "border-jade-400/40 bg-jade-400/10 text-jade-600", icon: "checkCircle" },
  error: { wrapper: "border-red-200 bg-red-50 text-red-700", icon: "alert" },
  info: { wrapper: "border-sky-200 bg-sky-50 text-sky-700", icon: "info" },
  warning: { wrapper: "border-amber-200 bg-amber-50 text-amber-700", icon: "alert" },
};

export function Alert({
  tone = "info",
  title,
  children,
  className,
}: {
  tone?: AlertTone;
  title?: ReactNode;
  children?: ReactNode;
  className?: string;
}) {
  const config = alertTones[tone];
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={cn(
        "flex items-start gap-3 rounded-2xl border px-4 py-3 text-sm",
        config.wrapper,
        className,
      )}
    >
      <Icon name={config.icon} className="mt-0.5 shrink-0" size={18} />
      <div className="space-y-1">
        {title ? <p className="font-semibold">{title}</p> : null}
        {children ? <div className="leading-relaxed">{children}</div> : null}
      </div>
    </div>
  );
}

export function EmptyState({
  icon = "folder",
  title,
  description,
  actionLabel,
  actionHref,
  children,
  className,
}: {
  icon?: IconName;
  title: string;
  description?: string;
  actionLabel?: string;
  actionHref?: string;
  children?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center rounded-3xl border border-dashed border-ink-900/12 bg-white/60 px-6 py-12 text-center",
        className,
      )}
    >
      <span className="mb-4 flex size-12 items-center justify-center rounded-2xl bg-brand-50 text-brand-600">
        <Icon name={icon} size={22} />
      </span>
      <h3 className="text-base font-bold text-ink-900">{title}</h3>
      {description ? (
        <p className="mt-2 max-w-md text-sm text-ink-500">{description}</p>
      ) : null}
      {actionLabel && actionHref ? (
        <Link
          href={actionHref}
          className="mt-5 inline-flex items-center gap-2 rounded-full bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-700"
        >
          {actionLabel}
        </Link>
      ) : null}
      {children ? <div className="mt-5 w-full">{children}</div> : null}
    </div>
  );
}
