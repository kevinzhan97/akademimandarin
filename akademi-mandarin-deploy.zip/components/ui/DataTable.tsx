import Link from "next/link";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export interface Column<T> {
  key: string;
  header: ReactNode;
  render: (row: T) => ReactNode;
  className?: string;
  align?: "left" | "center" | "right";
  hideOnMobile?: boolean;
}

const alignClass = {
  left: "text-left",
  center: "text-center",
  right: "text-right",
} as const;

/**
 * Server-rendered data table.
 * Responsive strategy: horizontal scroll container (keeps columns readable on
 * mobile without duplicating markup).
 */
export function DataTable<T>({
  columns,
  rows,
  getRowId,
  empty,
  footer,
  className,
}: {
  columns: Column<T>[];
  rows: T[];
  getRowId: (row: T, index: number) => string | number;
  empty?: ReactNode;
  footer?: ReactNode;
  className?: string;
}) {
  if (rows.length === 0 && empty) {
    return <>{empty}</>;
  }

  return (
    <div className={cn("card-surface overflow-hidden p-0", className)}>
      <div className="table-scroll">
        <table className="w-full min-w-[46rem] border-collapse text-sm">
          <thead>
            <tr className="border-b border-ink-900/8 bg-ink-900/[0.03]">
              {columns.map((column) => (
                <th
                  key={column.key}
                  scope="col"
                  className={cn(
                    "px-4 py-3 text-xs font-bold tracking-wide text-ink-500 uppercase",
                    alignClass[column.align ?? "left"],
                    column.hideOnMobile && "hidden md:table-cell",
                    column.className,
                  )}
                >
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr
                key={getRowId(row, index)}
                className="border-b border-ink-900/6 transition last:border-0 hover:bg-brand-50/40"
              >
                {columns.map((column) => (
                  <td
                    key={column.key}
                    className={cn(
                      "px-4 py-3 align-middle text-ink-700",
                      alignClass[column.align ?? "left"],
                      column.hideOnMobile && "hidden md:table-cell",
                      column.className,
                    )}
                  >
                    {column.render(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
          {footer ? <tfoot>{footer}</tfoot> : null}
        </table>
      </div>
    </div>
  );
}

export function Pagination({
  page,
  pageCount,
  basePath,
  query = {},
}: {
  page: number;
  pageCount: number;
  basePath: string;
  query?: Record<string, string | undefined>;
}) {
  if (pageCount <= 1) return null;

  const buildHref = (target: number) => {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(query)) {
      if (value) params.set(key, value);
    }
    if (target > 1) params.set("page", String(target));
    const search = params.toString();
    return search ? `${basePath}?${search}` : basePath;
  };

  const pages: number[] = [];
  const start = Math.max(1, page - 2);
  const end = Math.min(pageCount, start + 4);
  for (let index = start; index <= end; index += 1) pages.push(index);

  return (
    <nav
      className="mt-4 flex flex-wrap items-center justify-between gap-3"
      aria-label="Navigasi halaman"
    >
      <p className="text-xs text-ink-500">
        Halaman {page} dari {pageCount}
      </p>
      <div className="flex items-center gap-1">
        <Link
          href={buildHref(Math.max(1, page - 1))}
          aria-disabled={page === 1}
          className={cn(
            "rounded-lg border border-ink-900/10 px-3 py-1.5 text-sm font-medium transition",
            page === 1
              ? "pointer-events-none opacity-40"
              : "hover:border-brand-300 hover:text-brand-700",
          )}
        >
          Sebelumnya
        </Link>
        {pages.map((item) => (
          <Link
            key={item}
            href={buildHref(item)}
            aria-current={item === page ? "page" : undefined}
            className={cn(
              "rounded-lg px-3 py-1.5 text-sm font-semibold transition",
              item === page
                ? "bg-brand-600 text-white"
                : "border border-ink-900/10 hover:border-brand-300 hover:text-brand-700",
            )}
          >
            {item}
          </Link>
        ))}
        <Link
          href={buildHref(Math.min(pageCount, page + 1))}
          aria-disabled={page === pageCount}
          className={cn(
            "rounded-lg border border-ink-900/10 px-3 py-1.5 text-sm font-medium transition",
            page === pageCount
              ? "pointer-events-none opacity-40"
              : "hover:border-brand-300 hover:text-brand-700",
          )}
        >
          Berikutnya
        </Link>
      </div>
    </nav>
  );
}
