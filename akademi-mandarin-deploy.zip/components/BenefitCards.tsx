import { BenefitCard, type BenefitCardData } from "@/components/BenefitCard";
import { cn } from "@/lib/utils";

const benefits: BenefitCardData[] = [
  {
    icon: "briefcase",
    hanzi: "工作",
    title: "Karier",
    description: "Tingkatkan peluang di dunia kerja global.",
    href: "/mengapa-mandarin",
  },
  {
    icon: "graduation",
    hanzi: "教育",
    title: "Pendidikan",
    description: "Akses ke lebih banyak kesempatan belajar.",
    href: "/mengapa-mandarin",
  },
  {
    icon: "chart",
    hanzi: "商务",
    title: "Bisnis",
    description: "Jalin relasi lebih luas.",
    href: "/mengapa-mandarin",
  },
  {
    icon: "plane",
    hanzi: "旅游",
    title: "Travel",
    description: "Jelajahi dunia dengan lebih percaya diri.",
    href: "/mengapa-mandarin",
  },
  {
    icon: "palette",
    hanzi: "文化",
    title: "Budaya",
    description: "Pahami budaya dengan lebih mendalam.",
    href: "/mengapa-mandarin",
  },
];

/** Five benefit cards plus the highlighted red call-to-action card. */
export function BenefitCards({ className }: { className?: string }) {
  return (
    <ul
      className={cn(
        "grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-6",
        className,
      )}
    >
      {benefits.map((benefit) => (
        <li key={benefit.title} className="flex">
          <BenefitCard {...benefit} />
        </li>
      ))}
      <li className="col-span-2 flex sm:col-span-1">
        <BenefitCard
          highlighted
          icon="sparkles"
          hanzi="开始"
          title="Mulai Perjalanan Mandarin Anda"
          description="Pilih program yang sesuai dengan tujuan Anda."
          href="/mulai-sekarang"
          ctaLabel="Mulai Sekarang"
        />
      </li>
    </ul>
  );
}
