import Link from "next/link";
import { Icon, type IconName } from "@/components/ui/Icon";
import { cn } from "@/lib/utils";

export interface BenefitCardData {
  icon: IconName;
  hanzi: string;
  title: string;
  description: string;
  href: string;
  ctaLabel?: string;
}

/**
 * Glassmorphism benefit card over the wallpaper. `highlighted` renders the red
 * "Mulai Perjalanan" card that closes the row.
 */
export function BenefitCard({
  icon,
  hanzi,
  title,
  description,
  href,
  ctaLabel,
  highlighted = false,
}: BenefitCardData & { highlighted?: boolean }) {
  return (
    <Link
      href={href}
      className={cn(
        "group flex h-full flex-col rounded-2xl p-3.5 transition-all duration-300 hover:-translate-y-1 sm:rounded-3xl sm:p-4",
        highlighted
          ? "bg-gradient-to-br from-brand-600 via-brand-600 to-accent-500 text-white shadow-[var(--shadow-brand)] hover:brightness-110"
          : "glass-soft hover:border-brand-300 hover:shadow-[var(--shadow-glass)]",
      )}
    >
      <span
        className={cn(
          "flex size-9 items-center justify-center rounded-xl sm:rounded-2xl",
          highlighted
            ? "bg-white/20 text-white"
            : "bg-gradient-to-br from-brand-600 to-accent-500 text-white",
        )}
      >
        <Icon name={icon} size={18} />
      </span>

      {hanzi ? (
        <span
          aria-hidden="true"
          className={cn(
            "font-cjk mt-2.5 text-base leading-none",
            highlighted ? "text-white/75" : "text-brand-600/75",
          )}
        >
          {hanzi}
        </span>
      ) : null}

      <span
        className={cn(
          "mt-1.5 text-[0.8rem] font-extrabold",
          highlighted
            ? "tracking-tight text-white"
            : "tracking-[0.1em] text-ink-900 uppercase transition group-hover:text-brand-700",
        )}
      >
        {title}
      </span>

      <span
        className={cn(
          "mt-1.5 text-[0.7rem] leading-relaxed",
          highlighted ? "text-white/85" : "text-ink-600",
        )}
      >
        {description}
      </span>

      <span
        className={cn(
          "mt-auto inline-flex items-center gap-1 pt-2.5 text-[0.62rem] font-bold tracking-wider uppercase",
          highlighted ? "text-white" : "text-brand-600",
        )}
      >
        {ctaLabel ?? "Selengkapnya"}
        <Icon
          name="arrowRight"
          size={13}
          className="transition group-hover:translate-x-0.5"
        />
      </span>
    </Link>
  );
}
