import { z } from "zod";
import { PASSWORD_MIN_LENGTH } from "@/lib/password";

/** Converts a ZodError into `{ field: firstMessage }` for form rendering. */
export function zodFieldErrors(error: z.ZodError): Record<string, string> {
  const result: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = issue.path.join(".") || "form";
    if (!result[key]) result[key] = issue.message;
  }
  return result;
}

const optionalEmail = z
  .string()
  .trim()
  .max(160, "Email terlalu panjang.")
  .optional()
  .refine(
    (value) => !value || z.email().safeParse(value).success,
    "Format email tidak valid.",
  );

export const phoneField = z
  .string()
  .trim()
  .min(9, "Nomor minimal 9 digit.")
  .max(25, "Nomor terlalu panjang.")
  .regex(/^[0-9+()\s.-]+$/, "Nomor hanya boleh berisi angka dan simbol + - ( ) .");

/** Authentication */
export const loginSchema = z.object({
  identifier: z
    .string()
    .trim()
    .min(3, "Username minimal 3 karakter.")
    .max(191, "Username terlalu panjang."),
  password: z
    .string()
    .min(PASSWORD_MIN_LENGTH, `Password minimal ${PASSWORD_MIN_LENGTH} karakter.`)
    .max(200, "Password terlalu panjang."),
});

export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, "Password saat ini wajib diisi."),
    newPassword: z
      .string()
      .min(PASSWORD_MIN_LENGTH, `Password minimal ${PASSWORD_MIN_LENGTH} karakter.`)
      .max(200, "Password terlalu panjang.")
      .regex(/[A-Za-z]/, "Password harus mengandung huruf.")
      .regex(/[0-9]/, "Password harus mengandung angka."),
    confirmPassword: z.string().min(1, "Konfirmasi password wajib diisi."),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    path: ["confirmPassword"],
    message: "Konfirmasi password tidak sama.",
  });

/** Public lead capture (company profile → CRM) */
export const publicLeadSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Nama minimal 2 karakter.")
    .max(120, "Nama terlalu panjang."),
  phone: phoneField,
  email: optionalEmail,
  programId: z.string().trim().optional(),
  currentLevel: z.string().trim().max(80, "Terlalu panjang.").optional(),
  notes: z.string().trim().max(2000, "Catatan terlalu panjang.").optional(),
});

export type PublicLeadInput = z.infer<typeof publicLeadSchema>;

export { optionalEmail };
