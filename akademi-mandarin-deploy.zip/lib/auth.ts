import { redirect } from "next/navigation";
import { ROLE_HOME } from "@/lib/rbac";
import { getSessionUser } from "@/lib/session";
import type { RoleCode, SessionUser } from "@/types/auth";

export { getSessionUser };

/**
 * Server-side authorization helpers.
 * Every dashboard layout, page, server action and route handler must go through
 * one of these - hiding menu items in the UI is never enough.
 */

export async function requireUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  return user;
}

/** Requires one of the given roles. Users of another role are sent to their own dashboard. */
export async function requireRole(...roles: RoleCode[]): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (!roles.includes(user.role)) redirect(ROLE_HOME[user.role]);
  return user;
}

export class UnauthorizedError extends Error {
  constructor(message = "Unauthorized") {
    super(message);
    this.name = "UnauthorizedError";
  }
}

/** For route handlers: throws instead of redirecting. */
export async function requireApiRole(...roles: RoleCode[]): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user || !roles.includes(user.role)) {
    throw new UnauthorizedError();
  }
  return user;
}
