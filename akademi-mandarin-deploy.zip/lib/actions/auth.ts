"use server";

import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { isRoleCode, ROLE_HOME } from "@/lib/rbac";
import { verifyPassword } from "@/lib/password";
import { checkLoginThrottle, clearLoginAttempts, recordLoginAttempt } from "@/lib/rate-limit";
import { createSession, destroyCurrentSession, getRequestMeta } from "@/lib/session";
import { loginSchema, zodFieldErrors } from "@/lib/validators";
import type { FormState } from "@/types/forms";

const INVALID_CREDENTIALS =
  "Username atau password salah. Periksa kembali atau hubungi administrator.";

export async function loginAction(
  _previous: FormState,
  formData: FormData,
): Promise<FormState> {
  const parsed = loginSchema.safeParse({
    identifier: formData.get("identifier") ?? "",
    password: formData.get("password") ?? "",
  });

  if (!parsed.success) {
    return {
      status: "error",
      message: "Periksa kembali data login Anda.",
      errors: zodFieldErrors(parsed.error),
    };
  }

  const identifier = parsed.data.identifier.trim().toLowerCase();
  const meta = await getRequestMeta();

  const throttle = await checkLoginThrottle(identifier);
  if (!throttle.allowed) {
    return {
      status: "error",
      message: `Terlalu banyak percobaan gagal. Coba lagi dalam ${throttle.retryAfterMinutes} menit.`,
    };
  }

  const user = await prisma.user.findFirst({
    where: { OR: [{ username: identifier }, { email: identifier }] },
    include: { role: true },
  });

  const passwordValid =
    user !== null && (await verifyPassword(parsed.data.password, user.passwordHash));

  if (!user || !passwordValid) {
    await recordLoginAttempt({ identifier, success: false, ...meta });
    if (user && user.failedLoginAttempts + 1 >= 5) {
      await prisma.user.update({
        where: { id: user.id },
        data: { failedLoginAttempts: { increment: 1 } },
      });
    }
    return {
      status: "error",
      message: INVALID_CREDENTIALS,
      errors: throttle.remainingAttempts <= 2 && throttle.remainingAttempts > 0
        ? { password: `Sisa percobaan sebelum akun terkunci sementara: ${throttle.remainingAttempts}.` }
        : undefined,
    };
  }

  if (user.status !== "ACTIVE") {
    await recordLoginAttempt({ identifier, success: false, ...meta });
    return {
      status: "error",
      message:
        "Akun Anda tidak aktif. Hubungi administrator Akademi Mandarin untuk mengaktifkan kembali.",
    };
  }

  if (user.lockedUntil && user.lockedUntil.getTime() > Date.now()) {
    return {
      status: "error",
      message: "Akun Anda terkunci sementara karena percobaan login gagal berulang.",
    };
  }

  if (!isRoleCode(user.role.code)) {
    return {
      status: "error",
      message: "Peran akun tidak dikenali. Hubungi administrator Akademi Mandarin.",
    };
  }

  await createSession(user.id, meta);
  await prisma.user.update({
    where: { id: user.id },
    data: {
      lastLoginAt: new Date(),
      failedLoginAttempts: 0,
      lockedUntil: null,
    },
  });
  await recordLoginAttempt({ identifier, success: true, ...meta });
  await clearLoginAttempts(identifier);

  redirect(ROLE_HOME[user.role.code]);
}

export async function logoutAction(): Promise<void> {
  await destroyCurrentSession();
  redirect("/login");
}
