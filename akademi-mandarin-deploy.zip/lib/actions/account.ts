"use server";

import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser } from "@/lib/auth";
import { hashPassword, validatePasswordStrength, verifyPassword } from "@/lib/password";
import { createSession, destroyAllSessionsForUser, getRequestMeta } from "@/lib/session";
import { changePasswordSchema, zodFieldErrors } from "@/lib/validators";
import type { FormState } from "@/types/forms";

/** Updates the signed-in user's own profile (name, email, phone). */
export async function updateProfileAction(
  _previous: FormState,
  formData: FormData,
): Promise<FormState> {
  const user = await requireUser();

  const fullName = String(formData.get("fullName") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim();
  const phone = String(formData.get("phone") ?? "").trim();

  const errors: Record<string, string> = {};
  if (fullName.length < 2) errors.fullName = "Nama minimal 2 karakter.";
  if (email && !z.email().safeParse(email).success) {
    errors.email = "Format email tidak valid.";
  }
  if (Object.keys(errors).length > 0) {
    return { status: "error", message: "Periksa kembali data Anda.", errors };
  }

  if (email) {
    const duplicate = await prisma.user.findFirst({
      where: { email, NOT: { id: user.id } },
      select: { id: true },
    });
    if (duplicate) {
      return {
        status: "error",
        message: "Email sudah digunakan akun lain.",
        errors: { email: "Email sudah digunakan." },
      };
    }
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { fullName, email: email || null, phone: phone || null },
  });

  return { status: "success", message: "Profil berhasil diperbarui." };
}

/** Changes the signed-in user's password and rotates every other session. */
export async function changePasswordAction(
  _previous: FormState,
  formData: FormData,
): Promise<FormState> {
  const user = await requireUser();

  const parsed = changePasswordSchema.safeParse({
    currentPassword: formData.get("currentPassword") ?? "",
    newPassword: formData.get("newPassword") ?? "",
    confirmPassword: formData.get("confirmPassword") ?? "",
  });

  if (!parsed.success) {
    return {
      status: "error",
      message: "Periksa kembali data Anda.",
      errors: zodFieldErrors(parsed.error),
    };
  }

  const record = await prisma.user.findUnique({
    where: { id: user.id },
    select: { passwordHash: true },
  });
  if (!record) {
    return { status: "error", message: "Akun tidak ditemukan." };
  }

  const currentValid = await verifyPassword(
    parsed.data.currentPassword,
    record.passwordHash,
  );
  if (!currentValid) {
    return {
      status: "error",
      message: "Password saat ini tidak sesuai.",
      errors: { currentPassword: "Password saat ini tidak sesuai." },
    };
  }

  const strength = validatePasswordStrength(parsed.data.newPassword);
  if (strength) {
    return { status: "error", message: strength, errors: { newPassword: strength } };
  }

  await prisma.user.update({
    where: { id: user.id },
    data: {
      passwordHash: await hashPassword(parsed.data.newPassword),
      mustChangePassword: false,
    },
  });

  // Security: drop every existing session, then re-issue one for this device.
  await destroyAllSessionsForUser(user.id);
  await createSession(user.id, await getRequestMeta());

  return {
    status: "success",
    message: "Password berhasil diperbarui. Sesi di perangkat lain telah diakhiri.",
  };
}
