import type { IconName } from "@/components/ui/Icon";
import { ROLES, ROLE_CODES, type RoleCode } from "@/types/auth";

export const ROLE_HOME: Record<RoleCode, string> = {
  ADMIN: "/admin",
  TEACHER: "/teacher",
  BUZZER: "/buzzer",
  STUDENT: "/student",
};

export const ROLE_LABEL: Record<RoleCode, string> = {
  ADMIN: "Administrator",
  TEACHER: "Guru",
  BUZZER: "Buzzer",
  STUDENT: "Murid",
};

export const ROLE_DESCRIPTION: Record<RoleCode, string> = {
  ADMIN: "Akses penuh ke seluruh sistem Akademi Mandarin.",
  TEACHER: "Fokus pengajaran: kelas, materi, tugas, dan penilaian murid.",
  BUZZER: "Fokus koordinasi: jadwal, kelas, guru, dan murid.",
  STUDENT: "Fokus pembelajaran: kursus, latihan, kuis, dan progres HSK.",
};

export interface NavItem {
  label: string;
  href: string;
  icon: IconName;
}

export interface NavGroup {
  title: string;
  items: NavItem[];
}

export function isRoleCode(value: string | null | undefined): value is RoleCode {
  return typeof value === "string" && (ROLE_CODES as string[]).includes(value);
}

export function canAccess(role: RoleCode, allowed: readonly RoleCode[]): boolean {
  return role === ROLES.ADMIN || allowed.includes(role);
}

/**
 * Dashboard navigation per role.
 * Only routes that exist in this repository are listed here - no placeholders.
 * The menu grows as each build phase lands (CRM, LMS, content, system).
 */
export const DASHBOARD_NAV: Record<RoleCode, NavGroup[]> = {
  ADMIN: [
    {
      title: "Overview",
      items: [{ label: "Dashboard", href: "/admin", icon: "dashboard" }],
    },
    {
      title: "Akun",
      items: [
        { label: "Profil", href: "/admin/profile", icon: "user" },
        { label: "Situs Publik", href: "/", icon: "globe" },
      ],
    },
  ],
  TEACHER: [
    {
      title: "Overview",
      items: [{ label: "Dashboard", href: "/teacher", icon: "dashboard" }],
    },
    {
      title: "Akun",
      items: [{ label: "Profil", href: "/teacher/profile", icon: "user" }],
    },
  ],
  BUZZER: [
    {
      title: "Overview",
      items: [{ label: "Dashboard", href: "/buzzer", icon: "dashboard" }],
    },
    {
      title: "Akun",
      items: [{ label: "Profil", href: "/buzzer/profile", icon: "user" }],
    },
  ],
  STUDENT: [
    {
      title: "Overview",
      items: [{ label: "Dashboard", href: "/student", icon: "dashboard" }],
    },
    {
      title: "Akun",
      items: [{ label: "Profil", href: "/student/profile", icon: "user" }],
    },
  ],
};
