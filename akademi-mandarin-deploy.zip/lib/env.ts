import { z } from "zod";

/**
 * Server-side environment validation.
 * Imported only by server code (server components, actions, scripts).
 */
const envSchema = z.object({
  DATABASE_URL: z.string().min(1, "DATABASE_URL wajib diisi."),
  AUTH_SECRET: z
    .string()
    .min(32, "AUTH_SECRET minimal 32 karakter (gunakan string acak)."),
  AUTH_SESSION_TTL_DAYS: z.coerce.number().int().min(1).max(90).default(7),
  AUTH_MAX_LOGIN_ATTEMPTS: z.coerce.number().int().min(3).max(20).default(5),
  AUTH_LOCK_MINUTES: z.coerce.number().int().min(1).max(1440).default(15),
  SEED_DEMO_PASSWORD: z.string().min(8).optional(),
  PANDA_AI_API_KEY: z.string().optional(),
  PANDA_AI_BASE_URL: z.string().optional(),
  PANDA_AI_MODEL: z.string().optional(),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  const issues = parsed.error.issues
    .map((issue) => `  - ${issue.path.join(".") || "env"}: ${issue.message}`)
    .join("\n");
  throw new Error(
    `Konfigurasi environment tidak valid:\n${issues}\nSalin .env.example menjadi .env lalu isi nilainya.`,
  );
}

export const env = parsed.data;

export const isProduction = process.env.NODE_ENV === "production";
