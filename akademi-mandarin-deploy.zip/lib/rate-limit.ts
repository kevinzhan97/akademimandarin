import { env } from "@/lib/env";
import { prisma } from "@/lib/prisma";

export interface ThrottleResult {
  allowed: boolean;
  remainingAttempts: number;
  retryAfterMinutes: number;
}

/**
 * Database-backed login throttling (works across server restarts / multiple
 * Node processes on shared hosting, unlike an in-memory counter).
 */
export async function checkLoginThrottle(identifier: string): Promise<ThrottleResult> {
  const windowStart = new Date(Date.now() - env.AUTH_LOCK_MINUTES * 60 * 1000);

  const failed = await prisma.loginAttempt.findMany({
    where: { identifier, success: false, createdAt: { gte: windowStart } },
    orderBy: { createdAt: "desc" },
    take: env.AUTH_MAX_LOGIN_ATTEMPTS,
    select: { createdAt: true },
  });

  if (failed.length >= env.AUTH_MAX_LOGIN_ATTEMPTS) {
    const oldest = failed[failed.length - 1]!;
    const unlockAt = oldest.createdAt.getTime() + env.AUTH_LOCK_MINUTES * 60 * 1000;
    const retryAfterMinutes = Math.max(
      1,
      Math.ceil((unlockAt - Date.now()) / (60 * 1000)),
    );
    return { allowed: false, remainingAttempts: 0, retryAfterMinutes };
  }

  return {
    allowed: true,
    remainingAttempts: env.AUTH_MAX_LOGIN_ATTEMPTS - failed.length,
    retryAfterMinutes: 0,
  };
}

export async function recordLoginAttempt(input: {
  identifier: string;
  success: boolean;
  ipAddress?: string | null;
  userAgent?: string | null;
}): Promise<void> {
  await prisma.loginAttempt.create({
    data: {
      identifier: input.identifier.slice(0, 191),
      success: input.success,
      ipAddress: input.ipAddress ?? null,
      userAgent: input.userAgent?.slice(0, 255) ?? null,
    },
  });

  // Opportunistic cleanup: keep the table small on shared hosting.
  if (Math.random() < 0.05) {
    const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    await prisma.loginAttempt
      .deleteMany({ where: { createdAt: { lt: cutoff } } })
      .catch(() => undefined);
  }
}

export async function clearLoginAttempts(identifier: string): Promise<void> {
  await prisma.loginAttempt
    .deleteMany({ where: { identifier, success: false } })
    .catch(() => undefined);
}
