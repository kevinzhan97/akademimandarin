/**
 * Static company-profile content. Learning data (programs, lessons, users)
 * always comes from MySQL for authenticated areas; `programFallback` mirrors the
 * canonical curriculum definitions so the public profile stays available when the
 * database is temporarily unreachable.
 */
import type { IconName } from "@/components/ui/Icon";
import type { ProgramView } from "@/components/public/ProgramShowcase";

export const programFallback: ProgramView[] = [
  {
    id: 1,
    code: "BASIC",
    name: "Basic",
    slug: "basic",
    hskLabel: "Pre-HSK 1",
    tagline: "Fondasi pinyin, nada, dan 150 kosakata pertama",
    description:
      "Untuk pemula total: pinyin, empat nada, sapaan, angka, dan goresan hanzi dasar.",
    durationMonths: 3,
    priceMonthly: 0,
    levels: [
      {
        id: 11,
        code: "PRE-HSK-1",
        name: "Pre-HSK 1",
        description: "Target 150 kosakata dan 40 hanzi.",
      },
    ],
  },
  {
    id: 2,
    code: "BEGINNER",
    name: "Beginner",
    slug: "beginner",
    hskLabel: "HSK 1",
    tagline: "Kalimat dasar untuk percakapan sehari-hari",
    description:
      "Menguasai 150 kata inti HSK 1, menyusun kalimat sederhana, dan membaca hanzi dasar.",
    durationMonths: 3,
    priceMonthly: 0,
    levels: [
      {
        id: 12,
        code: "HSK-1",
        name: "HSK 1",
        description: "Target 150 kosakata dan 80 hanzi.",
      },
    ],
  },
  {
    id: 3,
    code: "INTERMEDIATE",
    name: "Intermediate",
    slug: "intermediate",
    hskLabel: "HSK 2",
    tagline: "Percakapan rutin dengan tata bahasa lanjutan",
    description: "300 kata HSK 2, tata bahasa lanjutan, dan menulis kalimat lengkap.",
    durationMonths: 4,
    priceMonthly: 0,
    levels: [
      {
        id: 13,
        code: "HSK-2",
        name: "HSK 2",
        description: "Target 300 kosakata dan 150 hanzi.",
      },
    ],
  },
  {
    id: 4,
    code: "PROFESSIONAL",
    name: "Professional",
    slug: "professional",
    hskLabel: "HSK 3 Path",
    tagline: "Kurikulum intensif 3A → 3B",
    description:
      "Persiapan HSK 3 dengan segmen internal 3A/3B: 600 kata, diskusi topik, dan menulis paragraf.",
    durationMonths: 6,
    priceMonthly: 0,
    levels: [
      {
        id: 14,
        code: "HSK-3A",
        name: "HSK 3A (segmen internal)",
        description: "Target 400 kosakata dan 220 hanzi.",
      },
      {
        id: 15,
        code: "HSK-3B",
        name: "HSK 3B (segmen internal)",
        description: "Target 600 kosakata dan 300 hanzi.",
      },
    ],
  },
  {
    id: 5,
    code: "ADVANCE",
    name: "Advance",
    slug: "advance",
    hskLabel: "HSK 4 Path",
    tagline: "Kurikulum intensif 4A → 4B",
    description:
      "Persiapan HSK 4 dengan segmen internal 4A/4B: 1.200 kata, presentasi, dan esai.",
    durationMonths: 8,
    priceMonthly: 0,
    levels: [
      {
        id: 16,
        code: "HSK-4A",
        name: "HSK 4A (segmen internal)",
        description: "Target 900 kosakata dan 450 hanzi.",
      },
      {
        id: 17,
        code: "HSK-4B",
        name: "HSK 4B (segmen internal)",
        description: "Target 1.200 kosakata dan 600 hanzi.",
      },
    ],
  },
];

export interface HskStage {
  stage: string;
  label: string;
  level: string;
  /** Akademi Mandarin curriculum segment shown on the homepage timeline. */
  path?: string;
  focus: string;
  internal?: string;
}

/**
 * HSK learning path. The official exam levels remain HSK 1-4; the 3A/3B and
 * 4A/4B splits are internal Akademi Mandarin curriculum segments.
 */
export const hskStages: HskStage[] = [
  {
    stage: "BASIC",
    label: "Basic",
    level: "Pre-HSK 1",
    focus: "Pinyin, empat nada, sapaan, angka, dan 150 kosakata pertama.",
  },
  {
    stage: "BEGINNER",
    label: "Beginner",
    level: "HSK 1",
    focus: "Kalimat dasar sehari-hari, 150 kata inti, membaca hanzi sederhana.",
  },
  {
    stage: "INTERMEDIATE",
    label: "Intermediate",
    level: "HSK 2",
    focus: "Percakapan rutin, 300 kata, tata bahasa lanjutan, menulis kalimat.",
  },
  {
    stage: "PROFESSIONAL",
    label: "Professional",
    level: "HSK 3 Path",
    path: "HSK 3A → 3B",
    focus:
      "Kurikulum intensif 3A → 3B: 600 kata, diskusi topik, menulis paragraf.",
    internal: "3A / 3B adalah segmen internal Akademi Mandarin",
  },
  {
    stage: "ADVANCE",
    label: "Advance",
    level: "HSK 4 Path",
    path: "HSK 4A → 4B",
    focus:
      "Kurikulum intensif 4A → 4B: 1.200 kata, presentasi, membaca artikel, esai.",
    internal: "4A / 4B adalah segmen internal Akademi Mandarin",
  },
];

export const whyMandarin: { icon: IconName; title: string; description: string }[] = [
  {
    icon: "globe",
    title: "Bahasa dengan penutur terbanyak",
    description:
      "Lebih dari 1,1 miliar orang berbicara Mandarin. Menguasainya berarti membuka akses ke pasar, budaya, dan jaringan terbesar di dunia.",
  },
  {
    icon: "trending",
    title: "Kekuatan ekonomi Tiongkok",
    description:
      "Tiongkok adalah mitra dagang terbesar Indonesia. Karyawan yang bisa berbahasa Mandarin menjadi nilai tambah di banyak industri.",
  },
  {
    icon: "award",
    title: "Sertifikasi HSK yang diakui",
    description:
      "HSK diakui secara internasional untuk studi, beasiswa, dan rekrutmen. Kami menyiapkan Anda dari Pre-HSK 1 hingga HSK 4.",
  },
  {
    icon: "brain",
    title: "Melatih daya ingat",
    description:
      "Menulis hanzi melatih memori visual dan disiplin belajar - manfaat kognitif yang dirasakan murid kami setiap pekan.",
  },
  {
    icon: "briefcase",
    title: "Nilai jual di dunia kerja",
    description:
      "Banyak lowongan menempatkan kemampuan Mandarin sebagai nilai plus. Sertifikat dan portofolio belajar Anda membantu bersaing.",
  },
  {
    icon: "palette",
    title: "Memahami budaya",
    description:
      "Bahasa dan budaya tidak bisa dipisahkan. Kami membahas etiket, idiom, dan konteks sosial agar komunikasi Anda tepat.",
  },
];

export const methodSteps: { step: string; title: string; description: string; icon: IconName }[] = [
  {
    step: "01",
    title: "Tes Penempatan",
    description:
      "Kami memetakan kemampuan awal Anda - pinyin, kosakata, listening - lalu menentukan titik mulai Pre-HSK 1 sampai HSK 4.",
    icon: "compass",
  },
  {
    step: "02",
    title: "Rencana Belajar Personal",
    description:
      "Target level, jumlah sesi, dan jadwal disusun bersama Anda. Setiap target dipecah per pekan agar mudah dicapai.",
    icon: "target",
  },
  {
    step: "03",
    title: "Kelas Interaktif 4 Keterampilan",
    description:
      "Setiap sesi melatih 听 (mendengar), 说 (berbicara), 读 (membaca), dan 写 (menulis) - seimbang, bukan hanya percakapan.",
    icon: "headphones",
  },
  {
    step: "04",
    title: "Latihan Terstruktur di LMS",
    description:
      "Murid mengakses materi, kuis, dan tugas di portal belajar kami. Semua hasil tersimpan sebagai riwayat belajar.",
    icon: "dashboard",
  },
  {
    step: "05",
    title: "Evaluasi & Simulasi HSK",
    description:
      "Progres per keterampilan dipantau guru. Menjelang ujian, murid mengerjakan simulasi HSK dengan penilaian nyata.",
    icon: "award",
  },
];

export const faqs: { question: string; answer: string }[] = [
  {
    question: "Apakah saya harus punya dasar Mandarin untuk mulai?",
    answer:
      "Tidak. Program Basic (Pre-HSK 1) dirancang untuk pemula total, mulai dari pinyin, nada, dan hanzi dasar. Jika Anda sudah pernah belajar, kami lakukan tes penempatan untuk menentukan level yang tepat.",
  },
  {
    question: "Apa perbedaan HSK 3 dan segmen 3A/3B?",
    answer:
      "Level ujian resmi tetap HSK 3. Segmen 3A dan 3B adalah pembagian internal Akademi Mandarin agar materi HSK 3 dan persiapan HSK 4 dapat dipelajari bertahap. Hal yang sama berlaku untuk 4A dan 4B.",
  },
  {
    question: "Berapa lama sampai bisa lulus HSK 1?",
    answer:
      "Dengan 2 sesi per pekan dan latihan mandiri rutin, mayoritas murid kami siap mengikuti simulasi HSK 1 dalam 3 sampai 4 bulan. Durasi dapat berbeda tergantung frekuensi belajar dan waktu latihan mandiri.",
  },
  {
    question: "Kelas online atau tatap muka?",
    answer:
      "Keduanya tersedia. Kelas online berlangsung melalui Zoom dengan kelas kecil, sementara kelas tatap muka dapat dibuka sesuai kebutuhan grup dan ketersediaan pengajar di wilayah Anda.",
  },
  {
    question: "Apakah ada kelas untuk perusahaan atau kelompok?",
    answer:
      "Ada. Kami melayani pelatihan korporat dan kelompok dengan kurikulum yang disesuaikan: Mandarin bisnis, persiapan relokasi, hingga persiapan ujian internal perusahaan.",
  },
  {
    question: "Bagaimana saya memantau perkembangan belajar?",
    answer:
      "Setiap murid mendapat akun portal belajar. Di sana tersedia progres kursus, hasil kuis, status tugas, kehadiran, jadwal kelas, dan perkembangan tiap keterampilan HSK.",
  },
  {
    question: "Apakah ada trial gratis?",
    answer:
      "Ya. Anda bisa mengambil satu sesi trial 60 menit bersama guru kami tanpa biaya. Sesi ini dipakai untuk mengukur level dan menyusun rencana belajar.",
  },
  {
    question: "Bagaimana cara pembayaran dan apakah bisa dicicil?",
    answer:
      "Pembayaran dapat dilakukan melalui transfer bank, QRIS, atau e-wallet. Untuk paket beberapa bulan, tim kami dapat mengatur skema pembayaran bertahap yang tercatat rapi di sistem kami.",
  },
];
