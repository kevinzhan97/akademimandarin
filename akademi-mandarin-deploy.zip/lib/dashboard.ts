import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { DASHBOARD_NAV, ROLE_HOME, ROLE_LABEL } from "@/lib/rbac";
import type { RoleCode } from "@/types/auth";

/**
 * Bootstraps a role dashboard: enforces server-side authorization for the role
 * (ADMIN always passes), resolves the correct navigation and the notification
 * badge count. Every dashboard layout uses this.
 */
export async function loadDashboardShell(...allowed: RoleCode[]) {
  const user = await requireRole(...allowed);

  const unreadNotifications = await prisma.notification.count({
    where: { userId: user.id, readAt: null },
  });

  return {
    user,
    shell: {
      nav: DASHBOARD_NAV[user.role],
      user: {
        fullName: user.fullName,
        username: user.username,
        roleLabel: ROLE_LABEL[user.role],
        roleHome: ROLE_HOME[user.role],
        mustChangePassword: user.mustChangePassword,
      },
      unreadNotifications,
    },
  };
}
