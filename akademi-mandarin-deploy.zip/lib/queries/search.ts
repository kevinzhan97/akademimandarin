import { faqs, hskStages, methodSteps } from "@/lib/content";
import { getPublicPrograms } from "@/lib/queries/public";

export interface SearchHit {
  title: string;
  description?: string;
  href: string;
}

export interface SearchGroup {
  label: string;
  hits: SearchHit[];
}

export interface SearchResults {
  term: string;
  groups: SearchGroup[];
}

interface IndexedPage extends SearchHit {
  keywords: string[];
}

/** Curated company-profile pages searchable from the header. */
const pages: IndexedPage[] = [
  {
    title: "Beranda — Mandarin Menghubungkan Lebih Banyak Peluang",
    description:
      "Ikhtisar Akademi Mandarin: program, jalur HSK, metode belajar, dan peluang.",
    href: "/",
    keywords: ["beranda", "home", "akademi mandarin", "peluang", "hero"],
  },
  {
    title: "Tentang Kami",
    description:
      "Profil, visi, misi, nilai, dan tim pengajar Akademi Mandarin.",
    href: "/tentang-kami",
    keywords: ["profil", "visi", "misi", "tim", "guru", "pengajar", "sejarah"],
  },
  {
    title: "Program Belajar",
    description:
      "Program Pre-HSK 1 sampai HSK 4 beserta durasi, level, dan target kosakata.",
    href: "/program",
    keywords: [
      "program",
      "kelas",
      "kursus",
      "biaya",
      "harga",
      "durasi",
      "basic",
      "beginner",
      "intermediate",
      "professional",
      "advance",
    ],
  },
  {
    title: "Mengapa Belajar Mandarin",
    description:
      "Alasan karier, pendidikan, bisnis, travel, dan budaya untuk belajar Mandarin.",
    href: "/mengapa-mandarin",
    keywords: [
      "karier",
      "kerja",
      "beasiswa",
      "bisnis",
      "travel",
      "budaya",
      "peluang",
    ],
  },
  {
    title: "Metode Belajar",
    description:
      "Lima langkah belajar: tes penempatan, rencana personal, kelas empat keterampilan, LMS, dan simulasi HSK.",
    href: "/metode-belajar",
    keywords: [
      "metode",
      "cara belajar",
      "kurikulum",
      "kelas interaktif",
      "lms",
      "evaluasi",
    ],
  },
  {
    title: "HSK Learning Path",
    description:
      "Jalur Pre-HSK 1 sampai HSK 4 dengan segmen internal 3A/3B dan 4A/4B.",
    href: "/hsk-path",
    keywords: ["hsk", "level", "ujian", "sertifikat", "3a", "3b", "4a", "4b"],
  },
  {
    title: "FAQ",
    description:
      "Pertanyaan yang sering diajukan tentang kelas, jadwal, dan pendaftaran.",
    href: "/faq",
    keywords: ["faq", "pertanyaan", "tanya", "jadwal", "pendaftaran"],
  },
  {
    title: "Mulai Sekarang — Trial Gratis 60 Menit",
    description:
      "Isi formulir singkat dan tim akademik kami menghubungi Anda.",
    href: "/mulai-sekarang",
    keywords: [
      "daftar",
      "trial",
      "gratis",
      "formulir",
      "konsultasi",
      "tes penempatan",
    ],
  },
];

function normalize(value: string) {
  return value.toLowerCase();
}

function matches(term: string, fields: (string | null | undefined)[]) {
  const needle = normalize(term);
  return fields.some((field) =>
    field ? normalize(field).includes(needle) : false,
  );
}

function snippet(value: string, max = 170) {
  return value.length > max ? `${value.slice(0, max).trimEnd()}…` : value;
}

/**
 * Company-profile search across curated content and published programs.
 * Program results tolerate a database outage through `getPublicPrograms`.
 */
export async function searchPublicContent(
  rawTerm: string,
): Promise<SearchResults> {
  const term = rawTerm.trim().replace(/\s+/g, " ").slice(0, 64);
  if (term.length < 2) return { term, groups: [] };

  const programs = await getPublicPrograms();

  const programHits: SearchHit[] = programs
    .filter((program) =>
      matches(term, [
        program.name,
        program.code,
        program.hskLabel,
        program.tagline,
        program.description,
        ...program.levels.map((level) => level.name),
      ]),
    )
    .map((program) => ({
      title: `${program.name} — ${program.hskLabel}`,
      description: program.tagline ?? program.description ?? undefined,
      href: `/program#${program.slug}`,
    }));

  const stageHits: SearchHit[] = hskStages
    .filter((stage) =>
      matches(term, [
        stage.stage,
        stage.label,
        stage.level,
        stage.path,
        stage.focus,
      ]),
    )
    .map((stage) => ({
      title: `${stage.label} — ${stage.path ?? stage.level}`,
      description: snippet(stage.focus),
      href: "/hsk-path",
    }));

  const methodHits: SearchHit[] = methodSteps
    .filter((step) => matches(term, [step.title, step.description]))
    .map((step) => ({
      title: `${step.step}. ${step.title}`,
      description: snippet(step.description),
      href: "/metode-belajar",
    }));

  const faqHits: SearchHit[] = faqs
    .filter((faq) => matches(term, [faq.question, faq.answer]))
    .map((faq) => ({
      title: faq.question,
      description: snippet(faq.answer),
      href: "/faq",
    }));

  const pageHits: SearchHit[] = pages
    .filter((page) =>
      matches(term, [page.title, page.description, ...page.keywords]),
    )
    .map((page) => ({
      title: page.title,
      description: page.description,
      href: page.href,
    }));

  return {
    term,
    groups: [
      { label: "Program", hits: programHits },
      { label: "Jalur HSK", hits: stageHits },
      { label: "Metode Belajar", hits: methodHits },
      { label: "Tanya Jawab", hits: faqHits },
      { label: "Halaman", hits: pageHits },
    ].filter((group) => group.hits.length > 0),
  };
}
