import { prisma } from "@/lib/prisma";
import { todayDate } from "@/lib/utils";

/** Aggregated data for the admin overview (everything admin sees at a glance). */
export async function getAdminDashboard() {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const weekAhead = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  const [
    totalStudents,
    activeStudents,
    teacherCount,
    buzzerCount,
    totalLeads,
    newLeads,
    activeClasses,
    upcomingClasses,
    revenue,
    outstanding,
    recentLeads,
    upcomingSchedules,
    recentPayments,
    pendingEnrollments,
    hskAverage,
  ] = await Promise.all([
    prisma.student.count(),
    prisma.student.count({ where: { status: "ACTIVE" } }),
    prisma.teacher.count({ where: { status: "ACTIVE" } }),
    prisma.buzzer.count({ where: { status: "ACTIVE" } }),
    prisma.lead.count(),
    prisma.lead.count({ where: { status: "LEAD" } }),
    prisma.class.count({ where: { status: "ACTIVE" } }),
    prisma.class.count({
      where: { status: { in: ["PLANNED", "ACTIVE"] }, startDate: { lte: weekAhead } },
    }),
    prisma.payment.aggregate({
      _sum: { amount: true },
      where: { status: "PAID", paidAt: { gte: startOfMonth } },
    }),
    prisma.payment.aggregate({
      _sum: { amount: true },
      where: { status: { in: ["PENDING", "OVERDUE"] } },
    }),
    prisma.lead.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
      include: {
        program: { select: { name: true } },
        assignedTo: { select: { fullName: true } },
      },
    }),
    prisma.schedule.findMany({
      where: { isActive: true },
      orderBy: [{ dayOfWeek: "asc" }, { startTime: "asc" }],
      take: 5,
      include: {
        class: { select: { name: true, code: true } },
        teacher: { include: { user: { select: { fullName: true } } } },
      },
    }),
    prisma.payment.findMany({
      orderBy: { createdAt: "desc" },
      take: 5,
      include: {
        student: { include: { user: { select: { fullName: true } } } },
        enrollment: { include: { program: { select: { name: true } } } },
      },
    }),
    prisma.enrollment.findMany({
      where: { status: { in: ["PENDING", "DRAFT"] } },
      orderBy: { createdAt: "desc" },
      take: 5,
      include: {
        student: { include: { user: { select: { fullName: true } } } },
        program: { select: { name: true } },
      },
    }),
    prisma.hSKProgress.aggregate({ _avg: { masteryPercent: true } }),
  ]);

  return {
    counters: {
      totalStudents,
      activeStudents,
      teachers: teacherCount,
      buzzers: buzzerCount,
      totalLeads,
      newLeads,
      activeClasses,
      upcomingClasses,
    },
    finance: {
      revenueThisMonth: Number(revenue._sum.amount ?? 0),
      outstanding: Number(outstanding._sum.amount ?? 0),
    },
    learning: {
      averageMastery: Math.round(hskAverage._avg.masteryPercent ?? 0),
    },
    recentLeads,
    upcomingSchedules,
    recentPayments,
    pendingEnrollments,
  };
}

/** Buzzer workspace: coordination view over classes, teachers and schedules. */
export async function getBuzzerDashboard() {
  const [
    unassignedClasses,
    activeTeachers,
    scheduleCount,
    studentsWithoutClass,
    weekSchedules,
    pendingEnrollments,
    activeClasses,
  ] = await Promise.all([
    prisma.class.findMany({
      where: { teacherId: null, status: { in: ["PLANNED", "ACTIVE"] } },
      orderBy: { startDate: "asc" },
      take: 6,
      include: {
        program: { select: { name: true } },
        level: { select: { name: true } },
        _count: { select: { students: true } },
      },
    }),
    prisma.teacher.count({ where: { status: "ACTIVE" } }),
    prisma.schedule.count({ where: { isActive: true } }),
    prisma.student.count({
      where: { status: "ACTIVE", classes: { none: { status: "ACTIVE" } } },
    }),
    prisma.schedule.findMany({
      where: { isActive: true },
      orderBy: [{ dayOfWeek: "asc" }, { startTime: "asc" }],
      take: 8,
      include: {
        class: { select: { name: true, code: true } },
        teacher: { include: { user: { select: { fullName: true } } } },
      },
    }),
    prisma.enrollment.count({ where: { status: "PENDING" } }),
    prisma.class.count({ where: { status: "ACTIVE" } }),
  ]);

  return {
    counters: {
      unassignedClasses: unassignedClasses.length,
      activeTeachers,
      activeClasses,
      studentsWithoutClass,
      scheduledSlots: scheduleCount,
      pendingEnrollments,
    },
    unassignedClasses,
    weekSchedules,
  };
}

/** Student workspace: program, progress, schedule, quizzes and attendance. */
export async function getStudentDashboard(userId: number) {
  const student = await prisma.student.findUnique({
    where: { userId },
    include: {
      program: { select: { id: true, name: true, hskLabel: true } },
      level: { select: { id: true, name: true, code: true } },
    },
  });
  if (!student) return null;

  const studentId = student.id;

  const [classLinks, attendances, attempts, submissions, hskProgress, pendingAssignments, publishedLessons, gradedCount] =
    await Promise.all([
      prisma.classStudent.findMany({
        where: { studentId, status: "ACTIVE" },
        include: {
          class: {
            include: {
              program: { select: { name: true } },
              teacher: { include: { user: { select: { fullName: true } } } },
              schedules: {
                where: { isActive: true },
                orderBy: [{ dayOfWeek: "asc" }, { startTime: "asc" }],
              },
              _count: { select: { students: true } },
            },
          },
        },
      }),
      prisma.attendance.findMany({
        where: { studentId },
        orderBy: { date: "desc" },
        take: 20,
      }),
      prisma.quizAttempt.findMany({
        where: { studentId },
        orderBy: { startedAt: "desc" },
        take: 5,
        include: {
          quiz: { select: { title: true, passingScore: true, type: true } },
        },
      }),
      prisma.submission.findMany({
        where: { studentId },
        orderBy: { submittedAt: "desc" },
        take: 5,
        include: {
          assignment: { select: { title: true, dueDate: true, maxScore: true } },
        },
      }),
      prisma.hSKProgress.findMany({
        where: { studentId },
        orderBy: { levelCode: "asc" },
      }),
      prisma.assignment.count({
        where: { isPublished: true, submissions: { none: { studentId } } },
      }),
      prisma.lesson.count({
        where: {
          isPublished: true,
          course: { programId: student.programId ?? undefined },
        },
      }),
      prisma.quizAttempt.count({
        where: { studentId, status: { in: ["SUBMITTED", "GRADED"] } },
      }),
    ]);

  const presentCount = attendances.filter(
    (item) => item.status === "PRESENT" || item.status === "LATE",
  ).length;

  return {
    student,
    classLinks,
    attendances,
    attempts,
    submissions,
    hskProgress,
    counters: {
      classes: classLinks.length,
      pendingAssignments,
      publishedLessons,
      quizzesTaken: gradedCount,
      attendanceRate: attendances.length
        ? Math.round((presentCount / attendances.length) * 100)
        : 0,
    },
  };
}

export async function getTeacherDashboard(userId: number) {
  const teacher = await prisma.teacher.findUnique({
    where: { userId },
    select: { id: true, specialization: true },
  });
  if (!teacher) return null;

  const teacherId = teacher.id;
  const classes = await prisma.class.findMany({
    where: { teacherId },
    orderBy: { startDate: "desc" },
    take: 6,
    include: {
      program: { select: { name: true } },
      level: { select: { name: true } },
      _count: { select: { students: true } },
    },
  });

  const classIds = classes.map((item) => item.id);

  const [activeStudentGroups, schedules, submissionsToGrade, attemptsToGrade, attendanceToday] =
    await Promise.all([
      prisma.classStudent.groupBy({
        by: ["studentId"],
        where: { classId: { in: classIds }, status: "ACTIVE" },
      }),
      prisma.schedule.findMany({
        where: { teacherId, isActive: true },
        orderBy: [{ dayOfWeek: "asc" }, { startTime: "asc" }],
        take: 8,
        include: { class: { select: { name: true, code: true } } },
      }),
      prisma.submission.findMany({
        where: {
          status: "SUBMITTED",
          student: { classes: { some: { classId: { in: classIds } } } },
        },
        orderBy: { submittedAt: "asc" },
        take: 5,
        include: {
          student: { include: { user: { select: { fullName: true } } } },
          assignment: { select: { title: true, maxScore: true } },
        },
      }),
      prisma.quizAttempt.findMany({
        where: {
          status: "SUBMITTED",
          student: { classes: { some: { classId: { in: classIds } } } },
        },
        orderBy: { submittedAt: "asc" },
        take: 5,
        include: {
          student: { include: { user: { select: { fullName: true } } } },
          quiz: { select: { title: true, passingScore: true } },
        },
      }),
      classIds.length
        ? prisma.attendance.count({
            where: { classId: { in: classIds }, date: todayDate() },
          })
        : Promise.resolve(0),
    ]);

  const [submissionQueue, attemptQueue] = await Promise.all([
    prisma.submission.count({
      where: {
        status: "SUBMITTED",
        student: { classes: { some: { classId: { in: classIds } } } },
      },
    }),
    prisma.quizAttempt.count({
      where: {
        status: "SUBMITTED",
        student: { classes: { some: { classId: { in: classIds } } } },
      },
    }),
  ]);

  return {
    teacher,
    counters: {
      classes: classes.length,
      students: activeStudentGroups.length,
      submissionsToGrade: submissionQueue,
      attemptsToGrade: attemptQueue,
      attendanceToday,
    },
    classes,
    schedules,
    submissionsToGrade,
    attemptsToGrade,
  };
}
