import { prisma } from "@/lib/prisma";
import { programFallback } from "@/lib/content";
import type { ProgramView } from "@/components/public/ProgramShowcase";
import type { LeadProgramOption } from "@/components/public/LeadForm";

/**
 * Public reads are fault-tolerant: the company profile keeps working (using the
 * curated curriculum definitions) even if MySQL is temporarily unreachable.
 * Admin/teaching data never falls back - it always requires the database.
 */
export async function getPublicPrograms(): Promise<ProgramView[]> {
  try {
    const programs = await prisma.program.findMany({
      where: { isPublished: true },
      orderBy: { order: "asc" },
      include: { levels: { orderBy: { order: "asc" } } },
    });

    if (programs.length === 0) return programFallback;

    return programs.map((program) => ({
      id: program.id,
      code: program.code,
      name: program.name,
      slug: program.slug,
      hskLabel: program.hskLabel,
      tagline: program.tagline,
      description: program.description,
      durationMonths: program.durationMonths,
      priceMonthly: Number(program.priceMonthly),
      levels: program.levels.map((level) => ({
        id: level.id,
        code: level.code,
        name: level.name,
        description: level.description,
      })),
    }));
  } catch (error) {
    console.error("[public] gagal memuat program dari database:", error);
    return programFallback;
  }
}

export async function getLeadProgramOptions(): Promise<LeadProgramOption[]> {
  try {
    const programs = await prisma.program.findMany({
      where: { isPublished: true },
      orderBy: { order: "asc" },
      select: { id: true, name: true, hskLabel: true },
    });
    if (programs.length > 0) return programs;
  } catch (error) {
    console.error("[public] gagal memuat opsi program:", error);
  }

  // The form stays usable without ids; staff confirm the program during follow-up.
  return [];
}

export interface PublicStats {
  available: boolean;
  students: number;
  teachers: number;
  programs: number;
  activeClasses: number;
}

/** Real numbers straight from MySQL - never hardcoded marketing figures. */
export async function getPublicStats(): Promise<PublicStats> {
  try {
    const [students, teachers, programs, activeClasses] = await Promise.all([
      prisma.student.count({ where: { status: "ACTIVE" } }),
      prisma.teacher.count({ where: { status: "ACTIVE" } }),
      prisma.program.count({ where: { isPublished: true } }),
      prisma.class.count({ where: { status: "ACTIVE" } }),
    ]);

    return { available: true, students, teachers, programs, activeClasses };
  } catch (error) {
    console.error("[public] gagal memuat statistik:", error);
    return { available: false, students: 0, teachers: 0, programs: 0, activeClasses: 0 };
  }
}
