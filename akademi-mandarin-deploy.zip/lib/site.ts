/**
 * Site-wide configuration. Safe to import from both server and client
 * components (only NEXT_PUBLIC_* values are referenced here).
 */
export const siteConfig = {
  name: process.env.NEXT_PUBLIC_SITE_NAME || "Akademi Mandarin",
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://akademimandarin.my.id",
  tagline: "Mandarin Menghubungkan Lebih Banyak Peluang",
  description:
    "Akademi Mandarin membantu Anda menguasai bahasa, membuka wawasan, dan menjembatani masa depan antara Indonesia dan Tiongkok.",
  whatsapp: process.env.NEXT_PUBLIC_CONTACT_WHATSAPP || "",
  email: process.env.NEXT_PUBLIC_CONTACT_EMAIL || "info@akademimandarin.my.id",
  phone: process.env.NEXT_PUBLIC_CONTACT_PHONE || "",
  social: {
    instagram: "https://instagram.com/akademimandarin",
    tiktok: "https://tiktok.com/@akademimandarin",
    youtube: "https://youtube.com/@akademimandarin",
    facebook: "https://facebook.com/akademimandarin",
  },
} as const;

export const publicNav = [
  { label: "Beranda", href: "/" },
  { label: "Tentang Kami", href: "/tentang-kami" },
  { label: "Program", href: "/program" },
  { label: "Mengapa Mandarin", href: "/mengapa-mandarin" },
  { label: "Metode Belajar", href: "/metode-belajar" },
  { label: "HSK Path", href: "/hsk-path" },
  { label: "FAQ", href: "/faq" },
] as const;

export function whatsappLink(message?: string) {
  const number = siteConfig.whatsapp.replace(/[^0-9]/g, "");
  if (!number) return "/mulai-sekarang";
  const text = encodeURIComponent(
    message || "Halo Akademi Mandarin, saya ingin bertanya tentang program Mandarin.",
  );
  return `https://wa.me/${number}?text=${text}`;
}
